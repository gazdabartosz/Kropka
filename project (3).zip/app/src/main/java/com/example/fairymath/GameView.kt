package com.example.fairymath

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class GameView(
    context: Context,
    private val cfg: GameSettings,
    val character: Int,
    start: SaveState?
) : View(context) {

    interface Listener {
        fun onGameOver(score: Int)
        fun onPauseRequested()
    }

    var listener: Listener? = null
    var paused = false
    var tapToResume = false

    var score = start?.score ?: 0
        private set
    var lives = start?.lives ?: 5
        private set
    var level = start?.level ?: 1
        private set
    private var progress = start?.progress ?: 0 // pokonane potwory na tym poziomie (0..5)

    private val tier: Int get() = min(4, level / 5)
    private val biome: Int get() = (level - 1) % 6

    private class Enc(val kind: Int, val bonus: Boolean, val boss: Boolean) {
        var chest = false
        var a = 0
        var b = 0
        var op = 0
        var answer = 0
        var total = 1f
        var left = 1f
        var x = 0f
        var y = 0f
        var size = 0f
        var phase = 0 // 0 idzie, 1 atakuje, 2 czeka na trafienie, 3 ginie, 4 odchodzi, 5 boss się cofa
        var timer = 0f
        var hp = 1
        var maxHp = 1
        var flash = 0f
        var walk = 0f
        val seed = Random.nextFloat() * 10f
    }

    private class Proj(var x: Float, var y: Float, val vx: Float, val vy: Float, val tx: Float, val angle: Float)
    private class Spark(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val maxLife: Float, val color: Int, val size: Float
    )

    private class Pop(val text: String, var x: Float, var y: Float, var life: Float, val color: Int, val size: Float)

    private var enc: Enc? = null
    private var proj: Proj? = null
    private val parts = ArrayList<Spark>()
    private val pops = ArrayList<Pop>()

    private var input = ""
    private var lastEq: String? = null
    private var lastOk = true
    private var spawnDelay = 1.2f
    private var sinceBonus = 0
    private var bonusEvery = Random.nextInt(5, 9)
    private val gear = IntArray(6) { -1 }
    init {
        start?.gear?.forEachIndexed { i, v -> if (i < 6) gear[i] = v }
    }
    private var chestPending = false
    private var bossesSinceChest = 0
    private var chestEvery = Random.nextInt(3, 11)
    private var choosing = false
    private var offers = IntArray(0)

    private var t = 0f
    private var lastNs = 0L
    private var shake = 0f
    private var hitBlink = 0f
    private var flash = 0f
    private var attackT = 0f
    private var launched = true
    private var transT = 0f
    private var scroll = 0f
    private var run = 1f
    private var runPhase = 0f
    private var vignette: Shader? = null
    private var groundShade: Shader? = null
    private var fogShaders: Array<Shader>? = null
    private val fogCol = intArrayOf(
        0xFF3B6B5F.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD9A8.toInt(),
        0xFF9DB89A.toInt(), 0xFFFF7043.toInt(), 0xFF9575CD.toInt()
    )
    private var over = false
    private var overTimer = 0f
    private var overFired = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rect = RectF()
    private var s = 1f
    private var skies: Array<Shader>? = null

    private val biomeNames = arrayOf(
        "Mroczny Las", "Śnieżne Szczyty", "Pustynne Ruiny",
        "Bagna Mgieł", "Ognista Kraina", "Kryształowe Jaskinie"
    )
    private val skyTop = intArrayOf(
        0xFF0B1D2A.toInt(), 0xFF7FA6CF.toInt(), 0xFFD9764A.toInt(),
        0xFF1B2925.toInt(), 0xFF2B0A0A.toInt(), 0xFF120B26.toInt()
    )
    private val skyBot = intArrayOf(
        0xFF2F5D50.toInt(), 0xFFE3EEF7.toInt(), 0xFFFBD38D.toInt(),
        0xFF5E7A62.toInt(), 0xFFB5381A.toInt(), 0xFF3B2A66.toInt()
    )
    private val farCol = intArrayOf(
        0xFF14302A.toInt(), 0xFFB8CFE3.toInt(), 0xFFC96F3B.toInt(),
        0xFF2D4237.toInt(), 0xFF4A1410.toInt(), 0xFF2A1F52.toInt()
    )
    private val nearCol = intArrayOf(
        0xFF0E2420.toInt(), 0xFF9DB7CC.toInt(), 0xFFB35A2B.toInt(),
        0xFF22352B.toInt(), 0xFF33100D.toInt(), 0xFF1D1540.toInt()
    )
    private val groundCol = intArrayOf(
        0xFF1E3A22.toInt(), 0xFFDCE8F2.toInt(), 0xFFD0A860.toInt(),
        0xFF2B3A27.toInt(), 0xFF2A1A18.toInt(), 0xFF2E2848.toInt()
    )
    private val groundTop = intArrayOf(
        0xFF2E5A33.toInt(), 0xFFFFFFFF.toInt(), 0xFFE7C98C.toInt(),
        0xFF3F5A3A.toInt(), 0xFFFF5722.toInt(), 0xFF6A5BAA.toInt()
    )

    private val kindSize = floatArrayOf(0.80f, 0.95f, 0.65f, 1.10f, 0.60f, 0.95f, 1.20f, 0.80f, 0.95f)
    private val pool = arrayOf(
        intArrayOf(0, 2, 3), intArrayOf(1, 5, 2), intArrayOf(1, 3, 4),
        intArrayOf(4, 0, 5), intArrayOf(3, 2, 1), intArrayOf(5, 1, 2)
    )
    private val bossKind = intArrayOf(6, 5, 3, 4, 3, 1)

    private val vw: Float get() = width.toFloat()
    private val vh: Float get() = height.toFloat()
    private val footY: Float get() = vh - 50f * s
    private val heroX: Float get() = vw * 0.20f
    private val charH: Float get() = min(100f * s, max(footY - 190f * s, 40f * s))

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        s = w / 360f
        skies = Array(6) { i ->
            LinearGradient(0f, 0f, 0f, h.toFloat(), skyTop[i], skyBot[i], Shader.TileMode.CLAMP)
        }
        val fy = h - 50f * s
        fogShaders = Array(6) { i ->
            val base = fogCol[i] and 0x00FFFFFF
            LinearGradient(0f, fy - 110f * s, 0f, fy - 4f * s, base, base or 0x66000000, Shader.TileMode.CLAMP)
        }
        groundShade = LinearGradient(0f, fy - 10f * s, 0f, h.toFloat(), 0x00000000, 0x88000000.toInt(), Shader.TileMode.CLAMP)
        val rad = max(w, h) * 0.75f
        vignette = RadialGradient(
            w / 2f, h / 2f, rad,
            intArrayOf(0x00000000, 0x00000000, 0x88000000.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    // ---------- API klawiatury ----------

    fun pressDigit(d: Int) {
        val e = enc ?: return
        if (e.phase != 0 || paused || input.length >= 3) return
        input = if (input == "0") d.toString() else input + d
    }

    fun backspace() {
        if (input.isNotEmpty()) input = input.dropLast(1)
    }

    fun submit() {
        val e = enc ?: return
        if (e.phase != 0 || paused || input.isEmpty()) return
        val v = input.toIntOrNull() ?: return
        input = ""
        if (v == e.answer) correct(e) else fail(e)
    }

    fun snapshot() = SaveState(character, score, max(1, lives), level, progress, gear.toList())

    // ---------- logika ----------

    private fun baseTime(): Float {
        val base = when (cfg.difficulty) {
            0 -> 15f
            1 -> 10f
            else -> 5f
        }
        return max(base * 0.7f, base * 0.96f.pow(level - 1))
    }

    private fun setEquation(e: Enc) {
        val ops = ArrayList<Int>()
        if (cfg.add) ops.add(0)
        if (cfg.sub) ops.add(1)
        if (cfg.mul) ops.add(2)
        if (ops.isEmpty()) ops.add(0)
        val op = ops.random()
        val hard = (e.boss && !e.chest) || e.bonus
        val lo = cfg.min
        var hi = min(cfg.max + (level - 1) * 3, 100)
        if (hard) hi = min(hi * 3 / 2 + 5, 100)
        if (hi <= lo) hi = lo + 1
        var a: Int
        var b: Int
        val ans: Int
        if (op == 2) {
            val mhi = min(hi, min(25, 10 + level * 2 + (if (hard) 4 else 0)))
            val mlo = max(2, min(lo, mhi - 1))
            a = Random.nextInt(mlo, mhi + 1)
            b = Random.nextInt(mlo, mhi + 1)
            ans = a * b
        } else {
            a = Random.nextInt(lo, hi + 1)
            b = Random.nextInt(lo, hi + 1)
            if (op == 1 && b > a) {
                val tmp = a; a = b; b = tmp
            }
            ans = if (op == 0) a + b else a - b
        }
        e.a = a
        e.b = b
        e.op = op
        e.answer = ans
        e.total = baseTime() * (if (e.chest) 3f else if (e.boss) 2f else if (e.bonus) 1.6f else 1f)
        e.left = e.total
        lastEq = null
        input = ""
    }

    private fun eqText(e: Enc, ans: String): String {
        val sym = when (e.op) {
            0 -> "+"
            1 -> "−"
            else -> "×"
        }
        return "${e.a} $sym ${e.b} = $ans"
    }

    private fun startXFor(e: Enc) = vw + e.size * 0.6f

    private fun visXFor(e: Enc) = vw - e.size * 0.55f - 8f * s

    private fun hitXFor(e: Enc) =
        if (e.bonus) heroX + charH * 1.3f else heroX + charH * 0.28f + e.size * 0.28f

    private fun hover(e: Enc, f: Float): Float {
        return when {
            e.bonus -> -charH * 0.6f + sin(t * 3f + e.seed) * 0.08f * charH
            e.kind == 2 -> -(1f - f * 0.6f) * charH * 0.55f + sin(t * 5f + e.seed) * 0.06f * charH
            e.kind == 5 -> -charH * 0.12f + sin(t * 2.5f + e.seed) * 0.07f * charH
            else -> 0f
        }
    }

    private fun spawn() {
        val chest = chestPending && progress < 5
        if (chest) {
            chestPending = false
            chestEvery = Random.nextInt(3, 11)
        }
        val boss = chest || progress >= 5
        val bonus = !boss && lives < 5 && sinceBonus >= bonusEvery
        val kind = when {
            chest -> 8
            boss -> bossKind[biome]
            bonus -> 7
            else -> pool[biome].random()
        }
        val e = Enc(kind, bonus, boss)
        e.chest = chest
        var size = if (bonus) charH * 0.22f else kindSize[kind] * charH * (if (boss && !chest) 1.6f else 1f)
        if (!bonus) size = max(40f * s, min(size, footY - 175f * s))
        e.size = size
        if (boss) {
            e.hp = if (chest) 5 else 3
            e.maxHp = e.hp
        }
        setEquation(e)
        e.x = startXFor(e)
        e.y = hover(e, 0f)
        e.phase = 6
        enc = e
        if (chest) addPop("SKRZYNIA!", vw / 2f, 200f * s, 0xFFFFC107.toInt(), 34f)
        else if (boss) addPop("BOSS!", vw / 2f, 200f * s, 0xFFFF5252.toInt(), 34f)
    }

    private fun impactCols(): IntArray {
        val c1 = Art.tierColor(tier)
        return intArrayOf(c1, 0xFFFFFFFF.toInt(), c1, 0xFFE0E0E0.toInt())
    }

    private fun correct(e: Enc) {
        lastEq = eqText(e, e.answer.toString())
        lastOk = true
        if (e.bonus) {
            if (lives < 5) lives++
            sinceBonus = 0
            bonusEvery = Random.nextInt(5, 9)
            e.phase = 4
            burst(heroX, footY - charH * 0.6f, 20, intArrayOf(0xFFFF5252.toInt(), 0xFFFF80AB.toInt(), 0xFFFFFFFF.toInt()), 150f * s)
            addPop("+1 ♥", heroX, footY - charH * 1.2f, 0xFFFF5252.toInt(), 26f)
        } else {
            attackT = 0.35f
            launched = false
            e.phase = 2
        }
    }

    private fun fail(e: Enc) {
        lastEq = eqText(e, e.answer.toString())
        lastOk = false
        input = ""
        if (e.bonus) {
            e.phase = 4
            addPop("Ucieka...", e.x, footY - charH * 1.0f, 0xFF90A4AE.toInt(), 20f)
        } else {
            e.phase = 1
        }
    }

    private fun launch(e: Enc) {
        val mx = Art.muzzleX(heroX, charH)
        val my = Art.muzzleY(footY, charH)
        val tx = e.x - e.size * 0.25f
        val ty = footY + e.y - e.size * 0.45f
        val dx = tx - mx
        val dy = ty - my
        val len = max(1f, sqrt(dx * dx + dy * dy))
        val sp = 1500f * s
        val ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        proj = Proj(mx, my, dx / len * sp, dy / len * sp, tx, ang)
        launched = true
    }

    private fun impact(e: Enc) {
        proj = null
        val cy = footY + e.y - e.size * 0.45f
        burst(e.x - e.size * 0.2f, cy, 18, impactCols(), 180f * s)
        if (e.boss) {
            score++
            if (e.hp > 1) {
                e.hp--
                e.flash = 0.4f
                addPop("Trafiony!", e.x, cy - e.size * 0.5f, 0xFFFFD54F.toInt(), 24f)
                e.phase = 5
            } else {
                e.hp = 0
                score += 4
                addPop("+5", e.x, cy - e.size * 0.5f, 0xFFFFD54F.toInt(), 30f)
                kill(e)
            }
        } else {
            score++
            progress++
            addPop("+1", e.x, cy - e.size * 0.4f, 0xFFFFD54F.toInt(), 24f)
            kill(e)
        }
    }

    private fun kill(e: Enc) {
        e.phase = 3
        e.timer = 0.6f
        val cy = footY + e.y - e.size * 0.4f
        burst(e.x, cy, if (e.boss) 50 else 22, intArrayOf(0xFF9E9E9E.toInt(), 0xFFBDBDBD.toInt(), Art.tierColor(tier), 0xFFFFFFFF.toInt()), if (e.boss) 260f * s else 150f * s)
    }

    private fun levelUp() {
        level++
        bossesSinceChest++
        if (bossesSinceChest >= chestEvery) {
            bossesSinceChest = 0
            chestPending = true
        }
        progress = 0
        transT = 1f
        addPop("Poziom $level", vw / 2f, 200f * s, 0xFFFFD54F.toInt(), 34f)
        addPop(biomeNames[biome], vw / 2f, 228f * s, 0xFFFFFFFF.toInt(), 20f)
        if (level % 5 == 0) {
            addPop("Nowa broń: " + Art.weaponName(character, tier) + "!", vw / 2f, 262f * s, Art.tierColor(tier), 22f)
            burst(heroX, footY - charH * 0.6f, 40, intArrayOf(Art.tierColor(tier), 0xFFFFFFFF.toInt()), 260f * s)
        }
    }

    private fun startChoice() {
        val pool = (0 until Art.ITEM_COUNT).filter { gear[Art.itemSlot(it)] != it }.shuffled()
        val picked = ArrayList<Int>()
        for (id in pool) {
            if (picked.size < 3 && picked.none { Art.itemSlot(it) == Art.itemSlot(id) }) picked.add(id)
        }
        for (id in pool) {
            if (picked.size < 3 && id !in picked) picked.add(id)
        }
        for (id in (0 until Art.ITEM_COUNT).shuffled()) {
            if (picked.size < 3 && id !in picked) picked.add(id)
        }
        offers = picked.toIntArray()
        choosing = true
        input = ""
    }

    private fun cardTop(i: Int): Float {
        val total = 3 * 120f * s + 2 * 12f * s
        return (vh - total) / 2f + 24f * s + i * 132f * s
    }

    private fun pickItem(i: Int) {
        val id = offers[i]
        gear[Art.itemSlot(id)] = id
        choosing = false
        for (k in 0 until 3) {
            if (k != i) burst(vw / 2f, cardTop(k) + 60f * s, 14, intArrayOf(0xFF9E9E9E.toInt(), 0xFFFFFFFF.toInt()), 160f * s)
        }
        burst(heroX, footY - charH * 0.6f, 36, intArrayOf(0xFFFFD54F.toInt(), 0xFFFFFFFF.toInt()), 220f * s)
        addPop(Art.itemName(id) + "!", heroX, footY - charH * 1.25f, 0xFFFFD54F.toInt(), 24f)
        spawnDelay = 1.2f
    }

    private fun drawChoice(c: Canvas) {
        c.drawRect(0f, 0f, vw, vh, fillP(0xCC0B0716.toInt()))
        textP.textAlign = Paint.Align.CENTER
        textP.color = 0xFFFFD54F.toInt()
        textP.textSize = 22f * s
        c.drawText("Wybierz nagrodę", vw / 2f, cardTop(0) - 14f * s, textP)
        for (i in 0 until offers.size) {
            val id = offers[i]
            val top = cardTop(i)
            rect.set(24f * s, top, vw - 24f * s, top + 120f * s)
            c.drawRoundRect(rect, 16f * s, 16f * s, fillP(0xFF1E1633.toInt()))
            c.drawRoundRect(rect, 16f * s, 16f * s, strokeP(0xFFC9A227.toInt(), 3f * s))
            val only = IntArray(6) { -1 }
            only[Art.itemSlot(id)] = id
            Art.drawHero(c, character, 24f * s + 62f * s, top + 112f * s, 96f * s, 0f, 0f, 0, 0f, only)
            textP.textAlign = Paint.Align.LEFT
            textP.color = 0xFFF5E6C8.toInt()
            textP.textSize = 19f * s
            c.drawText(Art.itemName(id), 24f * s + 132f * s, top + 56f * s, textP)
            textP.color = 0xFF9FA8DA.toInt()
            textP.textSize = 14f * s
            c.drawText(Art.slotName(Art.itemSlot(id)), 24f * s + 132f * s, top + 82f * s, textP)
        }
        textP.textAlign = Paint.Align.CENTER
    }

    private fun hit(e: Enc) {
        lives = max(0, lives - 1)
        shake = 0.45f
        hitBlink = 0.9f
        flash = 0.7f
        burst(
            heroX + charH * 0.1f, footY - charH * 0.5f, 16,
            intArrayOf(0xFFE53935.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt()), 150f * s
        )
        addPop("-1 ♥", heroX, footY - charH * 1.2f, 0xFFE53935.toInt(), 26f)
        spawnDelay = 1.2f
        if (lives <= 0) {
            over = true
            overTimer = 1.5f
            enc = null
            return
        }
        if (e.boss) {
            e.phase = 5
        } else {
            burst(e.x, footY + e.y - e.size * 0.4f, 12, intArrayOf(0xFF9E9E9E.toInt(), 0xFFBDBDBD.toInt()), 120f * s)
            enc = null
        }
    }

    private fun burst(x: Float, y: Float, n: Int, colors: IntArray, speed: Float) {
        repeat(n) {
            val ang = Random.nextFloat() * 6.2832f
            val sp = speed * (0.3f + Random.nextFloat())
            val life = 0.5f + Random.nextFloat() * 0.6f
            parts.add(
                Spark(x, y, cos(ang) * sp, sin(ang) * sp, life, life, colors.random(), (2.5f + Random.nextFloat() * 3.5f) * s)
            )
        }
    }

    private fun addPop(text: String, x: Float, y: Float, color: Int, size: Float) {
        pops.add(Pop(text, x, y, 1.6f, color, size))
    }

    private fun step(dt: Float) {
        t += dt
        shake = max(0f, shake - dt)
        hitBlink = max(0f, hitBlink - dt)
        flash = max(0f, flash - dt * 1.5f)
        transT = max(0f, transT - dt * 1.1f)
        val engagedEnc = enc
        val engaged = choosing || (engagedEnc != null && !engagedEnc.bonus &&
            (engagedEnc.phase == 0 || engagedEnc.phase == 1 || engagedEnc.phase == 2 || engagedEnc.phase == 5))
        run += ((if (engaged) 0f else 1f) - run) * min(1f, dt * 3f)
        scroll += dt * run
        runPhase += dt * 10f * run

        for (p in parts) {
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 50f * s * dt
            p.life -= dt
        }
        parts.removeAll { it.life <= 0f }
        for (p in pops) {
            p.y -= 24f * s * dt
            p.life -= dt
        }
        pops.removeAll { it.life <= 0f }

        if (over) {
            overTimer -= dt
            if (overTimer <= 0f && !overFired) {
                overFired = true
                post { listener?.onGameOver(score) }
            }
        }

        // animacja ataku bohatera
        val cur = enc
        if (attackT > 0f) {
            attackT = max(0f, attackT - dt)
            if (!launched && attackT <= 0.12f && cur != null && cur.phase == 2) launch(cur)
        }
        // pocisk
        val pr = proj
        if (pr != null) {
            pr.x += pr.vx * dt
            pr.y += pr.vy * dt
            val tc = Art.tierColor(tier)
            parts.add(Spark(pr.x, pr.y, (Random.nextFloat() - 0.5f) * 30f * s, (Random.nextFloat() - 0.5f) * 30f * s, 0.35f, 0.35f, tc, 3f * s))
            if (tier == 1) {
                parts.add(Spark(pr.x, pr.y, 0f, -40f * s, 0.4f, 0.4f, 0xFFFFEB3B.toInt(), 2.5f * s))
            }
            if (cur != null && cur.phase == 2 && pr.x >= pr.tx) impact(cur)
            else if (cur == null) proj = null
        }

        val e = enc
        if (e == null) {
            if (!over && !choosing) {
                spawnDelay -= dt
                if (spawnDelay <= 0f) spawn()
            }
        } else {
            stepEnc(e, dt)
        }
    }

    private fun stepEnc(e: Enc, dt: Float) {
        e.flash = max(0f, e.flash - dt)
        val flying = e.kind == 2 || e.kind == 4 || e.kind == 5 || e.bonus
        val rate = when {
            flying -> 8f
            e.phase == 0 -> max(2.8f, min(12f, ((visXFor(e) - hitXFor(e)) / e.total) / (e.size * 0.09f)))
            e.phase == 1 -> 14f
            e.phase == 6 -> 12f
            e.phase == 4 || e.phase == 5 -> -9f
            else -> 0f
        }
        e.walk += rate * dt
        when (e.phase) {
            6 -> {
                e.x -= 450f * s * dt
                e.y = hover(e, 0f)
                if (e.x <= visXFor(e)) {
                    e.x = visXFor(e)
                    e.phase = 0
                }
            }
            0 -> {
                e.left -= dt
                val f = 1f - (e.left / e.total).coerceIn(0f, 1f)
                val sx = visXFor(e)
                e.x = sx + (hitXFor(e) - sx) * f
                e.y = hover(e, f)
                if (e.left <= 0f) fail(e)
            }
            1 -> {
                e.x -= 900f * s * dt
                if (e.x <= hitXFor(e)) hit(e)
            }
            3 -> {
                e.timer -= dt
                e.x += 50f * s * dt
                if (e.timer <= 0f) {
                    enc = null
                    spawnDelay = 0.9f
                    if (e.chest) startChoice() else if (e.boss) levelUp()
                }
            }
            4 -> {
                e.x += 200f * s * dt
                e.y -= 130f * s * dt
                if (e.x > vw + e.size) {
                    enc = null
                    spawnDelay = 0.9f
                }
            }
            5 -> {
                e.x += 330f * s * dt
                if (e.x >= visXFor(e)) {
                    setEquation(e)
                    e.phase = 0
                }
            }
        }
    }

    // ---------- rysowanie ----------

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNs == 0L) 0f else ((now - lastNs) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNs = now
        if (paused) dt = 0f
        step(dt)

        canvas.save()
        if (shake > 0f) {
            canvas.translate((Random.nextFloat() - 0.5f) * 10f * s, (Random.nextFloat() - 0.5f) * 6f * s)
        }
        drawScene(canvas)
        drawActors(canvas)
        canvas.restore()
        paint.reset()
        paint.shader = vignette
        canvas.drawRect(0f, 0f, vw, vh, paint)
        paint.shader = null
        if (transT > 0f) {
            val a = (transT.coerceIn(0f, 1f) * 255).toInt()
            canvas.drawRect(0f, 0f, vw, vh, fillP(a shl 24))
        }
        drawHud(canvas)

        postInvalidateOnAnimation()
    }

    private fun fillP(color: Int): Paint {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = color
        return paint
    }

    private fun strokeP(color: Int, w: Float): Paint {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = w
        paint.color = color
        return paint
    }

    private fun wrap(v: Float, m: Float): Float = ((v % m) + m) % m
    private fun frac(v: Float): Float = v - floor(v)

    private fun hills(c: Canvas, base: Float, amp: Float, period: Float, off: Float, color: Int) {
        path.reset()
        path.moveTo(0f, vh)
        var x = 0f
        while (x <= vw + 12f * s) {
            path.lineTo(x, base + amp * sin((x + off) / period * 6.2832f))
            x += 12f * s
        }
        path.lineTo(vw + 12f * s, vh)
        path.close()
        c.drawPath(path, fillP(color))
    }

    private fun pines(c: Canvas, spacing: Float, speed: Float, hgt: Float, baseY: Float, color: Int) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 37) % 30) * s
            val hh = hgt * s * (0.8f + ((k * 53) % 40) / 100f)
            fillP(color)
            for (i in 0..2) {
                val w = hh * (0.30f + 0.08f * (2 - i))
                val top = baseY - hh + i * hh * 0.28f
                val bot = top + hh * 0.45f
                path.reset()
                path.moveTo(x, top)
                path.lineTo(x - w, bot)
                path.lineTo(x + w, bot)
                path.close()
                c.drawPath(path, paint)
            }
            c.drawRect(x - hh * 0.04f, baseY - hh * 0.12f, x + hh * 0.04f, baseY, paint)
        }
    }

    private fun peaks(c: Canvas, spacing: Float, speed: Float, hgt: Float, baseY: Float, color: Int, cap: Int) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 41) % 40) * s
            val hh = hgt * s * (0.75f + ((k * 57) % 50) / 100f)
            val w = hh * 0.9f
            path.reset()
            path.moveTo(x - w, baseY)
            path.lineTo(x, baseY - hh)
            path.lineTo(x + w, baseY)
            path.close()
            c.drawPath(path, fillP(color))
            if (cap != 0) {
                path.reset()
                path.moveTo(x - w * 0.3f, baseY - hh * 0.7f)
                path.lineTo(x, baseY - hh)
                path.lineTo(x + w * 0.3f, baseY - hh * 0.7f)
                path.lineTo(x + w * 0.1f, baseY - hh * 0.76f)
                path.lineTo(x - w * 0.05f, baseY - hh * 0.66f)
                path.lineTo(x - w * 0.18f, baseY - hh * 0.74f)
                path.close()
                c.drawPath(path, fillP(cap))
            }
        }
    }

    private fun pillars(c: Canvas, spacing: Float, speed: Float, baseY: Float, color: Int) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 31) % 60) * s
            val hh = (60 + (k * 47) % 60) * s
            fillP(color)
            c.drawRect(x - 9f * s, baseY - hh, x + 9f * s, baseY, paint)
            c.drawRect(x - 14f * s, baseY - hh - 7f * s, x + 14f * s, baseY - hh, paint)
            c.drawRect(x - 13f * s, baseY - 6f * s, x + 13f * s, baseY, paint)
            if (k % 2 == 0) c.drawRect(x + 18f * s, baseY - hh * 0.5f, x + 34f * s, baseY, paint)
        }
    }

    private fun deadTrees(c: Canvas, spacing: Float, speed: Float, baseY: Float, color: Int) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 43) % 50) * s
            val hh = (80 + (k * 29) % 50) * s
            strokeP(color, 7f * s)
            c.drawLine(x, baseY, x + 8f * s, baseY - hh, paint)
            paint.strokeWidth = 4f * s
            c.drawLine(x + 5f * s, baseY - hh * 0.55f, x - 24f * s, baseY - hh * 0.8f, paint)
            c.drawLine(x + 7f * s, baseY - hh * 0.75f, x + 34f * s, baseY - hh * 0.95f, paint)
            c.drawLine(x + 8f * s, baseY - hh, x - 8f * s, baseY - hh - 20f * s, paint)
        }
    }

    private fun crystals(c: Canvas, spacing: Float, speed: Float, baseY: Float, hgt: Float) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 37) % 50) * s
            val ch = hgt * s * (0.6f + ((k * 59) % 50) / 100f)
            val cw = ch * 0.3f
            val col = if (k % 2 == 0) 0xCC4DD0E1.toInt() else 0xCCB388FF.toInt()
            path.reset()
            path.moveTo(x, baseY - ch)
            path.lineTo(x + cw, baseY - ch * 0.35f)
            path.lineTo(x + cw * 0.5f, baseY)
            path.lineTo(x - cw * 0.5f, baseY)
            path.lineTo(x - cw, baseY - ch * 0.35f)
            path.close()
            c.drawPath(path, fillP(col))
            c.drawLine(x, baseY - ch, x - cw * 0.2f, baseY, strokeP(0x88FFFFFF.toInt(), 1.5f * s))
        }
    }

    private fun stalactites(c: Canvas, spacing: Float, speed: Float, color: Int) {
        val sp = spacing * s
        val sc = scroll * speed * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 23) % 40) * s
            val hh = (50 + (k * 61) % 60) * s
            val w = hh * 0.22f
            path.reset()
            path.moveTo(x - w, 0f)
            path.lineTo(x + w, 0f)
            path.lineTo(x, hh + 150f * s)
            path.close()
            c.drawPath(path, fillP(color))
        }
    }

    private fun ambient(c: Canvas, n: Int, color: Int, vx: Float, vy: Float, size: Float) {
        for (i in 0 until n) {
            val rx = frac(sin(i * 12.9898f) * 43758.5453f)
            val ry = frac(sin(i * 78.233f) * 12345.678f)
            val x = wrap(rx * vw + t * vx * s, vw)
            val y = wrap(ry * vh + t * vy * s, vh)
            c.drawCircle(x, y, size * s * (0.5f + rx), fillP(color))
        }
    }

    private fun drawScene(c: Canvas) {
        val b = biome
        val fy = footY
        paint.reset()
        paint.shader = skies?.get(b)
        c.drawRect(0f, 0f, vw, vh, paint)
        paint.shader = null

        when (b) {
            0 -> {
                c.drawCircle(vw * 0.8f, 215f * s, 34f * s, fillP(0x22E8EAF6))
                c.drawCircle(vw * 0.8f, 215f * s, 20f * s, fillP(0xFFE8EAF6.toInt()))
                hills(c, fy - 60f * s, 20f * s, 260f * s, scroll * 12f * s, farCol[0])
                pines(c, 80f, 22f, 110f, fy - 25f * s, 0xFF0F2622.toInt())
                pines(c, 110f, 55f, 150f, fy - 6f * s, nearCol[0])
            }
            1 -> {
                c.drawCircle(vw * 0.25f, 210f * s, 22f * s, fillP(0x55FFFFFF))
                peaks(c, 230f, 10f, 160f, fy - 40f * s, farCol[1], 0xFFFFFFFF.toInt())
                peaks(c, 170f, 28f, 105f, fy - 12f * s, nearCol[1], 0xFFFFFFFF.toInt())
            }
            2 -> {
                c.drawCircle(vw * 0.28f, 225f * s, 56f * s, fillP(0x33FFB74D))
                c.drawCircle(vw * 0.28f, 225f * s, 38f * s, fillP(0xFFFFB74D.toInt()))
                hills(c, fy - 50f * s, 22f * s, 280f * s, scroll * 10f * s, farCol[2])
                pillars(c, 260f, 45f, fy - 22f * s, 0xFF7A4A2A.toInt())
                hills(c, fy - 22f * s, 12f * s, 190f * s, scroll * 38f * s, nearCol[2])
            }
            3 -> {
                c.drawCircle(vw * 0.7f, 220f * s, 24f * s, fillP(0x33C5E1A5))
                hills(c, fy - 55f * s, 16f * s, 240f * s, scroll * 12f * s, farCol[3])
                deadTrees(c, 190f, 40f, fy - 8f * s, 0xFF14201A.toInt())
                c.drawRect(0f, fy - 70f * s, vw, fy, fillP(0x2290A89A))
            }
            4 -> {
                c.drawCircle(vw * 0.6f, fy - 60f * s, 130f * s, fillP(0x33FF5722))
                peaks(c, 320f, 9f, 175f, fy - 30f * s, farCol[4], 0xFFFF6D00.toInt())
                hills(c, fy - 22f * s, 12f * s, 200f * s, scroll * 34f * s, nearCol[4])
            }
            else -> {
                stalactites(c, 130f, 18f, 0xFF1A1235.toInt())
                hills(c, fy - 50f * s, 16f * s, 250f * s, scroll * 12f * s, farCol[5])
                crystals(c, 170f, 35f, fy - 10f * s, 120f)
            }
        }

        // mgła przy horyzoncie
        paint.reset()
        paint.shader = fogShaders?.get(b)
        c.drawRect(0f, fy - 110f * s, vw, fy - 4f * s, paint)
        paint.shader = null

        // ziemia
        c.drawRect(0f, fy - 10f * s, vw, vh, fillP(groundCol[b]))
        c.drawRect(0f, fy - 10f * s, vw, fy - 4f * s, fillP(groundTop[b]))
        paint.reset()
        paint.shader = groundShade
        c.drawRect(0f, fy - 10f * s, vw, vh, paint)
        paint.shader = null

        // elementy na pierwszym planie (najszybsze)
        val sp = 85f * s
        val sc = scroll * 120f * s
        val k0 = floor(sc / sp).toInt()
        for (k in k0..k0 + (vw / sp).toInt() + 2) {
            val x = k * sp - sc + ((k * 29) % 40) * s
            val y = fy + (12 + (k * 13) % 24) * s
            when (b) {
                0, 3 -> {
                    strokeP(if (b == 0) 0xFF3E7B43.toInt() else 0xFF4C6A3A.toInt(), 2.5f * s)
                    c.drawLine(x, y, x - 5f * s, y - 12f * s, paint)
                    c.drawLine(x, y, x, y - 15f * s, paint)
                    c.drawLine(x, y, x + 5f * s, y - 12f * s, paint)
                }
                1 -> c.drawOval(RectF(x - 14f * s, y - 6f * s, x + 14f * s, y + 3f * s), fillP(0xFFFFFFFF.toInt()))
                2 -> c.drawOval(RectF(x - 9f * s, y - 7f * s, x + 9f * s, y + 2f * s), fillP(0xFF8D6E4A.toInt()))
                4 -> {
                    strokeP(0xFFFF6D00.toInt(), 2f * s)
                    c.drawLine(x - 10f * s, y, x, y - 4f * s, paint)
                    c.drawLine(x, y - 4f * s, x + 10f * s, y + 1f * s, paint)
                }
                else -> {
                    tri(c, x, y - 14f * s, x + 6f * s, y, x - 6f * s, y, 0xCC80DEEA.toInt())
                }
            }
        }

        // cząsteczki w powietrzu
        when (b) {
            0 -> ambient(c, 10, 0xAACDDC39.toInt(), 6f, 3f, 1.8f)
            1 -> ambient(c, 40, 0xCCFFFFFF.toInt(), -25f, 45f, 1.8f)
            2 -> ambient(c, 14, 0x55FFE0B2, -60f, 6f, 1.6f)
            3 -> ambient(c, 14, 0xCCC6FF00.toInt(), 5f, -4f, 2f)
            4 -> ambient(c, 28, 0xCCFF9100.toInt(), -12f, -45f, 1.8f)
            else -> ambient(c, 22, 0xAA80DEEA.toInt(), 4f, -6f, 1.8f)
        }
    }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, color: Int) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.close()
        c.drawPath(path, fillP(color))
    }

    private fun drawActors(c: Canvas) {
        val fy = footY

        // cienie i aura
        c.drawOval(RectF(heroX - charH * 0.3f, fy - 4f * s, heroX + charH * 0.3f, fy + 5f * s), fillP(0x66000000))
        val shEnc = enc
        if (shEnc != null && !shEnc.bonus) {
            val sw2 = shEnc.size * 0.4f
            c.drawOval(RectF(shEnc.x - sw2, fy - 4f * s, shEnc.x + sw2, fy + 5f * s), fillP(0x55000000))
        }
        if (tier > 0) {
            c.drawCircle(heroX, fy - charH * 0.5f, charH * 0.75f, fillP((Art.tierColor(tier) and 0x00FFFFFF) or 0x22000000))
        }

        // bohater
        if (hitBlink <= 0f || (hitBlink * 12f).toInt() % 2 == 0) {
            Art.drawHero(c, character, heroX, fy, charH, runPhase, attackT / 0.35f, tier, run, gear)
        }

        // potwór
        val e = enc
        if (e != null) {
            val blink = e.flash > 0f && (e.flash * 14f).toInt() % 2 == 0
            if (!blink) {
                if (e.bonus) {
                    Art.drawWisp(c, e.x, fy + e.y, e.size, t * 6f)
                } else {
                    val alpha = if (e.phase == 3) (255 * (e.timer / 0.6f)).toInt().coerceIn(0, 255) else 255
                    if (alpha < 255) c.saveLayerAlpha(0f, 0f, vw, vh, alpha)
                    Art.drawMonster(c, e.kind, e.x, fy + e.y, e.size, e.walk, e.boss && !e.chest)
                    if (alpha < 255) c.restore()
                }
            }
            if (e.boss && e.phase != 3) {
                val top = fy + e.y - e.size - 14f * s
                for (i in 0 until e.maxHp) {
                    val cx = e.x + (i - (e.maxHp - 1) / 2f) * 18f * s
                    c.drawCircle(cx, top, 6f * s, fillP(if (i < e.hp) 0xFFE53935.toInt() else 0xFF455A64.toInt()))
                }
            }
        }

        // pocisk
        val pr = proj
        if (pr != null) {
            Art.drawProjectile(c, character, pr.x, pr.y, charH, t, tier, pr.angle)
        }

        // cząsteczki
        for (p in parts) {
            val a = (255 * (p.life / p.maxLife).coerceIn(0f, 1f)).toInt()
            val col = (p.color and 0x00FFFFFF) or (a shl 24)
            c.drawCircle(p.x, p.y, p.size, fillP(col))
        }

        // napisy
        textP.textAlign = Paint.Align.CENTER
        textP.setShadowLayer(4f * s, 0f, 1f * s, 0xFF000000.toInt())
        for (p in pops) {
            val a = (255 * (p.life / 0.6f).coerceIn(0f, 1f)).toInt()
            textP.color = (p.color and 0x00FFFFFF) or (a shl 24)
            textP.textSize = p.size * s
            c.drawText(p.text, p.x, p.y, textP)
        }
        textP.clearShadowLayer()
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, r: Float, pt: Paint) {
        path.reset()
        path.moveTo(cx, cy + r * 0.9f)
        path.cubicTo(cx - r * 1.6f, cy - r * 0.1f, cx - r * 0.8f, cy - r * 1.3f, cx, cy - r * 0.4f)
        path.cubicTo(cx + r * 0.8f, cy - r * 1.3f, cx + r * 1.6f, cy - r * 0.1f, cx, cy + r * 0.9f)
        path.close()
        c.drawPath(path, pt)
    }

    private fun drawHud(c: Canvas) {
        val gold = 0xFFFFD54F.toInt()
        val e = enc

        // serca
        for (i in 0 until 5) {
            val cx = 22f * s + i * 27f * s
            if (i < lives) {
                heart(c, cx, 24f * s, 11f * s, fillP(0xFFE53935.toInt()))
            } else {
                heart(c, cx, 24f * s, 11f * s, strokeP(0xFF78909C.toInt(), 2f * s))
            }
        }

        textP.setShadowLayer(4f * s, 0f, 1f * s, 0xFF000000.toInt())
        // punkty
        textP.textAlign = Paint.Align.RIGHT
        textP.color = gold
        textP.textSize = 18f * s
        c.drawText("Punkty: $score", vw - 60f * s, 30f * s, textP)

        // poziom i kraina
        textP.textAlign = Paint.Align.CENTER
        textP.color = 0xFFFFFFFF.toInt()
        textP.textSize = 15f * s
        c.drawText("POZIOM $level  •  ${biomeNames[biome]}", vw / 2f, 56f * s, textP)
        textP.clearShadowLayer()

        // pasek postępu: 5 potworów + boss
        for (i in 0 until 5) {
            val cx = vw / 2f + (i - 2.5f) * 20f * s
            c.drawCircle(cx, 70f * s, 5f * s, fillP(if (i < progress) gold else 0x66FFFFFF))
        }
        c.drawCircle(vw / 2f + 3f * 20f * s, 70f * s, 7f * s, fillP(if (progress >= 5) 0xFFFF5252.toInt() else 0x88B71C1C.toInt()))

        // przycisk pauzy
        c.drawCircle(vw - 28f * s, 28f * s, 18f * s, fillP(0xCC1A1630.toInt()))
        c.drawCircle(vw - 28f * s, 28f * s, 18f * s, strokeP(gold, 2f * s))
        c.drawRect(vw - 34f * s, 20f * s, vw - 29f * s, 36f * s, fillP(gold))
        c.drawRect(vw - 25f * s, 20f * s, vw - 20f * s, 36f * s, paint)

        // tablica z równaniem
        val boss = if (lastEq != null) false else (e?.boss == true)
        val bonus = if (lastEq != null) false else (e?.bonus == true)
        val edge = when {
            boss -> 0xFFE53935.toInt()
            bonus -> 0xFF4FC3F7.toInt()
            else -> 0xFFC9A227.toInt()
        }
        rect.set(14f * s, 84f * s, vw - 14f * s, 144f * s)
        c.drawRoundRect(rect, 14f * s, 14f * s, fillP(0xE61A1423.toInt()))
        c.drawRoundRect(rect, 14f * s, 14f * s, strokeP(edge, 3f * s))

        val showBoss = e?.boss == true
        val showBonus = e?.bonus == true
        if (showBoss && e != null && e.chest) {
            textP.textAlign = Paint.Align.CENTER
            textP.textSize = 12f * s
            textP.color = 0xFFFFD54F.toInt()
            c.drawText("SKRZYNIA – zadanie ${e.maxHp - e.hp + 1} z ${e.maxHp} (czas x3)", vw / 2f, 99f * s, textP)
        } else if (showBoss && e != null) {
            textP.textAlign = Paint.Align.CENTER
            textP.textSize = 12f * s
            textP.color = 0xFFFF8A80.toInt()
            c.drawText("BOSS – zadanie ${e.maxHp - e.hp + 1} z ${e.maxHp} (czas x2)", vw / 2f, 99f * s, textP)
        } else if (showBonus) {
            textP.textAlign = Paint.Align.CENTER
            textP.textSize = 12f * s
            textP.color = 0xFF81D4FA.toInt()
            c.drawText("BONUS – odpowiedz, aby odzyskać życie", vw / 2f, 99f * s, textP)
        }

        val txt = lastEq ?: (if (e != null) eqText(e, if (input.isEmpty()) "?" else input) else "Przygotuj się...")
        val col = when {
            lastEq != null && lastOk -> 0xFF81C784.toInt()
            lastEq != null -> 0xFFEF5350.toInt()
            else -> 0xFFF5E6C8.toInt()
        }
        textP.textAlign = Paint.Align.CENTER
        textP.color = col
        textP.textSize = 32f * s
        val maxW = vw - 60f * s
        val wdt = textP.measureText(txt)
        if (wdt > maxW) textP.textSize = 32f * s * maxW / wdt
        c.drawText(txt, vw / 2f, 130f * s, textP)

        // pasek czasu
        rect.set(14f * s, 150f * s, vw - 14f * s, 160f * s)
        c.drawRoundRect(rect, 5f * s, 5f * s, fillP(0x66000000))
        if (e != null && e.phase == 0) {
            val f = (e.left / e.total).coerceIn(0f, 1f)
            rect.set(14f * s, 150f * s, 14f * s + (vw - 28f * s) * f, 160f * s)
            c.drawRoundRect(rect, 5f * s, 5f * s, fillP(Color.HSVToColor(floatArrayOf(120f * f, 0.75f, 0.95f))))
        }

        if (flash > 0f) {
            val a = (flash.coerceIn(0f, 1f) * 90).toInt()
            c.drawRect(0f, 0f, vw, vh, fillP((a shl 24) or 0xE53935))
        }

        if (choosing) drawChoice(c)

        if (paused) {
            c.drawRect(0f, 0f, vw, vh, fillP(0xAA000000.toInt()))
            textP.color = 0xFFFFFFFF.toInt()
            textP.textSize = 40f * s
            c.drawText("Pauza", vw / 2f, vh / 2f, textP)
            if (tapToResume) {
                textP.textSize = 18f * s
                c.drawText("Dotknij ekranu, aby grać dalej", vw / 2f, vh / 2f + 34f * s, textP)
            }
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) {
            if (paused) {
                if (tapToResume) {
                    tapToResume = false
                    paused = false
                }
                return true
            }
            if (choosing) {
                for (i in 0 until offers.size) {
                    if (ev.y >= cardTop(i) && ev.y <= cardTop(i) + 120f * s) {
                        pickItem(i)
                        break
                    }
                }
                return true
            }
            if (ev.x > vw - 56f * s && ev.y < 60f * s) listener?.onPauseRequested()
            return true
        }
        return super.onTouchEvent(ev)
    }
}
