package com.example.fairymath

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class GameSettings(
    val add: Boolean = true,
    val sub: Boolean = true,
    val mul: Boolean = false,
    val min: Int = 1,
    val max: Int = 20,
    val difficulty: Int = 1,
    val bossEvery: Int = 5,
    val chestNom: Int = 6,
    val chestSpread: Int = 1,
    val music: Boolean = true,
    val sfx: Boolean = true
)

data class SaveState(
    val character: Int,
    val score: Int,
    val lives: Int,
    val level: Int,
    val progress: Int,
    val gear: List<Int> = List(6) { -1 }
)

data class ScoreEntry(
    val score: Int,
    val date: String,
    val character: Int = -1,
    val level: Int = 1,
    val difficulty: Int = 1,
    val gear: List<Int> = List(6) { -1 }
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("krainyliczb", Context.MODE_PRIVATE)

    fun settings(c: Context): GameSettings {
        val sp = prefs(c)
        return GameSettings(
            sp.getBoolean("add", true),
            sp.getBoolean("sub", true),
            sp.getBoolean("mul", false),
            sp.getInt("min", 1),
            sp.getInt("max", 20),
            sp.getInt("diff", 1),
            sp.getInt("bossEvery", 5).coerceIn(1, 10),
            sp.getInt("chestNom", 6).coerceIn(1, 10),
            sp.getInt("chestSpread", 1).coerceIn(1, 5),
            sp.getBoolean("music", true),
            sp.getBoolean("sfx", true)
        )
    }

    fun saveSettings(c: Context, s: GameSettings) {
        prefs(c).edit()
            .putBoolean("add", s.add)
            .putBoolean("sub", s.sub)
            .putBoolean("mul", s.mul)
            .putInt("min", s.min)
            .putInt("max", s.max)
            .putInt("diff", s.difficulty)
            .putInt("bossEvery", s.bossEvery)
            .putInt("chestNom", s.chestNom)
            .putInt("chestSpread", s.chestSpread)
            .putBoolean("music", s.music)
            .putBoolean("sfx", s.sfx)
            .apply()
    }

    fun scores(c: Context): List<ScoreEntry> {
        val raw = prefs(c).getString("scores", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(";").mapNotNull { item ->
            val parts = item.split(",")
            val sc = parts.getOrNull(0)?.toIntOrNull()
            if (sc == null) {
                null
            } else {
                val g = (5 until 11).map { i -> parts.getOrNull(i)?.toIntOrNull() ?: -1 }
                ScoreEntry(
                    sc, parts.getOrNull(1) ?: "",
                    parts.getOrNull(2)?.toIntOrNull() ?: -1,
                    parts.getOrNull(3)?.toIntOrNull() ?: 1,
                    parts.getOrNull(4)?.toIntOrNull() ?: 1,
                    g
                )
            }
        }
    }

    fun best(c: Context): Int = scores(c).maxOfOrNull { it.score } ?: 0

    fun addScore(c: Context, e: ScoreEntry) {
        val date = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
        val list = (scores(c) + e.copy(date = date))
            .sortedByDescending { it.score }
            .take(5)
        prefs(c).edit()
            .putString("scores", list.joinToString(";") { "${it.score},${it.date},${it.character},${it.level},${it.difficulty},${it.gear.joinToString(",")}" })
            .apply()
    }

    fun saveGame(c: Context, s: SaveState) {
        prefs(c).edit()
            .putString("save", "${s.character},${s.score},${s.lives},${s.level},${s.progress},${s.gear.joinToString(",")}")
            .apply()
    }

    fun loadGame(c: Context): SaveState? {
        val raw = prefs(c).getString("save", null) ?: return null
        val p = raw.split(",").mapNotNull { it.toIntOrNull() }
        if (p.size != 5 && p.size != 11) return null
        val gr = if (p.size == 11) p.subList(5, 11).map { if (it in 0 until Art.ITEM_COUNT) it else -1 } else List(6) { -1 }
        return SaveState(p[0].coerceIn(0, 2), p[1], p[2].coerceIn(1, 5), p[3].coerceAtLeast(1), p[4].coerceIn(0, 10), gr)
    }

    fun clearGame(c: Context) {
        prefs(c).edit().remove("save").apply()
    }
}
