package com.example.fairymath

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

data class AbSettings(
    val add: Boolean = true,
    val sub: Boolean = true,
    val mul: Boolean = false,
    val min: Int = 1,
    val max: Int = 20,
    val difficulty: Int = 1
)

data class AbScore(val score: Int, val date: String, val level: Int, val difficulty: Int)

object AbacusStore {
    private fun prefs(c: Context) = c.getSharedPreferences("abacus", Context.MODE_PRIVATE)

    fun settings(c: Context): AbSettings {
        val sp = prefs(c)
        return AbSettings(
            sp.getBoolean("add", true),
            sp.getBoolean("sub", true),
            sp.getBoolean("mul", false),
            sp.getInt("min", 1),
            sp.getInt("max", 20),
            sp.getInt("diff", 1).coerceIn(0, 2)
        )
    }

    fun saveSettings(c: Context, s: AbSettings) {
        prefs(c).edit()
            .putBoolean("add", s.add)
            .putBoolean("sub", s.sub)
            .putBoolean("mul", s.mul)
            .putInt("min", s.min)
            .putInt("max", s.max)
            .putInt("diff", s.difficulty)
            .apply()
    }

    fun scores(c: Context): List<AbScore> {
        val raw = prefs(c).getString("scores", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(";").mapNotNull { item ->
            val p = item.split(",")
            val sc = p.getOrNull(0)?.toIntOrNull()
            if (sc == null) null else AbScore(sc, p.getOrNull(1) ?: "", p.getOrNull(2)?.toIntOrNull() ?: 1, p.getOrNull(3)?.toIntOrNull() ?: 1)
        }
    }

    fun best(c: Context): Int = scores(c).maxOfOrNull { it.score } ?: 0

    fun addScore(c: Context, e: AbScore) {
        val date = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
        val list = (scores(c) + e.copy(date = date)).sortedByDescending { it.score }.take(5)
        prefs(c).edit()
            .putString("scores", list.joinToString(";") { "${it.score},${it.date},${it.level},${it.difficulty}" })
            .apply()
    }
}

/**
 * Liczydło soroban: na każdym pręcie 1 koralik "niebiański" (wart 5) i 4 "ziemskie" (warte 1).
 * Koralik liczy się, gdy dotyka poprzeczki. Dotknij koralika, aby go przesunąć.
 */
class AbacusView(context: Context, private val cfg: AbSettings) : View(context) {

    interface Listener {
        fun onGameOver(score: Int, level: Int)
        fun onPauseRequested()
    }

    var listener: Listener? = null
    var paused = false
    var tapToResume = false

    var score = 0
        private set
    var level = 1
        private set
    var lives = 5
        private set
    val difficulty: Int get() = cfg.difficulty

    private var solved = 0
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rc = RectF()

    private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val color: Int, val size: Float)
    private class Pop(val text: String, var x: Float, var y: Float, var life: Float, val color: Int, val size: Float)

    private val parts = ArrayList<Part>()
    private val pops = ArrayList<Pop>()

    // zadanie
    private var a = 0
    private var b = 0
    private var op = 0
    private var answer = 0
    private var startVal = 0
    private var rods = 2
    private val e = IntArray(4)
    private val hv = IntArray(4)
    private val ep = Array(4) { FloatArray(4) }
    private val hp = FloatArray(4)
    private var timeTotal = 40f
    private var timeLeft = 40f
    private var tries = 0
    private var phase = 0 // 0 rozwiązuje, 1 sukces, 2 pokazanie wyniku
    private var phaseT = 0f
    private var overFired = false

    private var t = 0f
    private var lastNs = 0L
    private var owlJump = 0f
    private var owlShake = 0f

    // układ
    private var frameL = 0f
    private var frameR = 0f
    private var frameT = 0f
    private var frameB = 0f
    private var innerL = 0f
    private var innerR = 0f
    private var innerT = 0f
    private var innerB = 0f
    private var beamY = 0f
    private var spacing = 1f
    private var bw = 10f
    private var bh = 10f
    private val btnClear = RectF()
    private val btnCheck = RectF()

    private val placeColors = intArrayOf(0xFF29B6F6.toInt(), 0xFF66BB6A.toInt(), 0xFFFFA726.toInt(), 0xFFAB47BC.toInt())
    private val placeNames = arrayOf("jedności", "dziesiątki", "setki", "tysiące")

    init {
        newTask()
    }

    // ---------- logika ----------

    private fun digits(v: Int): Int = v.toString().length

    private fun value(): Int {
        var v = 0
        for (i in 0 until rods) v = v * 10 + hv[i] * 5 + e[i]
        return v
    }

    private fun setValue(v0: Int) {
        var x = v0
        for (i in 0 until 4) {
            hv[i] = 0
            e[i] = 0
        }
        for (i in rods - 1 downTo 0) {
            val dg = x % 10
            x /= 10
            hv[i] = if (dg >= 5) 1 else 0
            e[i] = dg % 5
        }
    }

    private fun snap() {
        for (r in 0 until 4) {
            hp[r] = hv[r].toFloat()
            for (i in 0 until 4) ep[r][i] = if (i < e[r]) 1f else 0f
        }
    }

    private fun newTask() {
        val ops = ArrayList<Int>()
        if (cfg.add) ops.add(0)
        if (cfg.sub) ops.add(1)
        if (cfg.mul) ops.add(2)
        if (ops.isEmpty()) ops.add(0)
        op = ops.random()
        val lo = cfg.min
        var hi = min(cfg.max + (level - 1) * 2, 100)
        if (hi <= lo) hi = lo + 1
        if (op == 2) {
            val mhi = min(hi, min(12, 4 + level))
            val mlo = max(2, min(lo, mhi - 1))
            a = Random.nextInt(mlo, mhi + 1)
            b = Random.nextInt(mlo, mhi + 1)
            answer = a * b
        } else {
            a = Random.nextInt(lo, hi + 1)
            b = Random.nextInt(lo, hi + 1)
            if (op == 1 && b > a) {
                val tmp = a
                a = b
                b = tmp
            }
            answer = if (op == 0) a + b else a - b
        }
        rods = max(2, min(4, digits(max(max(a, b), answer))))
        startVal = if (op == 2 || cfg.difficulty == 2) 0 else a
        setValue(startVal)
        snap()
        timeTotal = when (cfg.difficulty) {
            0 -> 60f
            1 -> 40f
            else -> 30f
        }
        timeLeft = timeTotal
        tries = 0
        phase = 0
        phaseT = 0f
    }

    private fun sym() = when (op) {
        0 -> "+"
        1 -> "−"
        else -> "×"
    }

    private fun hintText(): String = when {
        op == 2 -> "Ustaw wynik: $a × $b"
        startVal == 0 -> "Ustaw $a, potem " + (if (op == 0) "dodaj $b" else "odejmij $b")
        op == 0 -> "Zaczynasz od $a – dodaj $b"
        else -> "Zaczynasz od $a – odejmij $b"
    }

    private fun confetti(x: Float, y: Float, n: Int) {
        val cols = intArrayOf(0xFFFFD54F.toInt(), 0xFFFFFFFF.toInt(), 0xFF4DD0E1.toInt(), 0xFFB39DDB.toInt(), 0xFFFFD54F.toInt(), 0xFFFF8A65.toInt())
        for (i in 0 until n) {
            parts.add(
                Part(
                    x, y, (Random.nextFloat() - 0.5f) * 520f * d, -Random.nextFloat() * 420f * d - 80f * d,
                    1.4f + Random.nextFloat() * 0.8f, cols.random(), (4f + Random.nextFloat() * 4f) * d
                )
            )
        }
    }

    private fun pop(text: String, x: Float, y: Float, color: Int, size: Float) {
        pops.add(Pop(text, x, y, 1.6f, color, size))
    }

    private fun check() {
        if (phase != 0 || paused) return
        if (value() == answer) {
            val mult = cfg.difficulty + 1
            val pts = max(1, 10 * level * mult / (tries + 1))
            score += pts
            solved++
            phase = 1
            phaseT = 1.6f
            owlJump = 1.0f
            confetti(width / 2f, (frameT + frameB) / 2f, 50)
            pop("+$pts", width / 2f, 130f * d, 0xFFFFD740.toInt(), 30f)
            if (solved >= 5) {
                solved = 0
                level++
                Sound.play(Sound.LEVEL)
                pop("Poziom $level!", width / 2f, 200f * d, 0xFFFFFFFF.toInt(), 30f)
            } else {
                Sound.play(Sound.HEAL)
            }
        } else {
            tries++
            owlShake = 0.7f
            Sound.play(Sound.WRONG)
            if (tries >= 3) {
                fail("Poprawny wynik: $answer")
            } else {
                pop("Spróbuj jeszcze raz!", width / 2f, 130f * d, 0xFFFF7043.toInt(), 24f)
            }
        }
    }

    private fun fail(msg: String) {
        lives = max(0, lives - 1)
        setValue(answer)
        phase = 2
        phaseT = 2.8f
        owlShake = 0.7f
        Sound.play(Sound.WRONG)
        pop(msg, width / 2f, 130f * d, 0xFFFF7043.toInt(), 22f)
    }

    private fun step(dt: Float) {
        t += dt
        val k = min(1f, dt * 14f)
        for (r in 0 until 4) {
            hp[r] += (hv[r].toFloat() - hp[r]) * k
            for (i in 0 until 4) {
                val tg = if (i < e[r]) 1f else 0f
                ep[r][i] += (tg - ep[r][i]) * k
            }
        }
        owlJump = max(0f, owlJump - dt)
        owlShake = max(0f, owlShake - dt)
        for (q in parts) {
            q.x += q.vx * dt
            q.y += q.vy * dt
            q.vy += 700f * d * dt
            q.life -= dt
        }
        parts.removeAll { it.life <= 0f }
        for (q in pops) {
            q.y -= 22f * d * dt
            q.life -= dt
        }
        pops.removeAll { it.life <= 0f }

        if (phase == 0) {
            timeLeft -= dt
            if (timeLeft <= 0f) {
                timeLeft = 0f
                fail("Czas minął! Wynik: $answer")
            }
        } else {
            phaseT -= dt
            if (phaseT <= 0f) {
                if (lives <= 0) {
                    if (!overFired) {
                        overFired = true
                        post { listener?.onGameOver(score, level) }
                    }
                } else {
                    newTask()
                }
            }
        }
    }

    // ---------- układ i dotyk ----------

    private fun layout() {
        val w = width.toFloat()
        val h = height.toFloat()
        frameL = 12f * d
        frameR = w - 12f * d
        frameT = 236f * d
        frameB = min(h - 150f * d, frameT + 330f * d)
        if (frameB < frameT + 200f * d) frameB = frameT + 200f * d
        val ins = 12f * d
        innerL = frameL + ins
        innerR = frameR - ins
        innerT = frameT + ins
        innerB = frameB - ins
        beamY = innerT + (innerB - innerT) * 0.31f
        spacing = (innerR - innerL) / rods
        bh = min(min((innerB - beamY - 8f * d) / 5.3f, (beamY - innerT) / 1.9f), 40f * d)
        bw = min(spacing * 0.78f, 78f * d)
        btnClear.set(14f * d, h - 84f * d, w * 0.36f, h - 24f * d)
        btnCheck.set(w * 0.40f, h - 84f * d, w - 14f * d, h - 24f * d)
    }

    private fun rodX(i: Int): Float = innerL + (i + 0.5f) * spacing

    private fun earthY(r: Int, i: Int): Float {
        val inactive = innerB - bh / 2f - 3f * d - (3 - i) * bh
        val active = beamY + 5f * d + bh / 2f + i * bh
        return inactive + (active - inactive) * ep[r][i]
    }

    private fun heavenY(r: Int): Float {
        val inactive = innerT + bh / 2f + 3f * d
        val active = beamY - 5f * d - bh / 2f
        return inactive + (active - inactive) * hp[r]
    }

    private fun tapBeads(x: Float, y: Float) {
        if (y < innerT || y > innerB) return
        val r = ((x - innerL) / spacing).toInt()
        if (r < 0 || r >= rods) return
        if (y < beamY) {
            hv[r] = 1 - hv[r]
            Sound.play(Sound.BEAD)
            return
        }
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in 0 until 4) {
            val dd = abs(earthY(r, i) - y)
            if (dd < bd) {
                bd = dd
                best = i
            }
        }
        e[r] = if (best < e[r]) best else best + 1
        Sound.play(Sound.BEAD)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action != MotionEvent.ACTION_DOWN) return true
        if (paused) {
            if (tapToResume) {
                tapToResume = false
                paused = false
            }
            return true
        }
        val x = ev.x
        val y = ev.y
        if (x > width - 56f * d && y < 56f * d) {
            listener?.onPauseRequested()
            return true
        }
        if (phase != 0) return true
        if (btnCheck.contains(x, y)) {
            check()
            return true
        }
        if (btnClear.contains(x, y)) {
            Sound.play(Sound.BEAD)
            setValue(startVal)
            return true
        }
        tapBeads(x, y)
        return true
    }

    // ---------- rysowanie ----------

    private fun fl(color: Int): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = color
        return p
    }

    private fun st(color: Int, w: Float): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.color = color
        return p
    }

    private fun dark(c: Int): Int =
        Color.rgb((Color.red(c) * 0.7f).toInt(), (Color.green(c) * 0.7f).toInt(), (Color.blue(c) * 0.7f).toInt())

    private fun mixWhite(c: Int, f: Float): Int =
        Color.rgb(
            (Color.red(c) + (255 - Color.red(c)) * f).toInt(),
            (Color.green(c) + (255 - Color.green(c)) * f).toInt(),
            (Color.blue(c) + (255 - Color.blue(c)) * f).toInt()
        )

    private fun text(c: Canvas, s: String, x: Float, y: Float, sizeDp: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, shadow: Boolean = false) {
        tp.textSize = sizeDp * d
        tp.color = color
        tp.textAlign = align
        if (shadow) tp.setShadowLayer(3f * d, 0f, 1.5f * d, 0x99000000.toInt()) else tp.clearShadowLayer()
        c.drawText(s, x, y, tp)
        tp.clearShadowLayer()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNs == 0L) 0f else ((now - lastNs) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNs = now
        if (paused) dt = 0f
        if (width > 0) {
            layout()
            step(dt)
            layout()
            drawBackground(canvas)
            drawHud(canvas)
            drawBoard(canvas)
            drawBottom(canvas)
            drawOwl(canvas, width - 58f * d, frameT + 6f * d, 62f * d)
            drawEffects(canvas)
            if (paused) {
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fl(0xAA000000.toInt()))
                text(canvas, "Pauza", width / 2f, height / 2f, 40f, Color.WHITE)
                if (tapToResume) text(canvas, "Dotknij ekranu, aby grać dalej", width / 2f, height / 2f + 34f * d, 17f, Color.WHITE)
            }
        }
        postInvalidateOnAnimation()
    }

    private fun drawBackground(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.reset()
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // księżyc
        c.drawCircle(w - 120f * d, 196f * d, 22f * d, fl(0x33FFF3C4))
        c.drawCircle(w - 120f * d, 196f * d, 15f * d, fl(0xFFFFF3C4.toInt()))
        // gwiazdy
        for (i in 0 until 26) {
            val x = (sin(i * 12.9898f) * 0.5f + 0.5f) * w
            val y = (sin(i * 7.233f) * 0.5f + 0.5f) * h * 0.85f
            val al = ((sin(t * 1.6f + i) * 0.5f + 0.5f) * 190f + 40f).toInt()
            c.drawCircle(x, y, (1f + (i % 3) * 0.6f) * d, fl((al shl 24) or 0xFFFFFF))
        }
        // góry
        path.reset()
        path.moveTo(0f, h)
        path.lineTo(0f, h - 70f * d)
        path.lineTo(w * 0.18f, h - 120f * d)
        path.lineTo(w * 0.34f, h - 80f * d)
        path.lineTo(w * 0.55f, h - 135f * d)
        path.lineTo(w * 0.75f, h - 85f * d)
        path.lineTo(w * 0.9f, h - 115f * d)
        path.lineTo(w, h - 75f * d)
        path.lineTo(w, h)
        path.close()
        c.drawPath(path, fl(0xFF1A1633.toInt()))
        path.reset()
        path.moveTo(0f, h)
        path.lineTo(0f, h - 40f * d)
        path.lineTo(w * 0.25f, h - 75f * d)
        path.lineTo(w * 0.5f, h - 45f * d)
        path.lineTo(w * 0.8f, h - 80f * d)
        path.lineTo(w, h - 45f * d)
        path.lineTo(w, h)
        path.close()
        c.drawPath(path, fl(0xFF120F26.toInt()))
        // mgła
        for (k in 0..2) {
            val cx = ((t * (8f + k * 4f) * d + k * 170f * d) % (w + 300f * d)) - 150f * d
            rc.set(cx - 130f * d, h - (110f + k * 30f) * d, cx + 130f * d, h - (70f + k * 30f) * d)
            c.drawOval(rc, fl(0x1FFFFFFF))
        }
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, r: Float, filled: Boolean) {
        path.reset()
        path.moveTo(cx, cy + r * 0.9f)
        path.cubicTo(cx - r * 1.6f, cy - r * 0.1f, cx - r * 0.8f, cy - r * 1.3f, cx, cy - r * 0.4f)
        path.cubicTo(cx + r * 0.8f, cy - r * 1.3f, cx + r * 1.6f, cy - r * 0.1f, cx, cy + r * 0.9f)
        path.close()
        if (filled) {
            c.drawPath(path, fl(0xFFE53935.toInt()))
            c.drawPath(path, st(0xFF8E1B1B.toInt(), 2f * d))
        } else {
            c.drawPath(path, st(0xFF90A4AE.toInt(), 2f * d))
        }
    }

    private fun drawHud(c: Canvas) {
        val w = width.toFloat()
        val gold = 0xFFFFD54F.toInt()
        for (i in 0 until 5) heart(c, (22f + i * 27f) * d, 24f * d, 11f * d, i < lives)
        text(c, "Punkty: $score", w - 60f * d, 30f * d, 18f, gold, Paint.Align.RIGHT, true)
        // przycisk pauzy
        c.drawCircle(w - 28f * d, 28f * d, 18f * d, fl(0xCC1A1630.toInt()))
        c.drawCircle(w - 28f * d, 28f * d, 18f * d, st(gold, 2f * d))
        c.drawRect(w - 34f * d, 20f * d, w - 29f * d, 36f * d, fl(gold))
        c.drawRect(w - 25f * d, 20f * d, w - 20f * d, 36f * d, fl(gold))
        // poziom i postęp
        text(c, "POZIOM $level  \u2022  LICZYDŁO", w / 2f, 54f * d, 15f, Color.WHITE, Paint.Align.CENTER, true)
        for (i in 0 until 5) {
            c.drawCircle(w / 2f + (i - 2f) * 20f * d, 66f * d, 5f * d, fl(if (i < solved) gold else 0x66FFFFFF))
        }
        // pasek czasu
        rc.set(14f * d, 74f * d, w - 14f * d, 84f * d)
        c.drawRoundRect(rc, 5f * d, 5f * d, fl(0x66000000))
        if (phase == 0) {
            val f = (timeLeft / timeTotal).coerceIn(0f, 1f)
            rc.set(14f * d, 74f * d, 14f * d + (w - 28f * d) * f, 84f * d)
            c.drawRoundRect(rc, 5f * d, 5f * d, fl(Color.HSVToColor(floatArrayOf(120f * f, 0.75f, 0.95f))))
        }
        // tablica z równaniem
        val edge = when (phase) {
            1 -> 0xFF66BB6A.toInt()
            2 -> 0xFFEF5350.toInt()
            else -> 0xFFC9A227.toInt()
        }
        rc.set(14f * d, 92f * d, w - 14f * d, 154f * d)
        c.drawRoundRect(rc, 14f * d, 14f * d, fl(0xE61A1423.toInt()))
        c.drawRoundRect(rc, 14f * d, 14f * d, st(edge, 3f * d))
        val shown = if (phase == 0) "?" else answer.toString()
        val col = when (phase) {
            1 -> 0xFF81C784.toInt()
            2 -> 0xFFEF5350.toInt()
            else -> 0xFFF5E6C8.toInt()
        }
        text(c, "$a ${sym()} $b = $shown", w / 2f, 141f * d, 38f, col)
        // podpowiedź
        text(c, hintText(), 16f * d, 182f * d, 14f, 0xFFF5E6C8.toInt(), Paint.Align.LEFT, true)
        text(c, "Próba ${min(tries + 1, 3)} z 3", 16f * d, 204f * d, 12f, 0xFFB0A8D8.toInt(), Paint.Align.LEFT, true)
    }

    private fun bead(c: Canvas, x: Float, cy: Float, color: Int, label: String?, active: Boolean) {
        val base = if (active) color else mixDark(color, 0.6f)
        rc.set(x - bw / 2f, cy - bh / 2f + 1f * d, x + bw / 2f, cy + bh / 2f - 1f * d)
        c.drawOval(rc, fl(base))
        c.drawOval(rc, st(if (active) dark(color) else 0xFF3A3358.toInt(), 2.5f * d))
        if (active) {
            rc.set(x - bw / 2f - 2f * d, cy - bh / 2f - 1f * d, x + bw / 2f + 2f * d, cy + bh / 2f + 1f * d)
            c.drawOval(rc, st(0xFFFFD54F.toInt(), 2.2f * d))
        }
        rc.set(x - bw * 0.32f, cy - bh * 0.34f, x + bw * 0.06f, cy - bh * 0.1f)
        c.drawOval(rc, fl(if (active) 0x77FFFFFF else 0x33FFFFFF))
        if (label != null) text(c, label, x + bw * 0.1f, cy + bh * 0.2f, 15f, if (active) Color.WHITE else 0x99FFFFFF.toInt())
    }

    private fun mixDark(c: Int, f: Float): Int =
        Color.rgb(
            (Color.red(c) + (0x1E - Color.red(c)) * f).toInt(),
            (Color.green(c) + (0x18 - Color.green(c)) * f).toInt(),
            (Color.blue(c) + (0x30 - Color.blue(c)) * f).toInt()
        )

    private fun drawBoard(c: Canvas) {
        // ciemna rama ze złotym obrzeżem
        rc.set(frameL, frameT, frameR, frameB)
        c.drawRoundRect(rc, 20f * d, 20f * d, fl(0xFF4A3020.toInt()))
        c.drawRoundRect(rc, 20f * d, 20f * d, st(0xFFC9A227.toInt(), 3f * d))
        rc.set(innerL - 4f * d, innerT - 4f * d, innerR + 4f * d, innerB + 4f * d)
        c.drawRoundRect(rc, 12f * d, 12f * d, fl(0xFF1E1830.toInt()))
        for (i in 0 until rods) {
            val x = rodX(i)
            c.drawRect(x - 3f * d, innerT, x + 3f * d, innerB, fl(0xFF8A7FB0.toInt()))
        }
        rc.set(innerL - 4f * d, beamY - 5f * d, innerR + 4f * d, beamY + 5f * d)
        c.drawRoundRect(rc, 4f * d, 4f * d, fl(0xFFC9A227.toInt()))
        for (i in 0 until rods) c.drawCircle(rodX(i), beamY, 2.2f * d, fl(0xFF5D4037.toInt()))
        for (r in 0 until rods) {
            val x = rodX(r)
            val color = placeColors[rods - 1 - r]
            for (i in 0 until 4) bead(c, x, earthY(r, i), color, null, e[r] > i)
            bead(c, x, heavenY(r), 0xFFE53935.toInt(), "5", hv[r] == 1)
        }
    }

    private fun drawBottom(c: Canvas) {
        if (cfg.difficulty < 2) {
            for (r in 0 until rods) {
                val x = rodX(r)
                val col = placeColors[rods - 1 - r]
                c.drawCircle(x, frameB + 22f * d, 16f * d, fl(col))
                c.drawCircle(x, frameB + 22f * d, 16f * d, st(0xFFFFD54F.toInt(), 2f * d))
                text(c, (hv[r] * 5 + e[r]).toString(), x, frameB + 29f * d, 20f, Color.WHITE)
                text(c, placeNames[rods - 1 - r], x, frameB + 52f * d, 11f, 0xFFB0A8D8.toInt(), Paint.Align.CENTER, true)
            }
        }
        val on = phase == 0
        fun button(r: RectF, color: Int, label: String, size: Float) {
            val col = if (on) color else 0xFF4A4A55.toInt()
            c.drawRoundRect(r, 12f * d, 12f * d, fl(col))
            c.drawRoundRect(r, 12f * d, 12f * d, st(0xFFFFD54F.toInt(), 2f * d))
            text(c, label, r.centerX(), r.centerY() + size * 0.35f * d, size, 0xFFFFD54F.toInt())
        }
        button(btnClear, 0xFF8A4B14.toInt(), "Od nowa", 18f)
        button(btnCheck, 0xFF1F6B3A.toInt(), "Zatwierdź", 20f)
    }

    private fun drawOwl(c: Canvas, cx0: Float, baseY: Float, sz: Float) {
        val mood = when {
            phase == 1 -> 1
            phase == 2 || owlShake > 0f -> 2
            else -> 0
        }
        val jump = if (owlJump > 0f) abs(sin(owlJump * 12f)) * sz * 0.25f else 0f
        val sh = if (owlShake > 0f) sin(owlShake * 40f) * sz * 0.06f else 0f
        val cx = cx0 + sh
        val by = baseY - jump
        val brown = 0xFF8D6E63.toInt()
        val brownD = 0xFF5D4037.toInt()
        // łapki
        rc.set(cx - 0.28f * sz, by - 0.07f * sz, cx - 0.04f * sz, by + 0.02f * sz)
        c.drawOval(rc, fl(0xFFFFA726.toInt()))
        rc.set(cx + 0.04f * sz, by - 0.07f * sz, cx + 0.28f * sz, by + 0.02f * sz)
        c.drawOval(rc, fl(0xFFFFA726.toInt()))
        // skrzydła
        val flap = if (owlJump > 0f) -0.22f * sz else 0f
        rc.set(cx - 0.58f * sz, by - 0.66f * sz + flap, cx - 0.3f * sz, by - 0.2f * sz)
        c.drawOval(rc, fl(brownD))
        rc.set(cx + 0.3f * sz, by - 0.66f * sz + flap, cx + 0.58f * sz, by - 0.2f * sz)
        c.drawOval(rc, fl(brownD))
        // ciało
        rc.set(cx - 0.42f * sz, by - 0.95f * sz, cx + 0.42f * sz, by - 0.04f * sz)
        c.drawOval(rc, fl(brown))
        c.drawOval(rc, st(brownD, 2f * d))
        rc.set(cx - 0.27f * sz, by - 0.52f * sz, cx + 0.27f * sz, by - 0.08f * sz)
        c.drawOval(rc, fl(0xFFFFE0B2.toInt()))
        // oczy
        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * 0.17f * sz
            val ey = by - 0.7f * sz
            c.drawCircle(ex, ey, 0.15f * sz, fl(Color.WHITE))
            c.drawCircle(ex, ey, 0.15f * sz, st(brownD, 1.5f * d))
            when (mood) {
                1 -> {
                    rc.set(ex - 0.1f * sz, ey - 0.07f * sz, ex + 0.1f * sz, ey + 0.09f * sz)
                    c.drawArc(rc, 180f, 180f, false, st(0xFF212121.toInt(), 2.5f * d))
                }
                2 -> {
                    c.drawCircle(ex, ey + 0.03f * sz, 0.05f * sz, fl(0xFF212121.toInt()))
                    c.drawLine(ex - 0.1f * sz, ey - 0.2f * sz + side * 0.03f * sz, ex + 0.1f * sz, ey - 0.14f * sz - side * 0.03f * sz, st(brownD, 2f * d))
                }
                else -> {
                    if (t % 3.2f < 0.12f) {
                        c.drawLine(ex - 0.09f * sz, ey, ex + 0.09f * sz, ey, st(0xFF212121.toInt(), 2f * d))
                    } else {
                        c.drawCircle(ex, ey, 0.065f * sz, fl(0xFF212121.toInt()))
                    }
                }
            }
        }
        // dziób
        path.reset()
        path.moveTo(cx - 0.06f * sz, by - 0.62f * sz)
        path.lineTo(cx + 0.06f * sz, by - 0.62f * sz)
        path.lineTo(cx, by - 0.5f * sz)
        path.close()
        c.drawPath(path, fl(0xFFFFA726.toInt()))
        // czapka absolwenta
        path.reset()
        path.moveTo(cx - 0.38f * sz, by - 0.97f * sz)
        path.lineTo(cx, by - 1.08f * sz)
        path.lineTo(cx + 0.38f * sz, by - 0.97f * sz)
        path.lineTo(cx, by - 0.88f * sz)
        path.close()
        c.drawPath(path, fl(0xFF303F9F.toInt()))
        c.drawLine(cx + 0.3f * sz, by - 0.96f * sz, cx + 0.36f * sz, by - 0.78f * sz, st(0xFFFFC107.toInt(), 2f * d))
    }

    private fun drawEffects(c: Canvas) {
        for (q in parts) {
            val a = (q.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawCircle(q.x, q.y, q.size, fl((a shl 24) or (q.color and 0xFFFFFF)))
        }
        for (q in pops) {
            val a = (q.life.coerceIn(0f, 1f) * 255).toInt()
            text(c, q.text, q.x, q.y, q.size, (a shl 24) or (q.color and 0xFFFFFF), Paint.Align.CENTER, true)
        }
    }
}
