package com.example.fairymath

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window
import kotlin.math.min
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Animowana postać na ekranach menu. */
class PreviewView(context: Context, private val kind: Int) : View(context) {
    override fun onDraw(canvas: Canvas) {
        val t = System.nanoTime() / 1_000_000_000f
        Art.drawHero(canvas, kind, width / 2f, height * 0.95f, height * 0.78f, t * 6f, 0f, 0, 1f)
        postInvalidateOnAnimation()
    }
}

/** Mała ilustracja liczydła do ekranów wyboru. */
class AbPreview(context: Context) : View(context) {
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val tt = System.nanoTime() / 1_000_000_000f
        pt.style = Paint.Style.FILL
        pt.color = 0xFF4A3020.toInt()
        rect.set(w * 0.1f, h * 0.05f, w * 0.9f, h * 0.95f)
        c.drawRoundRect(rect, h * 0.12f, h * 0.12f, pt)
        pt.style = Paint.Style.STROKE
        pt.strokeWidth = h * 0.025f
        pt.color = 0xFFC9A227.toInt()
        c.drawRoundRect(rect, h * 0.12f, h * 0.12f, pt)
        pt.style = Paint.Style.FILL
        pt.color = 0xFF1E1830.toInt()
        rect.set(w * 0.14f, h * 0.12f, w * 0.86f, h * 0.88f)
        c.drawRoundRect(rect, h * 0.08f, h * 0.08f, pt)
        val beamY = h * 0.38f
        val cols = intArrayOf(0xFFFFA726.toInt(), 0xFF66BB6A.toInt(), 0xFF29B6F6.toInt())
        val heav = intArrayOf(0, 1, 1)
        val earth = intArrayOf(3, 0, 2)
        for (r in 0..2) {
            val x = w * (0.28f + r * 0.22f)
            pt.color = 0xFF8A7FB0.toInt()
            c.drawRect(x - 2f, h * 0.12f, x + 2f, h * 0.88f, pt)
            val bh = h * 0.1f
            val bw = w * 0.17f
            pt.color = 0xFFE53935.toInt()
            val hy = if (heav[r] == 1) beamY - h * 0.05f - bh / 2f else h * 0.2f
            rect.set(x - bw / 2f, hy - bh / 2f, x + bw / 2f, hy + bh / 2f)
            c.drawOval(rect, pt)
            pt.color = cols[r]
            for (i in 0..3) {
                val up = i < earth[r]
                val y = if (up) beamY + h * 0.05f + bh / 2f + i * bh else h * 0.88f - bh / 2f - (3 - i) * bh - h * 0.02f
                rect.set(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f)
                c.drawOval(rect, pt)
            }
        }
        pt.color = 0xFFC9A227.toInt()
        rect.set(w * 0.14f, beamY - h * 0.025f, w * 0.86f, beamY + h * 0.025f)
        c.drawRect(rect, pt)
        if (tt < 0f) postInvalidateOnAnimation()
    }
}

/** Statyczny obrazek bohatera wraz z zdobytymi przedmiotami (do wyników). */
class HeroThumb(context: Context, private val kind: Int, gear: List<Int>, private val level: Int) : View(context) {
    private val arr = IntArray(6) { gear.getOrElse(it) { -1 } }
    override fun onDraw(canvas: Canvas) {
        Art.drawHero(canvas, kind.coerceIn(0, 2), width / 2f, height * 0.96f, height * 0.82f, 0f, 0f, min(4, level / 5), 0f, arr)
    }
}

class MainActivity : Activity() {

    private var game: GameView? = null
    private var abGame: AbacusView? = null
    private var pauseDialog: Dialog? = null
    private var screen = "menu"

    private val gold = 0xFFFFD54F.toInt()
    private val cream = 0xFFEDE7D0.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashHandler()
        Sound.init()
        applySound()
        val trace = getSharedPreferences("crashlog", Context.MODE_PRIVATE).getString("trace", null)
        if (trace != null) showCrash(trace) else showHome()
    }

    // Zapisuje błąd, gdy aplikacja się wysypie, i pokazuje go przy następnym uruchomieniu
    private fun installCrashHandler() {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, ex ->
            try {
                val sw = java.io.StringWriter()
                ex.printStackTrace(java.io.PrintWriter(sw))
                getSharedPreferences("crashlog", Context.MODE_PRIVATE)
                    .edit().putString("trace", sw.toString().take(4000)).commit()
            } catch (e: Throwable) {
            }
            old?.uncaughtException(th, ex)
        }
    }

    private fun showCrash(trace: String) {
        screen = "crash"
        val shown = trace.lines().take(16).joinToString("\n")
        val tv = TextView(this).apply {
            text = shown
            textSize = 11f
            setTextColor(cream)
            setTextIsSelectable(true)
        }
        page(
            listOf(
                titleView("Wykryto błąd", 28f).sized(MATCH, WRAP),
                label("Skopiuj ten tekst i wyślij go do Claude.", 14f).sized(WRAP, WRAP, 8),
                tv.sized(MATCH, WRAP, 12),
                fancyButton("Kopiuj błąd", 0xFF2A3F5E.toInt()) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("blad", trace))
                    Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show()
                }.sized(MATCH, dp(52), 16),
                fancyButton("Dalej do menu", 0xFF7B1F2E.toInt()) {
                    getSharedPreferences("crashlog", Context.MODE_PRIVATE).edit().remove("trace").commit()
                    showMenu()
                }.sized(MATCH, dp(52), 12)
            )
        )
    }

    private fun applySound() {
        val st = Store.settings(this)
        Sound.musicOn = st.music
        Sound.sfxOn = st.sfx
    }

    override fun onResume() {
        super.onResume()
        Sound.musicStart()
    }

    override fun onPause() {
        super.onPause()
        Sound.musicPause()
        val g = game
        if (screen == "game" && g != null && !g.paused) {
            g.paused = true
            g.tapToResume = true
        }
        val ag = abGame
        if (screen == "abgame" && ag != null && !ag.paused) {
            ag.paused = true
            ag.tapToResume = true
        }
    }

    override fun onBackPressed() {
        when (screen) {
            "home" -> super.onBackPressed()
            "menu" -> showHome()
            "game" -> showPauseDialog()
            "abgame" -> showAbPause()
            "abmenu" -> showHome()
            "abset", "abscores", "abover" -> showAbMenu()
            else -> showMenu()
        }
    }

    // ---------- pomocnicy interfejsu ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun bg() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt())
    )

    private fun roundBg(color: Int, radiusDp: Int, strokeColor: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(2), strokeColor)
        }

    private fun <T : View> T.sized(w: Int, h: Int, top: Int = 0): T {
        layoutParams = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
        return this
    }

    private fun fancyButton(label: String, color: Int, size: Float = 20f, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = size
            setTextColor(gold)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            background = RippleDrawable(ColorStateList.valueOf(0x66FFFFFF), roundBg(color, 12, gold), null)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun titleView(label: String, size: Float = 34f, color: Int = gold) = TextView(this).apply {
        text = label
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(color)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        setShadowLayer(10f, 0f, 3f, 0xFF000000.toInt())
    }

    private fun label(txt: String, size: Float = 20f, color: Int = cream) = TextView(this).apply {
        text = txt
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }

    private fun page(views: List<View>, back: android.graphics.drawable.Drawable = bg()) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }
        views.forEach { col.addView(it) }
        val scroll = ScrollView(this).apply {
            background = back
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        setContentView(scroll)
    }

    // ---------- ekrany ----------

    private fun showHome() {
        screen = "home"
        game = null
        abGame = null
        Sound.setTrack(0)
        fun card(title: String, desc: String, color: Int, preview: View, onClick: () -> Unit): View {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(12), dp(12), dp(14))
                background = roundBg(color, 16, gold)
                setOnClickListener { onClick() }
            }
            box.addView(preview.sized(dp(250), dp(110)))
            box.addView(label(title, 22f, gold).sized(WRAP, WRAP, 6))
            box.addView(label(desc, 13f, 0xFFD1C4E9.toInt()).sized(WRAP, WRAP, 2))
            return box
        }
        val heroes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (k in 0..2) addView(PreviewView(this@MainActivity, k).sized(dp(80), dp(110)))
        }
        page(
            listOf(
                titleView("WYBIERZ GRĘ", 34f).sized(MATCH, WRAP),
                label("wersja 10  \u2022  27.11", 11f, 0xFF8A84B8.toInt()).sized(WRAP, WRAP, 2),
                card("Krainy Liczb", "Fantasy: potwory, bossy, skrzynie i zbroje", 0xCC3A1830.toInt(), heroes) { showMenu() }
                    .sized(MATCH, WRAP, 20),
                card("Magiczne Liczydło", "Soroban: licz, przesuwając koraliki", 0xCC182C50.toInt(), AbPreview(this)) { showAbMenu() }
                    .sized(MATCH, WRAP, 16),
                fancyButton("Wyjdź", 0xFF37383F.toInt()) { finish() }.sized(MATCH, dp(52), 20)
            )
        )
    }

    private fun showMenu() {
        screen = "menu"
        game = null
        abGame = null
        Sound.setTrack(0)
        val heroes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (k in 0..2) addView(PreviewView(this@MainActivity, k).sized(dp(90), dp(130)))
        }
        val hasSave = Store.loadGame(this) != null
        val load = fancyButton("Wczytaj grę", 0xFF1B3A57.toInt()) {
            val sv = Store.loadGame(this)
            if (sv != null) startGame(sv.character, sv)
        }
        load.isEnabled = hasSave
        load.alpha = if (hasSave) 1f else 0.45f

        page(
            listOf(
                titleView("KRAINY\nLICZB", 44f).sized(MATCH, WRAP),
                label("Matematyczna wyprawa przez krainy fantasy", 14f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 4),
                heroes.sized(MATCH, WRAP, 8),
                fancyButton("Nowa gra", 0xFF7B1F2E.toInt()) { showCharacterSelect() }.sized(MATCH, dp(56), 16),
                load.sized(MATCH, dp(56), 12),
                fancyButton("Wyniki", 0xFF3E2A5E.toInt()) { showScores() }.sized(MATCH, dp(56), 12),
                fancyButton("Ustawienia", 0xFF2A3F5E.toInt()) { showSettings() }.sized(MATCH, dp(56), 12),
                fancyButton("Zmień grę", 0xFF37383F.toInt()) { showHome() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showCharacterSelect() {
        screen = "select"
        val views = ArrayList<View>()
        views.add(titleView("Wybierz bohatera", 30f).sized(MATCH, WRAP))
        for (k in 0..2) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(14), dp(8))
                background = roundBg(0xCC1A1630.toInt(), 14, gold)
                setOnClickListener { startGame(k, null) }
            }
            card.addView(PreviewView(this, k).sized(dp(100), dp(130)))
            val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            txt.addView(label(Art.heroName(k), 22f, gold).sized(WRAP, WRAP))
            txt.addView(label(Art.heroDesc(k), 16f).sized(WRAP, WRAP, 4))
            txt.addView(label("Nowa broń co 5 poziomów", 12f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 6))
            card.addView(txt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })
            views.add(card.sized(MATCH, WRAP, 12))
        }
        views.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 20))
        page(views)
    }

    private fun startGame(character: Int, save: SaveState?) {
        screen = "game"
        val cfg = Store.settings(this)
        val gv = GameView(this, cfg, character.coerceIn(0, 2), save)
        gv.listener = object : GameView.Listener {
            override fun onGameOver(score: Int) {
                if (game === gv) gameOver(score)
            }

            override fun onPauseRequested() {
                showPauseDialog()
            }
        }
        game = gv
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F0C29.toInt())
        }
        root.addView(gv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(keypad(gv), LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    private fun keypad(gv: GameView): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            setBackgroundColor(0xFF1A1630.toInt())
        }
        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9"),
            arrayOf("Cofnij", "0", "Zatwierdź")
        )
        for (row in rows) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in row) {
                val color = when (key) {
                    "Cofnij" -> 0xFF8A4B14.toInt()
                    "Zatwierdź" -> 0xFF1F6B3A.toInt()
                    else -> 0xFF3A2E66.toInt()
                }
                val size = if (key.length > 2) 15f else 24f
                val b = fancyButton(key, color, size) {
                    when (key) {
                        "Cofnij" -> gv.backspace()
                        "Zatwierdź" -> gv.submit()
                        else -> gv.pressDigit(key.toInt())
                    }
                }
                r.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            col.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return col
    }

    private fun showPauseDialog() {
        val g = game ?: return
        if (pauseDialog?.isShowing == true) return
        g.paused = true
        g.tapToResume = false
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(18), dp(22), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF2E2559.toInt(), 0xFF15102E.toInt())
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(3), gold)
            }
        }
        card.addView(label("\u2694  \u2726  \u2694", 16f, 0xFFB39DDB.toInt()).sized(WRAP, WRAP))
        card.addView(titleView("PAUZA", 36f).sized(MATCH, WRAP, 2))
        card.addView(
            label("Poziom ${g.level}   \u2022   Punkty ${g.score}   \u2022   \u2665 ${g.lives}", 14f, 0xFFD1C4E9.toInt())
                .sized(WRAP, WRAP, 6)
        )
        card.addView(fancyButton("Wznów grę", 0xFF1F6B3A.toInt()) {
            dlg.dismiss()
            g.paused = false
        }.sized(MATCH, dp(54), 18))
        card.addView(fancyButton("Zapisz i wyjdź do menu", 0xFF1B3A57.toInt(), 17f) {
            dlg.dismiss()
            Store.saveGame(this, g.snapshot())
            Toast.makeText(this, "Gra zapisana", Toast.LENGTH_SHORT).show()
            showMenu()
        }.sized(MATCH, dp(54), 10))
        card.addView(fancyButton("Zakończ grę", 0xFF7B1F2E.toInt()) {
            dlg.dismiss()
            gameOver(g.score)
        }.sized(MATCH, dp(54), 10))
        card.addView(label("Wynik trafi do tabeli wyników, gra nie zostanie zapisana.", 11f, 0xFF9E9AC8.toInt()).sized(WRAP, WRAP, 4))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bm = fancyButton("", 0xFF3A2E66.toInt(), 14f) {}
        val bs = fancyButton("", 0xFF3A2E66.toInt(), 14f) {}
        fun refresh() {
            bm.text = if (Sound.musicOn) "Muzyka: wł." else "Muzyka: wył."
            bs.text = if (Sound.sfxOn) "Dźwięki: wł." else "Dźwięki: wył."
        }
        bm.setOnClickListener {
            Sound.musicOn = !Sound.musicOn
            Store.saveSettings(this, Store.settings(this).copy(music = Sound.musicOn))
            Sound.refreshMusic()
            refresh()
        }
        bs.setOnClickListener {
            Sound.sfxOn = !Sound.sfxOn
            Store.saveSettings(this, Store.settings(this).copy(sfx = Sound.sfxOn))
            refresh()
        }
        refresh()
        row.addView(bm, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(5) })
        row.addView(bs, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(5) })
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        dlg.setContentView(card)
        dlg.setOnCancelListener { g.paused = false }
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pauseDialog = dlg
        dlg.show()
        dlg.window?.setLayout(dp(320), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun gameOver(score: Int) {
        screen = "over"
        val g = game
        val lvl = g?.level ?: 1
        val ch = g?.character ?: -1
        val gearL = g?.gearList() ?: List(6) { -1 }
        val diff = g?.difficulty ?: 1
        game = null
        Store.clearGame(this)
        val best = Store.best(this)
        if (score > 0) Store.addScore(this, ScoreEntry(score, "", ch, lvl, diff, gearL))
        val record = score > best && score > 0
        val msg = if (record) "Nowy rekord!" else "Najlepszy wynik: $best"
        page(
            listOf(
                titleView("Koniec wyprawy", 34f).sized(MATCH, WRAP),
                (if (ch >= 0) HeroThumb(this, ch, gearL, lvl) else View(this)).sized(dp(120), dp(if (ch >= 0) 150 else 1), 12),
                label("Twój wynik", 20f).sized(WRAP, WRAP, 12),
                titleView("$score", 64f).sized(MATCH, WRAP),
                label("Dotarłeś do poziomu $lvl", 18f).sized(WRAP, WRAP, 4),
                label(msg, 18f, gold).sized(WRAP, WRAP, 8),
                fancyButton("Zagraj jeszcze raz", 0xFF7B1F2E.toInt()) { showCharacterSelect() }
                    .sized(MATCH, dp(56), 28),
                fancyButton("Menu", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showScores() {
        screen = "scores"
        val list = Store.scores(this)
        val views = ArrayList<View>()
        views.add(titleView("Top 5", 34f).sized(MATCH, WRAP))
        if (list.isEmpty()) {
            views.add(label("Jeszcze brak wyników.\nWyrusz na pierwszą wyprawę!", 18f).sized(WRAP, WRAP, 24))
        } else {
            val medal = intArrayOf(0xFFFFD54F.toInt(), 0xFFCFD8DC.toInt(), 0xFFFFAB66.toInt())
            val diffNames = arrayOf("Łatwy x1", "Średni x2", "Trudny x3")
            list.forEachIndexed { i, e ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(6), dp(12), dp(6))
                    background = roundBg(0xCC1A1630.toInt(), 14, if (i < 3) medal[i] else 0xFF6A5FA8.toInt())
                }
                if (e.character >= 0) {
                    card.addView(HeroThumb(this, e.character, e.gear, e.level).sized(dp(64), dp(84)))
                } else {
                    card.addView(View(this).sized(dp(64), dp(84)))
                }
                val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                txt.addView(label("${i + 1}.  ${e.score} pkt", 22f, if (i < 3) medal[i] else cream).sized(WRAP, WRAP))
                val dn = diffNames[e.difficulty.coerceIn(0, 2)]
                txt.addView(label("Poziom ${e.level}  \u2022  $dn", 13f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 2))
                txt.addView(label(e.date, 12f, 0xFF8A84B8.toInt()).sized(WRAP, WRAP, 2))
                card.addView(txt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(10) })
                views.add(card.sized(MATCH, WRAP, 10))
            }
        }
        views.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 24))
        page(views)
    }

    private fun onSeek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            f(progress)
        }

        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    }

    private fun tintBox(cb: CheckBox) {
        cb.buttonTintList = ColorStateList.valueOf(gold)
    }

    private fun showSettings() {
        screen = "settings"
        var st = Store.settings(this)
        fun save() = Store.saveSettings(this, st)

        fun box(txt: String, on: Boolean) = CheckBox(this).apply {
            text = txt
            textSize = 20f
            setTextColor(cream)
            isChecked = on
            tintBox(this)
        }

        val cbAdd = box("Dodawanie (+)", st.add)
        val cbSub = box("Odejmowanie (−)", st.sub)
        val cbMul = box("Mnożenie (×)", st.mul)
        fun others(except: CheckBox) = listOf(cbAdd, cbSub, cbMul).filter { it !== except }.any { it.isChecked }

        cbAdd.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbAdd)) {
                cbAdd.isChecked = true
            } else {
                st = st.copy(add = checked)
                save()
            }
        }
        cbSub.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbSub)) {
                cbSub.isChecked = true
            } else {
                st = st.copy(sub = checked)
                save()
            }
        }
        cbMul.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbMul)) {
                cbMul.isChecked = true
            } else {
                st = st.copy(mul = checked)
                save()
            }
        }

        val tvFrom = label("Od: ${st.min}", 18f)
        val tvTo = label("Do: ${st.max}", 18f)
        val sbFrom = SeekBar(this).apply {
            max = 99
            progress = st.min
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        val sbTo = SeekBar(this).apply {
            max = 99
            progress = st.max - 1
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        sbFrom.setOnSeekBarChangeListener(onSeek { p ->
            val lo = p
            var hi = st.max
            if (lo >= hi) {
                hi = lo + 1
                sbTo.progress = hi - 1
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })
        sbTo.setOnSeekBarChangeListener(onSeek { p ->
            val hi = p + 1
            var lo = st.min
            if (hi <= lo) {
                lo = hi - 1
                sbFrom.progress = lo
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })

        val rg = RadioGroup(this)
        val names = arrayOf("Łatwy – 15 s  (punkty x1)", "Średni – 10 s  (punkty x2)", "Trudny – 5 s  (punkty x3)")
        names.forEachIndexed { i, txt ->
            rg.addView(RadioButton(this).apply {
                id = 1000 + i
                text = txt
                textSize = 18f
                setTextColor(cream)
                buttonTintList = ColorStateList.valueOf(gold)
            })
        }
        rg.check(1000 + st.difficulty)
        rg.setOnCheckedChangeListener { _, id ->
            st = st.copy(difficulty = id - 1000)
            save()
        }

        fun slider(title: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): List<View> {
            val tv = label(fmt(value), 18f)
            val sb = SeekBar(this).apply {
                max = hi - lo
                progress = value - lo
                progressTintList = ColorStateList.valueOf(gold)
                thumbTintList = ColorStateList.valueOf(gold)
            }
            sb.setOnSeekBarChangeListener(onSeek { p ->
                val v = p + lo
                tv.text = fmt(v)
                onChange(v)
            })
            return listOf(label(title, 20f, gold).sized(WRAP, WRAP, 20), tv.sized(WRAP, WRAP, 6), sb.sized(MATCH, WRAP))
        }

        val cbMusic = box("Muzyka w tle", st.music)
        val cbSfx = box("Efekty dźwiękowe", st.sfx)
        cbMusic.setOnCheckedChangeListener { _, on ->
            st = st.copy(music = on)
            save()
            Sound.musicOn = on
            Sound.refreshMusic()
        }
        cbSfx.setOnCheckedChangeListener { _, on ->
            st = st.copy(sfx = on)
            save()
            Sound.sfxOn = on
        }

        val items = ArrayList<View>()
        items.add(titleView("Ustawienia", 34f).sized(MATCH, WRAP))
        items.add(label("Działania", 20f, gold).sized(WRAP, WRAP, 20))
        items.add(cbAdd.sized(WRAP, WRAP, 4))
        items.add(cbSub.sized(WRAP, WRAP, 4))
        items.add(cbMul.sized(WRAP, WRAP, 4))
        items.add(label("Zakres liczb", 20f, gold).sized(WRAP, WRAP, 20))
        items.add(tvFrom.sized(WRAP, WRAP, 6))
        items.add(sbFrom.sized(MATCH, WRAP))
        items.add(tvTo.sized(WRAP, WRAP, 6))
        items.add(sbTo.sized(MATCH, WRAP))
        items.add(label("Czas na odpowiedź i mnożnik punktów", 20f, gold).sized(WRAP, WRAP, 20))
        items.add(rg.sized(MATCH, WRAP, 4))
        items.addAll(slider("Częstotliwość bossa", 1, 10, st.bossEvery, { "Boss co $it pokonanych potworów" }) {
            st = st.copy(bossEvery = it)
            save()
        })
        items.addAll(slider("Częstotliwość skrzyni", 1, 10, st.chestNom, { "Skrzynia co około $it bossów" }) {
            st = st.copy(chestNom = it)
            save()
        })
        items.addAll(slider("Rozrzut skrzyni (losowość)", 1, 5, st.chestSpread, { "\u00B1 $it bossów od wybranej liczby" }) {
            st = st.copy(chestSpread = it)
            save()
        })
        items.add(label("Dźwięk", 20f, gold).sized(WRAP, WRAP, 20))
        items.add(cbMusic.sized(WRAP, WRAP, 4))
        items.add(cbSfx.sized(WRAP, WRAP, 4))
        items.add(label("Z każdym poziomem liczby rosną, a czas się skraca.\nNa bossa masz 2x więcej czasu, na skrzynię 3x.\nPunkty rosną z poziomem i trudnością.", 13f).sized(WRAP, WRAP, 12))
        items.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 20))
        page(items)
    }

    // ================= LICZYDŁO (soroban) =================

    private fun abPage(views: List<View>) = page(views)

    private fun abTitle(txt: String, size: Float = 34f) = titleView(txt, size)

    private fun abLabel(txt: String, size: Float = 18f, color: Int = cream) = label(txt, size, color)

    private fun showAbMenu() {
        screen = "abmenu"
        abGame = null
        game = null
        Sound.setTrack(1)
        val heroes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(AbPreview(this@MainActivity).sized(dp(230), dp(130)))
        }
        abPage(
            listOf(
                abTitle("MAGICZNE\nLICZYDŁO", 44f).sized(MATCH, WRAP),
                abLabel("Soroban – licz, przesuwając koraliki", 14f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 4),
                heroes.sized(MATCH, WRAP, 8),
                fancyButton("Nowa gra", 0xFF7B1F2E.toInt()) { startAbacus() }.sized(MATCH, dp(56), 16),
                fancyButton("Jak liczyć na liczydle?", 0xFF1B3A57.toInt(), 18f) { showAbHelp() }.sized(MATCH, dp(56), 12),
                fancyButton("Wyniki", 0xFF3E2A5E.toInt()) { showAbScores() }.sized(MATCH, dp(56), 12),
                fancyButton("Ustawienia", 0xFF2A3F5E.toInt()) { showAbSettings() }.sized(MATCH, dp(56), 12),
                fancyButton("Zmień grę", 0xFF37383F.toInt()) { showHome() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showAbHelp() {
        val tv = TextView(this).apply {
            text = "Każdy pręt to jedna cyfra: jedności, dziesiątki, setki.\n\n" +
                "Koralik na górze (z piątką) jest wart 5. Cztery koraliki na dole są warte po 1.\n\n" +
                "Liczy się koralik, który dotyka poprzeczki. Dotknij koralika, aby go przesunąć.\n\n" +
                "Przykład: 7 to koralik z piątką przy poprzeczce i dwa koraliki z dołu.\n\n" +
                "Ustaw wynik działania i naciśnij Sprawdź."
            textSize = 16f
            setTextColor(0xFF37314F.toInt())
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Jak liczyć na liczydle?")
            .setView(tv)
            .setPositiveButton("Rozumiem", null)
            .show()
    }

    private fun startAbacus() {
        screen = "abgame"
        Sound.setTrack(1)
        val cfg = AbacusStore.settings(this)
        val v = AbacusView(this, cfg)
        v.listener = object : AbacusView.Listener {
            override fun onGameOver(score: Int, level: Int) {
                if (abGame === v) abGameOver(score, level)
            }

            override fun onPauseRequested() {
                showAbPause()
            }
        }
        abGame = v
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(v)
    }

    private fun showAbPause() {
        val g = abGame ?: return
        if (pauseDialog?.isShowing == true) return
        g.paused = true
        g.tapToResume = false
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(18), dp(22), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF2E2559.toInt(), 0xFF15102E.toInt())
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(3), gold)
            }
        }
        card.addView(abTitle("PAUZA", 34f).sized(MATCH, WRAP))
        card.addView(abLabel("Poziom ${g.level}   \u2022   Punkty ${g.score}", 14f, 0xFFD1C4E9.toInt()).sized(WRAP, WRAP, 6))
        card.addView(fancyButton("Wznów grę", 0xFF1F6B3A.toInt()) {
            dlg.dismiss()
            g.paused = false
        }.sized(MATCH, dp(54), 18))
        card.addView(fancyButton("Zakończ grę", 0xFF7B1F2E.toInt()) {
            dlg.dismiss()
            abGameOver(g.score, g.level)
        }.sized(MATCH, dp(54), 10))
        card.addView(abLabel("Wynik trafi do tabeli wyników.", 11f).sized(WRAP, WRAP, 4))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bm = fancyButton("", 0xFF3A2E66.toInt(), 14f) {}
        val bs = fancyButton("", 0xFF3A2E66.toInt(), 14f) {}
        fun refresh() {
            bm.text = if (Sound.musicOn) "Muzyka: wł." else "Muzyka: wył."
            bs.text = if (Sound.sfxOn) "Dźwięki: wł." else "Dźwięki: wył."
        }
        bm.setOnClickListener {
            Sound.musicOn = !Sound.musicOn
            Store.saveSettings(this, Store.settings(this).copy(music = Sound.musicOn))
            Sound.refreshMusic()
            refresh()
        }
        bs.setOnClickListener {
            Sound.sfxOn = !Sound.sfxOn
            Store.saveSettings(this, Store.settings(this).copy(sfx = Sound.sfxOn))
            refresh()
        }
        refresh()
        row.addView(bm, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(5) })
        row.addView(bs, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(5) })
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
        dlg.setContentView(card)
        dlg.setOnCancelListener { g.paused = false }
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pauseDialog = dlg
        dlg.show()
        dlg.window?.setLayout(dp(320), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun abGameOver(score: Int, level: Int) {
        screen = "abover"
        val diff = abGame?.difficulty ?: 1
        abGame = null
        val best = AbacusStore.best(this)
        if (score > 0) AbacusStore.addScore(this, AbScore(score, "", level, diff))
        val record = score > best && score > 0
        abPage(
            listOf(
                abTitle(if (record) "Nowy rekord!" else "Świetna zabawa!", 32f).sized(MATCH, WRAP),
                abLabel("Twój wynik", 20f).sized(WRAP, WRAP, 24),
                abTitle("$score", 64f).sized(MATCH, WRAP),
                abLabel("Doszedłeś do poziomu $level", 18f).sized(WRAP, WRAP, 6),
                abLabel("Najlepszy wynik: ${maxOf(best, score)}", 16f).sized(WRAP, WRAP, 6),
                fancyButton("Zagraj jeszcze raz", 0xFF1F6B3A.toInt()) { startAbacus() }.sized(MATCH, dp(58), 28),
                fancyButton("Menu liczydła", 0xFF37383F.toInt()) { showAbMenu() }.sized(MATCH, dp(54), 12)
            )
        )
    }

    private fun showAbScores() {
        screen = "abscores"
        val list = AbacusStore.scores(this)
        val views = ArrayList<View>()
        views.add(abTitle("Top 5", 34f).sized(MATCH, WRAP))
        if (list.isEmpty()) {
            views.add(abLabel("Jeszcze brak wyników.\nZagraj pierwszą partię!", 18f).sized(WRAP, WRAP, 24))
        } else {
            val medal = intArrayOf(0xFFFFD54F.toInt(), 0xFFECEFF1.toInt(), 0xFFFFAB66.toInt())
            val dn = arrayOf("Łatwy x1", "Średni x2", "Trudny x3")
            list.forEachIndexed { i, s ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                    background = roundBg(0xCC1A1630.toInt(), 14, if (i < 3) medal[i] else 0xFF6A5FA8.toInt())
                }
                card.addView(label("${i + 1}.  ${s.score} pkt", 22f, if (i < 3) medal[i] else cream).sized(WRAP, WRAP))
                card.addView(label("Poziom ${s.level}  \u2022  ${dn[s.difficulty.coerceIn(0, 2)]}  \u2022  ${s.date}", 12f, 0xFFD1C4E9.toInt()).sized(WRAP, WRAP, 2))
                views.add(card.sized(MATCH, WRAP, 10))
            }
        }
        views.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showAbMenu() }.sized(MATCH, dp(52), 24))
        abPage(views)
    }

    private fun showAbSettings() {
        screen = "abset"
        var st = AbacusStore.settings(this)
        fun save() = AbacusStore.saveSettings(this, st)

        fun box(txt: String, on: Boolean) = CheckBox(this).apply {
            text = txt
            textSize = 20f
            setTextColor(cream)
            isChecked = on
            buttonTintList = ColorStateList.valueOf(gold)
        }
        val cbAdd = box("Dodawanie (+)", st.add)
        val cbSub = box("Odejmowanie (\u2212)", st.sub)
        val cbMul = box("Mnożenie (\u00D7)", st.mul)
        fun others(except: CheckBox) = listOf(cbAdd, cbSub, cbMul).filter { it !== except }.any { it.isChecked }
        cbAdd.setOnCheckedChangeListener { _, on ->
            if (!on && !others(cbAdd)) {
                cbAdd.isChecked = true
            } else {
                st = st.copy(add = on)
                save()
            }
        }
        cbSub.setOnCheckedChangeListener { _, on ->
            if (!on && !others(cbSub)) {
                cbSub.isChecked = true
            } else {
                st = st.copy(sub = on)
                save()
            }
        }
        cbMul.setOnCheckedChangeListener { _, on ->
            if (!on && !others(cbMul)) {
                cbMul.isChecked = true
            } else {
                st = st.copy(mul = on)
                save()
            }
        }

        val tvFrom = abLabel("Od: ${st.min}", 18f)
        val tvTo = abLabel("Do: ${st.max}", 18f)
        val sbFrom = SeekBar(this).apply {
            max = 99
            progress = st.min
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        val sbTo = SeekBar(this).apply {
            max = 99
            progress = st.max - 1
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        sbFrom.setOnSeekBarChangeListener(onSeek { p ->
            var hi = st.max
            if (p >= hi) {
                hi = p + 1
                sbTo.progress = hi - 1
            }
            st = st.copy(min = p, max = hi)
            tvFrom.text = "Od: $p"
            tvTo.text = "Do: $hi"
            save()
        })
        sbTo.setOnSeekBarChangeListener(onSeek { p ->
            val hi = p + 1
            var lo = st.min
            if (hi <= lo) {
                lo = hi - 1
                sbFrom.progress = lo
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })

        val rg = RadioGroup(this)
        val names = arrayOf(
            "Łatwy \u2013 60 s (punkty x1)",
            "Średni \u2013 40 s (punkty x2)",
            "Trudny \u2013 30 s, start od pustego liczydła, bez podglądu cyfr (punkty x3)"
        )
        names.forEachIndexed { i, txt ->
            rg.addView(RadioButton(this).apply {
                id = 2000 + i
                text = txt
                textSize = 17f
                setTextColor(cream)
                buttonTintList = ColorStateList.valueOf(gold)
            })
        }
        rg.check(2000 + st.difficulty)
        rg.setOnCheckedChangeListener { _, id ->
            st = st.copy(difficulty = id - 2000)
            save()
        }

        abPage(
            listOf(
                abTitle("Ustawienia liczydła", 28f).sized(MATCH, WRAP),
                abLabel("Działania", 20f, gold).sized(WRAP, WRAP, 20),
                cbAdd.sized(WRAP, WRAP, 4),
                cbSub.sized(WRAP, WRAP, 4),
                cbMul.sized(WRAP, WRAP, 4),
                abLabel("Zakres liczb", 20f, gold).sized(WRAP, WRAP, 20),
                tvFrom.sized(WRAP, WRAP, 6),
                sbFrom.sized(MATCH, WRAP),
                tvTo.sized(WRAP, WRAP, 6),
                sbTo.sized(MATCH, WRAP),
                abLabel("Czas i poziom trudności", 20f, gold).sized(WRAP, WRAP, 20),
                rg.sized(MATCH, WRAP, 4),
                abLabel("Co 5 zadań poziom rośnie, a liczby są większe.\nZa mnożenie liczydło startuje od zera.", 13f).sized(WRAP, WRAP, 10),
                fancyButton("Wróć", 0xFF37383F.toInt()) { showAbMenu() }.sized(MATCH, dp(52), 20)
            )
        )
    }
}
