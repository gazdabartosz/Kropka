package com.example.fairymath

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Dźwięki i muzyka generowane w całości w kodzie (bez plików). */
object Sound {
    const val KEY = 0
    const val SHOOT = 1
    const val HIT = 2
    const val DEATH = 3
    const val HURT = 4
    const val HEAL = 5
    const val LEVEL = 6
    const val BOSS = 7
    const val CHEST = 8
    const val REWARD = 9
    const val PICK = 10
    const val OVER = 11

    private const val SR = 22050

    @Volatile var sfxOn = true
    @Volatile var musicOn = true

    @Volatile private var ready = false
    private var started = false
    private var sfx: Array<ShortArray> = emptyArray()
    private var music: ShortArray? = null
    private var musicTrack: AudioTrack? = null
    private var wantMusic = false
    private var active = 0
    private val handler = Handler(Looper.getMainLooper())

    fun init() {
        if (started) return
        started = true
        Thread {
            try {
                sfx = buildSfx()
                music = buildMusic()
                ready = true
                handler.post { refreshMusic() }
            } catch (e: Throwable) {
                // brak dźwięku nie może zatrzymać gry
            }
        }.start()
    }

    // ---------- odtwarzanie ----------

    fun play(id: Int) {
        if (!sfxOn || !ready || id < 0 || id >= sfx.size || active >= 10) return
        val d = sfx[id]
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(d.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(d, 0, d.size)
            t.setVolume(0.8f)
            t.play()
            active++
            handler.postDelayed({
                try {
                    t.release()
                } catch (e: Exception) {
                }
                active--
            }, d.size * 1000L / SR + 200L)
        } catch (e: Exception) {
        }
    }

    fun musicStart() {
        wantMusic = true
        refreshMusic()
    }

    fun musicPause() {
        wantMusic = false
        refreshMusic()
    }

    fun refreshMusic() {
        val m = music
        if (!ready || m == null) return
        try {
            if (wantMusic && musicOn) {
                if (musicTrack == null) {
                    val t = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setSampleRate(SR)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(m.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()
                    t.write(m, 0, m.size)
                    t.setLoopPoints(0, m.size, -1)
                    t.setVolume(0.3f)
                    musicTrack = t
                }
                musicTrack?.play()
            } else {
                musicTrack?.pause()
            }
        } catch (e: Exception) {
        }
    }

    // ---------- synteza ----------

    private fun wave(kind: Int, ph: Double): Double = when (kind) {
        0 -> sin(ph)
        1 -> if (sin(ph) >= 0.0) 0.6 else -0.6
        2 -> 2.0 * ((ph / (2 * PI)) % 1.0) - 1.0
        else -> Random.nextDouble() * 2.0 - 1.0
    }

    /** Ton z płynną zmianą wysokości i zanikiem. kind: 0 sinus, 1 prostokąt, 2 piła, 3 szum. */
    private fun tone(b: FloatArray, start: Float, dur: Float, f0: Float, f1: Float, vol: Float, kind: Int) {
        val s0 = (start * SR).toInt()
        val n = (dur * SR).toInt()
        var ph = 0.0
        val att = max(1, (0.004f * SR).toInt())
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= b.size) break
            val t = i.toFloat() / n
            val f = f0 + (f1 - f0) * t
            ph += 2 * PI * f / SR
            val env = min(1f, i.toFloat() / att) * (1f - t) * (1f - t)
            b[idx] += (wave(kind, ph) * env * vol).toFloat()
        }
    }

    private fun toShorts(b: FloatArray, peak: Float): ShortArray {
        var mx = 0.0001f
        for (v in b) mx = max(mx, abs(v))
        val k = min(1f, peak / mx) * 32767f
        return ShortArray(b.size) { (b[it] * k).toInt().coerceIn(-32767, 32767).toShort() }
    }

    private fun mk(sec: Float, f: (FloatArray) -> Unit): ShortArray {
        val b = FloatArray((sec * SR).toInt())
        f(b)
        return toShorts(b, 0.85f)
    }

    private fun buildSfx(): Array<ShortArray> {
        val list = ArrayList<ShortArray>()
        // KEY
        list.add(mk(0.06f) { tone(it, 0f, 0.05f, 900f, 700f, 0.5f, 0) })
        // SHOOT
        list.add(mk(0.25f) {
            tone(it, 0f, 0.2f, 1000f, 300f, 0.3f, 2)
            tone(it, 0f, 0.2f, 0f, 0f, 0.25f, 3)
        })
        // HIT
        list.add(mk(0.25f) {
            tone(it, 0f, 0.15f, 0f, 0f, 0.6f, 3)
            tone(it, 0f, 0.22f, 220f, 70f, 0.6f, 0)
        })
        // DEATH
        list.add(mk(0.5f) {
            tone(it, 0f, 0.4f, 650f, 110f, 0.4f, 0)
            tone(it, 0f, 0.3f, 0f, 0f, 0.25f, 3)
            tone(it, 0.05f, 0.3f, 300f, 60f, 0.25f, 1)
        })
        // HURT
        list.add(mk(0.45f) {
            tone(it, 0f, 0.4f, 240f, 60f, 0.6f, 2)
            tone(it, 0f, 0.4f, 120f, 50f, 0.35f, 1)
            tone(it, 0f, 0.1f, 0f, 0f, 0.4f, 3)
        })
        // HEAL
        list.add(mk(0.6f) {
            val fs = floatArrayOf(523f, 659f, 784f, 1047f)
            for (i in fs.indices) tone(it, i * 0.07f, 0.25f, fs[i], fs[i], 0.4f, 0)
        })
        // LEVEL
        list.add(mk(1.0f) {
            val fs = floatArrayOf(392f, 523f, 659f, 784f)
            for (i in fs.indices) {
                val d = if (i == 3) 0.6f else 0.2f
                tone(it, i * 0.13f, d, fs[i], fs[i], 0.3f, 1)
                tone(it, i * 0.13f, d, fs[i] * 2, fs[i] * 2, 0.15f, 0)
            }
        })
        // BOSS
        list.add(mk(1.0f) {
            tone(it, 0f, 0.9f, 85f, 55f, 0.55f, 2)
            tone(it, 0f, 0.9f, 90f, 58f, 0.4f, 2)
            tone(it, 0.4f, 0.5f, 60f, 40f, 0.5f, 1)
        })
        // CHEST
        list.add(mk(0.7f) {
            tone(it, 0f, 0.25f, 180f, 280f, 0.35f, 2)
            tone(it, 0.25f, 0.3f, 280f, 140f, 0.35f, 2)
            tone(it, 0.5f, 0.15f, 0f, 0f, 0.2f, 3)
        })
        // REWARD
        list.add(mk(0.8f) {
            val fs = floatArrayOf(880f, 1175f, 1480f, 1760f, 2093f)
            for (i in fs.indices) tone(it, i * 0.08f, 0.3f, fs[i], fs[i], 0.3f, 0)
        })
        // PICK
        list.add(mk(0.5f) {
            tone(it, 0f, 0.15f, 784f, 784f, 0.45f, 0)
            tone(it, 0.09f, 0.35f, 1175f, 1175f, 0.45f, 0)
        })
        // OVER
        list.add(mk(1.6f) {
            val fs = floatArrayOf(392f, 330f, 262f, 196f)
            for (i in fs.indices) {
                tone(it, i * 0.32f, 0.5f, fs[i], fs[i] * 0.97f, 0.3f, 2)
            }
        })
        return list.toTypedArray()
    }

    private fun hz(root: Float, semis: Int): Float = root * 2.0.pow(semis / 12.0).toFloat()

    /** Nuta z zawijaniem na końcu pętli, żeby muzyka zapętlała się bez trzasku. */
    private fun note(b: FloatArray, startS: Int, durS: Int, freq: Float, vol: Float, attackS: Int, decayPow: Float, harm: Float) {
        var ph = 0.0
        val a = max(1, attackS)
        for (i in 0 until durS) {
            val t = i.toFloat() / durS
            ph += 2 * PI * freq / SR
            val env = min(1f, i.toFloat() / a) * (1f - t).pow(decayPow)
            val v = sin(ph) + harm * sin(ph * 2) + harm * 0.5 * sin(ph * 3)
            b[(startS + i) % b.size] += (v * env * vol).toFloat()
        }
    }

    private fun buildMusic(): ShortArray {
        val bpm = 92f
        val beatS = (60f / bpm * SR).toInt()
        val bars = 8
        val total = bars * 4 * beatS
        val b = FloatArray(total)
        val roots = floatArrayOf(110f, 87.31f, 73.42f, 82.41f) // Am, F, Dm, E
        val tones = arrayOf(
            intArrayOf(0, 3, 7), intArrayOf(0, 4, 7), intArrayOf(0, 3, 7), intArrayOf(0, 4, 8)
        )
        val patterns = arrayOf(
            intArrayOf(2, 4, 3, 1, 2, 0, 1),
            intArrayOf(4, 3, 2, 4, 5, 3, 2),
            intArrayOf(3, 2, 1, 3, 4, 2, 0),
            intArrayOf(2, 3, 5, 4, 3, 1, 2)
        )
        val mBeats = floatArrayOf(0f, 1.5f, 2f, 3.5f, 4f, 5.5f, 6f)
        val mLen = floatArrayOf(1.5f, 0.5f, 1.5f, 0.5f, 1.5f, 0.5f, 2f)
        val arpPat = intArrayOf(0, 1, 2, 1, 2, 1, 2, 1)

        for (bar in 0 until bars) {
            val ci = bar / 2
            val root = roots[ci]
            val tn = tones[ci]
            val ext = IntArray(6) { if (it < 3) tn[it] else tn[it - 3] + 12 }
            val barS = bar * 4 * beatS
            // pad
            for (k in 0..2) {
                note(b, barS, beatS * 4 + beatS / 2, hz(root * 2f, tn[k]), 0.05f, beatS, 0.6f, 0.15f)
            }
            // bas
            note(b, barS, (beatS * 1.6f).toInt(), root, 0.32f, 300, 1.4f, 0.3f)
            note(b, barS + beatS * 2, (beatS * 1.6f).toInt(), root, 0.26f, 300, 1.4f, 0.3f)
            // arpeggio
            for (e in 0 until 8) {
                val st = barS + e * beatS / 2
                note(b, st, beatS / 2 + beatS / 4, hz(root * 4f, ext[arpPat[e]]), 0.055f, 100, 2.2f, 0.4f)
            }
            // perkusja
            for (kb in intArrayOf(0, 2)) {
                val st = barS + kb * beatS
                var ph = 0.0
                val dur = (0.16f * SR).toInt()
                for (i in 0 until dur) {
                    val t = i.toFloat() / dur
                    ph += 2 * PI * (120f - 80f * t) / SR
                    b[(st + i) % total] += (sin(ph) * (1f - t) * 0.45f).toFloat()
                }
            }
            for (sb in intArrayOf(1, 3)) {
                val st = barS + sb * beatS
                val dur = (0.06f * SR).toInt()
                for (i in 0 until dur) {
                    val t = i.toFloat() / dur
                    b[(st + i) % total] += ((Random.nextFloat() * 2f - 1f) * (1f - t) * 0.06f)
                }
            }
            // melodia co dwa takty
            if (bar % 2 == 0) {
                val pat = patterns[ci]
                for (m in pat.indices) {
                    val st = barS + (mBeats[m] * beatS).toInt()
                    val du = (mLen[m] * beatS).toInt()
                    note(b, st, du, hz(root * 2f, ext[pat[m]] + 12), 0.1f, 400, 1.2f, 0.25f)
                }
            }
        }
        return toShorts(b, 0.8f)
    }
}
