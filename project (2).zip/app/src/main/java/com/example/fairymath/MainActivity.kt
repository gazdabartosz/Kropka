package com.example.fairymath

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Animowana postać na ekranach menu. */
class PreviewView(context: Context, private val kind: Int) : View(context) {
    override fun onDraw(canvas: Canvas) {
        val t = System.nanoTime() / 1_000_000_000f
        Art.drawHero(canvas, kind, width / 2f, height * 0.95f, height * 0.78f, t * 6f, 0f, 0, 1f)
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {

    private var game: GameView? = null
    private var pauseDialog: AlertDialog? = null
    private var screen = "menu"

    private val gold = 0xFFFFD54F.toInt()
    private val cream = 0xFFEDE7D0.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMenu()
    }

    override fun onPause() {
        super.onPause()
        val g = game
        if (screen == "game" && g != null && !g.paused) {
            g.paused = true
            g.tapToResume = true
        }
    }

    override fun onBackPressed() {
        when (screen) {
            "menu" -> super.onBackPressed()
            "game" -> showPauseDialog()
            else -> showMenu()
        }
    }

    // ---------- pomocnicy interfejsu ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun bg() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt())
    )

    private fun roundBg(color: Int, radiusDp: Int, strokeColor: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(2), strokeColor)
        }

    private fun <T : View> T.sized(w: Int, h: Int, top: Int = 0): T {
        layoutParams = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
        return this
    }

    private fun fancyButton(label: String, color: Int, size: Float = 20f, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = size
            setTextColor(gold)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            background = RippleDrawable(ColorStateList.valueOf(0x66FFFFFF), roundBg(color, 12, gold), null)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun titleView(label: String, size: Float = 34f) = TextView(this).apply {
        text = label
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(gold)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        setShadowLayer(10f, 0f, 3f, 0xFF000000.toInt())
    }

    private fun label(txt: String, size: Float = 20f, color: Int = cream) = TextView(this).apply {
        text = txt
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }

    private fun page(views: List<View>) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }
        views.forEach { col.addView(it) }
        val scroll = ScrollView(this).apply {
            background = bg()
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        setContentView(scroll)
    }

    // ---------- ekrany ----------

    private fun showMenu() {
        screen = "menu"
        game = null
        val heroes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (k in 0..2) addView(PreviewView(this@MainActivity, k).sized(dp(90), dp(130)))
        }
        val hasSave = Store.loadGame(this) != null
        val load = fancyButton("Wczytaj grę", 0xFF1B3A57.toInt()) {
            val sv = Store.loadGame(this)
            if (sv != null) startGame(sv.character, sv)
        }
        load.isEnabled = hasSave
        load.alpha = if (hasSave) 1f else 0.45f

        page(
            listOf(
                titleView("KRAINY\nLICZB", 44f).sized(MATCH, WRAP),
                label("Matematyczna wyprawa przez krainy fantasy", 14f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 4),
                heroes.sized(MATCH, WRAP, 8),
                fancyButton("Nowa gra", 0xFF7B1F2E.toInt()) { showCharacterSelect() }.sized(MATCH, dp(56), 16),
                load.sized(MATCH, dp(56), 12),
                fancyButton("Wyniki", 0xFF3E2A5E.toInt()) { showScores() }.sized(MATCH, dp(56), 12),
                fancyButton("Ustawienia", 0xFF2A3F5E.toInt()) { showSettings() }.sized(MATCH, dp(56), 12),
                fancyButton("Wyjdź", 0xFF37383F.toInt()) { finish() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showCharacterSelect() {
        screen = "select"
        val views = ArrayList<View>()
        views.add(titleView("Wybierz bohatera", 30f).sized(MATCH, WRAP))
        for (k in 0..2) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(14), dp(8))
                background = roundBg(0xCC1A1630.toInt(), 14, gold)
                setOnClickListener { startGame(k, null) }
            }
            card.addView(PreviewView(this, k).sized(dp(100), dp(130)))
            val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            txt.addView(label(Art.heroName(k), 22f, gold).sized(WRAP, WRAP))
            txt.addView(label(Art.heroDesc(k), 16f).sized(WRAP, WRAP, 4))
            txt.addView(label("Nowa broń co 5 poziomów", 12f, 0xFFB0A8D8.toInt()).sized(WRAP, WRAP, 6))
            card.addView(txt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })
            views.add(card.sized(MATCH, WRAP, 12))
        }
        views.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 20))
        page(views)
    }

    private fun startGame(character: Int, save: SaveState?) {
        screen = "game"
        val cfg = Store.settings(this)
        val gv = GameView(this, cfg, character.coerceIn(0, 2), save)
        gv.listener = object : GameView.Listener {
            override fun onGameOver(score: Int) {
                if (game === gv) gameOver(score)
            }

            override fun onPauseRequested() {
                showPauseDialog()
            }
        }
        game = gv
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F0C29.toInt())
        }
        root.addView(gv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(keypad(gv), LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    private fun keypad(gv: GameView): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            setBackgroundColor(0xFF1A1630.toInt())
        }
        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9"),
            arrayOf("Cofnij", "0", "Zatwierdź")
        )
        for (row in rows) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in row) {
                val color = when (key) {
                    "Cofnij" -> 0xFF8A4B14.toInt()
                    "Zatwierdź" -> 0xFF1F6B3A.toInt()
                    else -> 0xFF3A2E66.toInt()
                }
                val size = if (key.length > 2) 15f else 24f
                val b = fancyButton(key, color, size) {
                    when (key) {
                        "Cofnij" -> gv.backspace()
                        "Zatwierdź" -> gv.submit()
                        else -> gv.pressDigit(key.toInt())
                    }
                }
                r.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            col.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return col
    }

    private fun showPauseDialog() {
        val g = game ?: return
        if (pauseDialog?.isShowing == true) return
        g.paused = true
        g.tapToResume = false
        pauseDialog = AlertDialog.Builder(this)
            .setTitle("Pauza")
            .setItems(arrayOf("Wznów grę", "Zapisz i wyjdź do menu", "Wyjdź bez zapisu")) { _, which ->
                when (which) {
                    0 -> {
                        g.paused = false
                    }
                    1 -> {
                        Store.saveGame(this, g.snapshot())
                        Toast.makeText(this, "Gra zapisana", Toast.LENGTH_SHORT).show()
                        showMenu()
                    }
                    else -> {
                        showMenu()
                    }
                }
            }
            .setOnCancelListener { g.paused = false }
            .show()
    }

    private fun gameOver(score: Int) {
        screen = "over"
        val lvl = game?.level ?: 1
        game = null
        Store.clearGame(this)
        val best = Store.best(this)
        if (score > 0) Store.addScore(this, score)
        val record = score > best && score > 0
        val msg = if (record) "Nowy rekord!" else "Najlepszy wynik: $best"
        page(
            listOf(
                titleView("Koniec wyprawy", 34f).sized(MATCH, WRAP),
                label("Twój wynik", 20f).sized(WRAP, WRAP, 24),
                titleView("$score", 64f).sized(MATCH, WRAP),
                label("Dotarłeś do poziomu $lvl", 18f).sized(WRAP, WRAP, 4),
                label(msg, 18f, gold).sized(WRAP, WRAP, 8),
                fancyButton("Zagraj jeszcze raz", 0xFF7B1F2E.toInt()) { showCharacterSelect() }
                    .sized(MATCH, dp(56), 28),
                fancyButton("Menu", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showScores() {
        screen = "scores"
        val list = Store.scores(this)
        val views = ArrayList<View>()
        views.add(titleView("Wyniki", 34f).sized(MATCH, WRAP))
        if (list.isEmpty()) {
            views.add(label("Jeszcze brak wyników.\nWyrusz na pierwszą wyprawę!", 18f).sized(WRAP, WRAP, 24))
        } else {
            list.forEachIndexed { i, e ->
                views.add(label("${i + 1}.   ${e.score} pkt    ${e.date}", 20f).sized(WRAP, WRAP, 10))
            }
        }
        views.add(fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 28))
        page(views)
    }

    private fun onSeek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            f(progress)
        }

        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    }

    private fun tintBox(cb: CheckBox) {
        cb.buttonTintList = ColorStateList.valueOf(gold)
    }

    private fun showSettings() {
        screen = "settings"
        var st = Store.settings(this)
        fun save() = Store.saveSettings(this, st)

        fun box(txt: String, on: Boolean) = CheckBox(this).apply {
            text = txt
            textSize = 20f
            setTextColor(cream)
            isChecked = on
            tintBox(this)
        }

        val cbAdd = box("Dodawanie (+)", st.add)
        val cbSub = box("Odejmowanie (−)", st.sub)
        val cbMul = box("Mnożenie (×)", st.mul)
        fun others(except: CheckBox) = listOf(cbAdd, cbSub, cbMul).filter { it !== except }.any { it.isChecked }

        cbAdd.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbAdd)) {
                cbAdd.isChecked = true
            } else {
                st = st.copy(add = checked)
                save()
            }
        }
        cbSub.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbSub)) {
                cbSub.isChecked = true
            } else {
                st = st.copy(sub = checked)
                save()
            }
        }
        cbMul.setOnCheckedChangeListener { _, checked ->
            if (!checked && !others(cbMul)) {
                cbMul.isChecked = true
            } else {
                st = st.copy(mul = checked)
                save()
            }
        }

        val tvFrom = label("Od: ${st.min}", 18f)
        val tvTo = label("Do: ${st.max}", 18f)
        val sbFrom = SeekBar(this).apply {
            max = 99
            progress = st.min
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        val sbTo = SeekBar(this).apply {
            max = 99
            progress = st.max - 1
            progressTintList = ColorStateList.valueOf(gold)
            thumbTintList = ColorStateList.valueOf(gold)
        }
        sbFrom.setOnSeekBarChangeListener(onSeek { p ->
            val lo = p
            var hi = st.max
            if (lo >= hi) {
                hi = lo + 1
                sbTo.progress = hi - 1
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })
        sbTo.setOnSeekBarChangeListener(onSeek { p ->
            val hi = p + 1
            var lo = st.min
            if (hi <= lo) {
                lo = hi - 1
                sbFrom.progress = lo
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })

        val rg = RadioGroup(this)
        val names = arrayOf("Łatwy – dużo czasu (15 s)", "Średni (10 s)", "Trudny – mało czasu (5 s)")
        names.forEachIndexed { i, txt ->
            rg.addView(RadioButton(this).apply {
                id = 1000 + i
                text = txt
                textSize = 18f
                setTextColor(cream)
                buttonTintList = ColorStateList.valueOf(gold)
            })
        }
        rg.check(1000 + st.difficulty)
        rg.setOnCheckedChangeListener { _, id ->
            st = st.copy(difficulty = id - 1000)
            save()
        }

        page(
            listOf(
                titleView("Ustawienia", 34f).sized(MATCH, WRAP),
                label("Działania", 20f, gold).sized(WRAP, WRAP, 20),
                cbAdd.sized(WRAP, WRAP, 4),
                cbSub.sized(WRAP, WRAP, 4),
                cbMul.sized(WRAP, WRAP, 4),
                label("Zakres liczb", 20f, gold).sized(WRAP, WRAP, 20),
                tvFrom.sized(WRAP, WRAP, 6),
                sbFrom.sized(MATCH, WRAP),
                tvTo.sized(WRAP, WRAP, 6),
                sbTo.sized(MATCH, WRAP),
                label("Czas na odpowiedź", 20f, gold).sized(WRAP, WRAP, 20),
                rg.sized(MATCH, WRAP, 4),
                label("Z każdym poziomem liczby rosną, a czas się skraca.\nNa bossa masz 2x więcej czasu.", 13f).sized(WRAP, WRAP, 8),
                fancyButton("Wróć", 0xFF37383F.toInt()) { showMenu() }.sized(MATCH, dp(52), 20)
            )
        )
    }
}
