package com.example.dotapp

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

class DotView(context: Context) : View(context) {

    // Średnica 1 cm = 10 mm, czyli promień 5 mm
    private val radius = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_MM, 5f, resources.displayMetrics
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = randomColor() }

    private var x = -1f
    private var y = -1f
    private var dx: Float
    private var dy: Float
    private var lastFrameNs = 0L

    var speedPxPerSec = 300f
    var onDotClicked: (() -> Unit)? = null

    init {
        val angle = Random.nextDouble(0.0, Math.PI * 2)
        dx = cos(angle).toFloat()
        dy = sin(angle).toFloat()
    }

    private fun randomColor(): Int =
        Color.HSVToColor(floatArrayOf(Random.nextFloat() * 360f, 0.9f, 1f))

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (x < 0f) {
            x = width / 2f
            y = height / 2f
        }

        val now = System.nanoTime()
        val dt = if (lastFrameNs == 0L) 0f
        else ((now - lastFrameNs) / 1_000_000_000f).coerceAtMost(0.05f)
        lastFrameNs = now

        x += dx * speedPxPerSec * dt
        y += dy * speedPxPerSec * dt

        if (x < radius) { x = radius; dx = -dx }
        if (x > width - radius) { x = width - radius; dx = -dx }
        if (y < radius) { y = radius; dy = -dy }
        if (y > height - radius) { y = height - radius; dy = -dy }

        canvas.drawCircle(x, y, radius, paint)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            // Trochę większa strefa trafienia, bo kropka się rusza
            if (hypot(event.x - x, event.y - y) <= radius * 1.5f) {
                paint.color = randomColor()
                onDotClicked?.invoke()
            }
            return true
        }
        return super.onTouchEvent(event)
    }
}

class MainActivity : Activity() {

    private var clicks = 0

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
        ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val counter = TextView(this).apply {
            text = "Kliknięcia: 0"
            textSize = 22f
        }
        val speedLabel = TextView(this).apply {
            text = "Prędkość"
            textSize = 14f
        }
        val seekBar = SeekBar(this).apply {
            max = 100
            progress = 30
        }
        val dotView = DotView(this)

        fun speedFor(progress: Int) = dp(40 + progress * 8).toFloat()
        dotView.speedPxPerSec = speedFor(seekBar.progress)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                dotView.speedPxPerSec = speedFor(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        dotView.onDotClicked = {
            clicks++
            counter.text = "Kliknięcia: $clicks"
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
            addView(counter)
            addView(speedLabel)
            addView(seekBar)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(panel)
            addView(
                dotView,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
                )
            )
        }
        setContentView(root)
    }
}
