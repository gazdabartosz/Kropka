package com.example.fairymath

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

class GameView(
    context: Context,
    private val cfg: GameSettings,
    val character: Int,
    start: SaveState?
) : View(context) {

    interface Listener {
        fun onGameOver(score: Int)
        fun onPauseRequested()
    }

    var listener: Listener? = null
    var paused = false
    var tapToResume = false

    var score = start?.score ?: 0
        private set
    var lives = start?.lives ?: 5
        private set
    var level = start?.level ?: 1
        private set
    private var progress = start?.progress ?: 0

    private class Enc(
        val bonus: Boolean,
        val a: Int,
        val b: Int,
        val plus: Boolean,
        val answer: Int,
        val total: Float
    ) {
        var left = total
        var x = 0f
        var y = 0f
        var phase = 0 // 0 podchodzi, 1 atakuje, 2 czar, 3 odchodzi
        var timer = 0f
    }

    private class Friend(var x: Float, val kind: Int) {
        var ph = 0f
    }

    private class Spark(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val maxLife: Float, val color: Int, val size: Float
    )

    private class Pop(val text: String, var x: Float, var y: Float, var life: Float, val color: Int)

    private var enc: Enc? = null
    private val friends = ArrayList<Friend>()
    private val parts = ArrayList<Spark>()
    private val pops = ArrayList<Pop>()

    private var input = ""
    private var lastEq: String? = null
    private var lastOk = true
    private var lastBonus = false
    private var spawnDelay = 1.2f
    private var sinceBonus = 0
    private var bonusEvery = Random.nextInt(4, 7)

    private var t = 0f
    private var lastNs = 0L
    private var shake = 0f
    private var hitBlink = 0f
    private var flash = 0f
    private var castT = 0f
    private var over = false
    private var overTimer = 0f
    private var overFired = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rect = RectF()
    private var s = 1f
    private var sky: Shader? = null

    private val sparkCols = intArrayOf(
        0xFFFFEB3B.toInt(), 0xFFFF80AB.toInt(), 0xFF80D8FF.toInt(),
        0xFFFFFFFF.toInt(), 0xFFB388FF.toInt()
    )

    private val vw: Float get() = width.toFloat()
    private val vh: Float get() = height.toFloat()
    private val footY: Float get() = vh - 52f * s
    private val charX: Float get() = vw * 0.74f
    private val charH: Float get() = min(100f * s, max(footY - 150f * s, 40f * s))
    private val hitX: Float get() = charX - charH * 0.50f
    private val startX: Float get() = -charH * 0.4f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        s = w / 360f
        sky = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            0xFFFFD6EC.toInt(), 0xFFBEE7FF.toInt(), Shader.TileMode.CLAMP
        )
    }

    // ---------- API dla klawiatury ----------

    fun pressDigit(d: Int) {
        val e = enc ?: return
        if (e.phase != 0 || paused || input.length >= 3) return
        input = if (input == "0") d.toString() else input + d
    }

    fun backspace() {
        if (input.isNotEmpty()) input = input.dropLast(1)
    }

    fun submit() {
        val e = enc ?: return
        if (e.phase != 0 || paused || input.isEmpty()) return
        val v = input.toIntOrNull() ?: return
        input = ""
        if (v == e.answer) correct(e) else fail(e)
    }

    fun snapshot() = SaveState(character, score, max(1, lives), level, progress)

    // ---------- logika gry ----------

    private fun baseTime(): Float {
        val base = when (cfg.difficulty) {
            0 -> 22f
            1 -> 15f
            else -> 10f
        }
        return max(base * 0.5f, base * 0.93f.pow(level - 1))
    }

    private fun spawn() {
        val bonus = lives < 5 && sinceBonus >= bonusEvery
        val lo = cfg.min
        var hi = min(cfg.max + (level - 1) * 2, 100)
        if (bonus) hi = min(max(hi * 2, hi + 10), 100)
        if (hi <= lo) hi = lo + 1
        val plus = if (cfg.add && cfg.sub) Random.nextBoolean() else cfg.add
        var a = Random.nextInt(lo, hi + 1)
        var b = Random.nextInt(lo, hi + 1)
        if (!plus && b > a) {
            val tmp = a; a = b; b = tmp
        }
        val ans = if (plus) a + b else a - b
        val total = baseTime() * (if (bonus) 1.6f else 1f)
        val e = Enc(bonus, a, b, plus, ans, total)
        e.x = startX
        enc = e
        input = ""
        lastEq = null
    }

    private fun eqText(e: Enc, ans: String) =
        "${e.a} ${if (e.plus) "+" else "−"} ${e.b} = $ans"

    private fun correct(e: Enc) {
        lastEq = eqText(e, e.answer.toString())
        lastOk = true
        lastBonus = e.bonus
        castT = 0.5f
        if (e.bonus) {
            if (lives < 5) lives++
            sinceBonus = 0
            bonusEvery = Random.nextInt(4, 7)
            e.phase = 3
            burst(charX, footY - charH * 0.7f, 18, sparkCols, 150f * s)
            addPop("+1 ♥", charX, footY - charH * 1.15f, 0xFFE91E63.toInt())
        } else {
            score++
            sinceBonus++
            progress++
            e.phase = 2
            e.timer = 0.5f
            addPop("+1", e.x, footY - charH * 0.5f, 0xFF7B1FA2.toInt())
            if (progress >= 5) {
                progress = 0
                level++
                addPop("Poziom $level!", vw / 2f, 175f * s, 0xFFFF6F00.toInt())
                burst(vw / 2f, 175f * s, 24, sparkCols, 200f * s)
            }
        }
    }

    private fun fail(e: Enc) {
        lastEq = eqText(e, e.answer.toString())
        lastOk = false
        lastBonus = e.bonus
        input = ""
        if (e.bonus) {
            e.phase = 3
            addPop("Ups!", e.x, footY - charH * 0.8f, 0xFF8E24AA.toInt())
        } else {
            e.phase = 1
        }
    }

    private fun hit() {
        enc = null
        lives = max(0, lives - 1)
        shake = 0.45f
        hitBlink = 0.9f
        flash = 0.7f
        burst(
            charX - charH * 0.3f, footY - charH * 0.5f, 18,
            intArrayOf(0xFFE53935.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt()), 160f * s
        )
        addPop("-1 ♥", charX, footY - charH * 1.15f, 0xFFE53935.toInt())
        spawnDelay = 1.3f
        if (lives <= 0) {
            over = true
            overTimer = 1.5f
        }
    }

    private fun finishCast(e: Enc) {
        var k = Random.nextInt(Art.KINDS)
        if (k == character) k = (k + 1) % Art.KINDS
        friends.add(Friend(e.x, k))
        burst(e.x, footY - charH * 0.3f, 22, sparkCols, 160f * s)
        enc = null
        spawnDelay = 0.8f
    }

    private fun burst(x: Float, y: Float, n: Int, colors: IntArray, speed: Float) {
        repeat(n) {
            val ang = Random.nextFloat() * 6.2832f
            val sp = speed * (0.3f + Random.nextFloat())
            val life = 0.6f + Random.nextFloat() * 0.5f
            parts.add(
                Spark(
                    x, y, cos(ang) * sp, sin(ang) * sp, life, life,
                    colors.random(), (3f + Random.nextFloat() * 4f) * s
                )
            )
        }
    }

    private fun addPop(text: String, x: Float, y: Float, color: Int) {
        pops.add(Pop(text, x, y, 1.3f, color))
    }

    private fun step(dt: Float) {
        t += dt
        shake = max(0f, shake - dt)
        hitBlink = max(0f, hitBlink - dt)
        flash = max(0f, flash - dt * 1.5f)
        castT = max(0f, castT - dt)

        for (f in friends) {
            f.x += 230f * s * dt
            f.ph += dt * 9f
        }
        friends.removeAll { it.x > vw + 60f * s }
        for (p in parts) {
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 60f * s * dt
            p.life -= dt
        }
        parts.removeAll { it.life <= 0f }
        for (p in pops) {
            p.y -= 40f * s * dt
            p.life -= dt
        }
        pops.removeAll { it.life <= 0f }

        if (over) {
            overTimer -= dt
            if (overTimer <= 0f && !overFired) {
                overFired = true
                post { listener?.onGameOver(score) }
            }
        }

        val e = enc
        if (e == null) {
            if (!over) {
                spawnDelay -= dt
                if (spawnDelay <= 0f) spawn()
            }
        } else {
            stepEnc(e, dt)
        }
    }

    private fun stepEnc(e: Enc, dt: Float) {
        when (e.phase) {
            0 -> {
                e.left -= dt
                val f = 1f - (e.left / e.total).coerceIn(0f, 1f)
                e.x = startX + (hitX - startX) * f
                if (e.left <= 0f) fail(e)
            }
            1 -> {
                e.x += 800f * s * dt
                if (e.x >= hitX) hit()
            }
            2 -> {
                e.timer -= dt
                val tx = Art.wandTipX(charX, charH)
                val ty = Art.wandTipY(footY, charH)
                repeat(2) {
                    val k = Random.nextFloat()
                    val px = tx + (e.x - tx) * k
                    val py = ty + ((footY - charH * 0.2f) - ty) * k
                    parts.add(
                        Spark(
                            px, py, (Random.nextFloat() - 0.5f) * 40f * s, (Random.nextFloat() - 0.5f) * 40f * s,
                            0.5f, 0.5f, sparkCols.random(), (3f + Random.nextFloat() * 3f) * s
                        )
                    )
                }
                if (e.timer <= 0f) finishCast(e)
            }
            else -> {
                e.x += 220f * s * dt
                e.y -= 140f * s * dt
                if (e.x > vw + 60f * s) {
                    enc = null
                    spawnDelay = 0.8f
                }
            }
        }
    }

    // ---------- rysowanie ----------

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNs == 0L) 0f else ((now - lastNs) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNs = now
        if (paused) dt = 0f
        step(dt)

        canvas.save()
        if (shake > 0f) {
            canvas.translate((Random.nextFloat() - 0.5f) * 10f * s, (Random.nextFloat() - 0.5f) * 6f * s)
        }
        drawScene(canvas)
        drawActors(canvas)
        canvas.restore()
        drawHud(canvas)

        postInvalidateOnAnimation()
    }

    private fun fillP(color: Int): Paint {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = color
        return paint
    }

    private fun wrap(v: Float, m: Float): Float = ((v % m) + m) % m

    private fun hills(c: Canvas, base: Float, amp: Float, period: Float, off: Float, color: Int) {
        path.reset()
        path.moveTo(0f, vh)
        var x = 0f
        while (x <= vw + 12f * s) {
            path.lineTo(x, base + amp * sin((x + off) / period * 6.2832f))
            x += 12f * s
        }
        path.lineTo(vw + 12f * s, vh)
        path.close()
        c.drawPath(path, fillP(color))
    }

    private fun mushroom(c: Canvas, x: Float, baseY: Float, size: Float) {
        rect.set(x - size * 0.18f, baseY - size * 0.6f, x + size * 0.18f, baseY)
        c.drawRoundRect(rect, 4f * s, 4f * s, fillP(0xFFFFF3E0.toInt()))
        rect.set(x - size * 0.55f, baseY - size * 1.1f, x + size * 0.55f, baseY - size * 0.2f)
        c.drawArc(rect, 180f, 180f, false, fillP(0xFFE53935.toInt()))
        fillP(0xFFFFFFFF.toInt())
        c.drawCircle(x - size * 0.25f, baseY - size * 0.8f, size * 0.08f, paint)
        c.drawCircle(x + size * 0.15f, baseY - size * 0.9f, size * 0.09f, paint)
        c.drawCircle(x + size * 0.35f, baseY - size * 0.7f, size * 0.06f, paint)
        rect.set(x - size * 0.07f, baseY - size * 0.38f, x + size * 0.07f, baseY - size * 0.1f)
        c.drawRoundRect(rect, 3f * s, 3f * s, fillP(0xFFFFB300.toInt()))
    }

    private fun flower(c: Canvas, x: Float, y: Float, color: Int) {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * s
        paint.color = 0xFF558B2F.toInt()
        c.drawLine(x, y, x, y - 14f * s, paint)
        fillP(color)
        for (i in 0 until 5) {
            val a = i * 1.2566f
            c.drawCircle(x + cos(a) * 5f * s, y - 16f * s + sin(a) * 5f * s, 3.8f * s, paint)
        }
        c.drawCircle(x, y - 16f * s, 3f * s, fillP(0xFFFFFFFF.toInt()))
    }

    private fun tuft(c: Canvas, x: Float, y: Float) {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f * s
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = 0xFF689F38.toInt()
        c.drawLine(x, y, x - 5f * s, y - 12f * s, paint)
        c.drawLine(x, y, x, y - 15f * s, paint)
        c.drawLine(x, y, x + 5f * s, y - 12f * s, paint)
    }

    private fun drawScene(c: Canvas) {
        val fy = footY
        paint.reset()
        paint.shader = sky
        c.drawRect(0f, 0f, vw, vh, paint)
        paint.shader = null

        // chmurki
        for (i in 0..3) {
            val cx = wrap(i * 190f * s - t * 12f * s, vw + 200f * s) - 100f * s
            val cy = (170f + (i % 2) * 28f) * s
            c.drawCircle(cx, cy, 16f * s, fillP(0xCCFFFFFF.toInt()))
            c.drawCircle(cx + 18f * s, cy - 8f * s, 20f * s, paint)
            c.drawCircle(cx + 38f * s, cy, 15f * s, paint)
            rect.set(cx - 16f * s, cy - 2f * s, cx + 53f * s, cy + 15f * s)
            c.drawRoundRect(rect, 8f * s, 8f * s, paint)
        }

        // wzgórza (różna prędkość = efekt głębi)
        hills(c, fy - 55f * s, 22f * s, 260f * s, t * 14f * s, 0xFFC8E6C9.toInt())
        hills(c, fy - 25f * s, 14f * s, 170f * s, t * 36f * s, 0xFFA5D6A7.toInt())

        // grzybowe domki
        val sp1 = 240f * s
        val sc1 = t * 55f * s
        val k1 = floor(sc1 / sp1).toInt()
        for (k in k1..k1 + (vw / sp1).toInt() + 2) {
            val x = k * sp1 - sc1 + ((k * 37) % 50 - 25) * s
            val size = (46 + (k * 53) % 30) * s
            mushroom(c, x, fy - 10f * s, size)
        }

        // ziemia
        c.drawRect(0f, fy - 10f * s, vw, vh, fillP(0xFF8BC34A.toInt()))
        c.drawRect(0f, fy - 10f * s, vw, fy - 3f * s, fillP(0xFF9CCC65.toInt()))

        // kwiatki na pierwszym planie (najszybsze)
        val sp2 = 95f * s
        val sc2 = t * 120f * s
        val k2 = floor(sc2 / sp2).toInt()
        for (k in k2..k2 + (vw / sp2).toInt() + 2) {
            val x = k * sp2 - sc2 + ((k * 29) % 40) * s
            val y = fy + (14 + (k * 13) % 22) * s
            when (k % 3) {
                0 -> flower(c, x, y, 0xFFFF80AB.toInt())
                1 -> flower(c, x, y, 0xFFFFEB3B.toInt())
                else -> tuft(c, x, y)
            }
        }
    }

    private fun drawActors(c: Canvas) {
        val fy = footY
        val unit = charH * 0.24f

        val e = enc
        if (e != null) {
            if (e.bonus) {
                Art.drawLady(c, e.x, fy + e.y, unit * 1.05f, t * 10f)
            } else {
                if (e.phase == 2) {
                    c.drawCircle(e.x, fy - unit, unit * (1.7f + 0.3f * sin(t * 25f)), fillP(0x66FFFFFF.toInt()))
                }
                val hop = when (e.phase) {
                    0 -> abs(sin(t * 7f))
                    1 -> abs(sin(t * 14f))
                    else -> 0f
                }
                Art.drawFrog(c, e.x, fy, unit, hop)
            }
        }

        for (f in friends) {
            Art.drawPerson(c, f.kind, f.x, fy + 6f * s, charH * 0.75f, f.ph, 0f)
        }

        if (hitBlink <= 0f || (hitBlink * 12f).toInt() % 2 == 0) {
            Art.drawPerson(c, character, charX, fy, charH, t * 11f, castT / 0.5f)
        }

        for (p in parts) {
            val a = (255 * (p.life / p.maxLife).coerceIn(0f, 1f)).toInt()
            val col = (p.color and 0x00FFFFFF) or (a shl 24)
            c.drawCircle(p.x, p.y, p.size, fillP(col))
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = p.size * 0.4f
            c.drawLine(p.x - p.size * 1.8f, p.y, p.x + p.size * 1.8f, p.y, paint)
            c.drawLine(p.x, p.y - p.size * 1.8f, p.x, p.y + p.size * 1.8f, paint)
        }

        textP.textAlign = Paint.Align.CENTER
        textP.textSize = 24f * s
        for (p in pops) {
            val a = (255 * (p.life / 0.6f).coerceIn(0f, 1f)).toInt()
            textP.color = (p.color and 0x00FFFFFF) or (a shl 24)
            c.drawText(p.text, p.x, p.y, textP)
        }
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, r: Float, pt: Paint) {
        path.reset()
        path.moveTo(cx, cy + r * 0.9f)
        path.cubicTo(cx - r * 1.6f, cy - r * 0.1f, cx - r * 0.8f, cy - r * 1.3f, cx, cy - r * 0.4f)
        path.cubicTo(cx + r * 0.8f, cy - r * 1.3f, cx + r * 1.6f, cy - r * 0.1f, cx, cy + r * 0.9f)
        path.close()
        c.drawPath(path, pt)
    }

    private fun drawHud(c: Canvas) {
        // serca
        for (i in 0 until 5) {
            val cx = 22f * s + i * 27f * s
            if (i < lives) {
                heart(c, cx, 28f * s, 11f * s, fillP(0xFFE53935.toInt()))
            } else {
                paint.reset()
                paint.isAntiAlias = true
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f * s
                paint.color = 0xFFB39DDB.toInt()
                heart(c, cx, 28f * s, 11f * s, paint)
            }
        }

        // punkty i poziom
        textP.textAlign = Paint.Align.RIGHT
        textP.color = 0xFF4A148C.toInt()
        textP.textSize = 18f * s
        c.drawText("Punkty: $score", vw - 62f * s, 27f * s, textP)
        textP.textSize = 12f * s
        c.drawText("Poziom $level", vw - 62f * s, 44f * s, textP)

        // przycisk pauzy
        c.drawCircle(vw - 28f * s, 30f * s, 18f * s, fillP(0xFF7E57C2.toInt()))
        c.drawRect(vw - 34f * s, 22f * s, vw - 29f * s, 38f * s, fillP(0xFFFFFFFF.toInt()))
        c.drawRect(vw - 25f * s, 22f * s, vw - 20f * s, 38f * s, paint)

        // tablica z równaniem
        val e = enc
        val bonusNow = if (lastEq != null) lastBonus else (e?.bonus == true)
        rect.set(14f * s, 54f * s, vw - 14f * s, 118f * s)
        c.drawRoundRect(rect, 18f * s, 18f * s, fillP(if (bonusNow) 0xFFFFF59D.toInt() else 0xFFFFFFFF.toInt()))
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * s
        paint.color = if (bonusNow) 0xFFFFB300.toInt() else 0xFFBA68C8.toInt()
        c.drawRoundRect(rect, 18f * s, 18f * s, paint)

        if (bonusNow) {
            textP.textAlign = Paint.Align.CENTER
            textP.textSize = 12f * s
            textP.color = 0xFFFF6F00.toInt()
            c.drawText("BONUS! (odpowiedz, a odzyskasz serduszko)", vw / 2f, 72f * s, textP)
        }

        val txt = lastEq ?: (if (e != null) eqText(e, if (input.isEmpty()) "?" else input) else "Uwaga!")
        val col = when {
            lastEq != null && lastOk -> 0xFF2E7D32.toInt()
            lastEq != null -> 0xFFC62828.toInt()
            else -> 0xFF4A148C.toInt()
        }
        textP.textAlign = Paint.Align.CENTER
        textP.color = col
        textP.textSize = 34f * s
        val maxW = vw - 60f * s
        val wdt = textP.measureText(txt)
        if (wdt > maxW) textP.textSize = 34f * s * maxW / wdt
        c.drawText(txt, vw / 2f, 106f * s, textP)

        // pasek czasu
        rect.set(14f * s, 124f * s, vw - 14f * s, 136f * s)
        c.drawRoundRect(rect, 6f * s, 6f * s, fillP(0x332E1065))
        if (e != null && e.phase == 0) {
            val f = (e.left / e.total).coerceIn(0f, 1f)
            rect.set(14f * s, 124f * s, 14f * s + (vw - 28f * s) * f, 136f * s)
            fillP(Color.HSVToColor(floatArrayOf(120f * f, 0.75f, 0.9f)))
            c.drawRoundRect(rect, 6f * s, 6f * s, paint)
        }

        // czerwony błysk po trafieniu
        if (flash > 0f) {
            val a = (flash.coerceIn(0f, 1f) * 90).toInt()
            c.drawRect(0f, 0f, vw, vh, fillP((a shl 24) or 0xE53935))
        }

        // pauza
        if (paused) {
            c.drawRect(0f, 0f, vw, vh, fillP(0x99000000.toInt()))
            textP.color = 0xFFFFFFFF.toInt()
            textP.textSize = 40f * s
            c.drawText("Pauza", vw / 2f, vh / 2f, textP)
            if (tapToResume) {
                textP.textSize = 18f * s
                c.drawText("Dotknij ekranu, aby grać dalej", vw / 2f, vh / 2f + 34f * s, textP)
            }
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) {
            if (paused) {
                if (tapToResume) {
                    tapToResume = false
                    paused = false
                }
                return true
            }
            if (ev.x > vw - 56f * s && ev.y < 60f * s) listener?.onPauseRequested()
            return true
        }
        return super.onTouchEvent(ev)
    }
}
