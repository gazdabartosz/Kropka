package com.example.fairymath

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.sin

/** Wszystkie postacie są rysowane kodem (bez plików graficznych). To własne, oryginalne postacie. */
object Art {
    const val KINDS = 6
    private val NAMES = arrayOf("Wróżka", "Król", "Królowa", "Niania", "Elf", "Czarodziej")
    fun name(kind: Int): String = NAMES[kind]

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val SKIN = 0xFFFFDDB8.toInt()
    private val SHOE = 0xFF6D4C41.toInt()
    private val GOLD = 0xFFFFC107.toInt()
    private val DARK = 0xFF333333.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val DRESS = intArrayOf(
        0xFFFF6FB5.toInt(), 0xFF3F51B5.toInt(), 0xFF9C27B0.toInt(),
        0xFF26A69A.toInt(), 0xFF43A047.toInt(), 0xFF283593.toInt()
    )
    private val HAIR = intArrayOf(
        0xFFFFB300.toInt(), 0xFFBDBDBD.toInt(), 0xFF5D4037.toInt(),
        0xFFBDBDBD.toInt(), 0xFF8D6E63.toInt(), 0xFFBDBDBD.toInt()
    )

    private fun fill(color: Int): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = color
        return p
    }

    private fun stroke(color: Int, w: Float): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        return p
    }

    private fun ov(c: Canvas, l: Float, t: Float, r: Float, b: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawOval(rect, paint)
    }

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
    }

    private fun arc(c: Canvas, l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawArc(rect, start, sweep, false, paint)
    }

    // Czubek różdżki (do iskier czaru)
    fun wandTipX(cx: Float, h: Float): Float = cx + 0.36f * h
    fun wandTipY(footY: Float, h: Float): Float = footY - 0.783f * h

    fun drawPerson(c: Canvas, kind: Int, cx: Float, footY: Float, h: Float, phase: Float, cast: Float) {
        val r = h * 0.13f
        val headCy = footY - h * 0.70f
        val neckY = headCy + r * 0.9f
        val hemY = footY - h * 0.16f
        val sw = sin(phase)
        val raised = kind == 0 || cast > 0f
        val dress = DRESS[kind]
        val hair = HAIR[kind]

        // skrzydła (wróżka i niania)
        if (kind == 0 || kind == 3) {
            val flap = 0.75f + 0.25f * sin(phase * 2.2f)
            val col = if (kind == 0) 0xAAB3E5FC.toInt() else 0xAAFFF59D.toInt()
            for (i in 0..1) {
                val px = cx - h * 0.10f
                val py = neckY + h * (0.06f + i * 0.16f)
                c.save()
                c.rotate(if (i == 0) 40f else -25f, px, py)
                ov(c, px - h * 0.30f * flap, py - h * 0.07f, px, py + h * 0.07f, fill(col))
                c.restore()
            }
        }

        // długie włosy królowej (za postacią)
        if (kind == 2) {
            rr(c, cx - r * 1.3f, headCy - r * 0.9f, cx + r * 0.2f, headCy + r * 2.4f, r * 0.6f, fill(hair))
        }

        // nogi i buty
        val lw = h * 0.05f
        val footL = cx - h * 0.07f + sw * h * 0.07f
        val footR = cx + h * 0.07f - sw * h * 0.07f
        c.drawLine(cx - h * 0.07f, hemY, footL, footY - lw * 0.5f, stroke(SKIN, lw))
        c.drawLine(cx + h * 0.07f, hemY, footR, footY - lw * 0.5f, stroke(SKIN, lw))
        c.drawCircle(footL + lw * 0.4f, footY - lw * 0.5f, lw * 0.9f, fill(SHOE))
        c.drawCircle(footR + lw * 0.4f, footY - lw * 0.5f, lw * 0.9f, fill(SHOE))

        // ubranie
        path.reset()
        path.moveTo(cx - h * 0.13f, neckY)
        path.lineTo(cx + h * 0.13f, neckY)
        path.lineTo(cx + h * 0.23f, hemY)
        path.lineTo(cx - h * 0.23f, hemY)
        path.close()
        c.drawPath(path, fill(dress))

        val waist = neckY + (hemY - neckY) * 0.45f
        when (kind) {
            0 -> c.drawRect(cx - h * 0.22f, hemY - h * 0.035f, cx + h * 0.22f, hemY, fill(0xFFFFB3D9.toInt()))
            1 -> {
                c.drawRect(cx - h * 0.22f, hemY - h * 0.06f, cx + h * 0.22f, hemY, fill(WHITE))
                for (i in -1..1) c.drawCircle(cx + i * h * 0.1f, hemY - h * 0.03f, h * 0.011f, fill(DARK))
                c.drawRect(cx - h * 0.17f, waist, cx + h * 0.17f, waist + h * 0.03f, fill(GOLD))
            }
            2 -> c.drawRect(cx - h * 0.17f, waist, cx + h * 0.17f, waist + h * 0.03f, fill(GOLD))
            3 -> {
                path.reset()
                path.moveTo(cx - h * 0.07f, neckY + h * 0.08f)
                path.lineTo(cx + h * 0.07f, neckY + h * 0.08f)
                path.lineTo(cx + h * 0.17f, hemY)
                path.lineTo(cx - h * 0.17f, hemY)
                path.close()
                c.drawPath(path, fill(0xEEFFFFFF.toInt()))
            }
            4 -> c.drawRect(cx - h * 0.17f, waist, cx + h * 0.17f, waist + h * 0.035f, fill(0xFF6D4C41.toInt()))
            else -> {
                c.drawCircle(cx - h * 0.06f, neckY + h * 0.12f, h * 0.014f, fill(GOLD))
                c.drawCircle(cx + h * 0.07f, neckY + h * 0.2f, h * 0.014f, fill(GOLD))
                c.drawCircle(cx - h * 0.02f, neckY + h * 0.3f, h * 0.014f, fill(GOLD))
            }
        }

        // ręce
        val shY = neckY + h * 0.03f
        val backX = cx - h * 0.14f - sw * h * 0.03f
        val backY = shY + h * 0.17f
        c.drawLine(cx - h * 0.12f, shY, backX, backY, stroke(dress, h * 0.05f))
        c.drawCircle(backX, backY, h * 0.03f, fill(SKIN))
        val hx: Float
        val hy: Float
        if (raised) {
            hx = cx + h * 0.24f
            hy = neckY - h * 0.04f
        } else {
            hx = cx + h * 0.14f + sw * h * 0.05f
            hy = shY + h * 0.17f
        }
        c.drawLine(cx + h * 0.12f, shY, hx, hy, stroke(dress, h * 0.05f))
        c.drawCircle(hx, hy, h * 0.03f, fill(SKIN))

        // broda króla i czarodzieja (nad ubraniem, pod twarzą)
        if (kind == 1) {
            ov(c, cx - r * 0.95f, headCy - r * 0.1f, cx + r * 0.95f, headCy + r * 1.7f, fill(WHITE))
        }
        if (kind == 5) {
            path.reset()
            path.moveTo(cx - r * 0.85f, headCy + r * 0.2f)
            path.lineTo(cx + r * 0.85f, headCy + r * 0.2f)
            path.lineTo(cx, headCy + r * 3.4f)
            path.close()
            c.drawPath(path, fill(WHITE))
        }

        // uszy elfa
        if (kind == 4) {
            path.reset()
            path.moveTo(cx - r * 0.9f, headCy - r * 0.1f)
            path.lineTo(cx - r * 1.8f, headCy - r * 0.7f)
            path.lineTo(cx - r * 0.9f, headCy + r * 0.4f)
            path.close()
            c.drawPath(path, fill(SKIN))
            path.reset()
            path.moveTo(cx + r * 0.9f, headCy - r * 0.1f)
            path.lineTo(cx + r * 1.8f, headCy - r * 0.7f)
            path.lineTo(cx + r * 0.9f, headCy + r * 0.4f)
            path.close()
            c.drawPath(path, fill(SKIN))
        }

        // głowa i twarz
        c.drawCircle(cx, headCy, r, fill(SKIN))
        c.drawCircle(cx + r * 0.55f, headCy + r * 0.35f, r * 0.16f, fill(0x66FF5C8A.toInt()))
        c.drawCircle(cx + r * 0.05f, headCy - r * 0.05f, r * 0.11f, fill(DARK))
        c.drawCircle(cx + r * 0.6f, headCy - r * 0.05f, r * 0.11f, fill(DARK))
        arc(c, cx, headCy + r * 0.05f, cx + r * 0.7f, headCy + r * 0.6f, 20f, 140f, stroke(0xFFB23A48.toInt(), r * 0.08f))

        // włosy / nakrycia głowy
        when (kind) {
            0 -> {
                arc(c, cx - r * 1.08f, headCy - r * 1.3f, cx + r * 1.08f, headCy + r * 0.8f, 180f, 180f, fill(hair))
                c.drawCircle(cx - r * 0.95f, headCy - r * 0.55f, r * 0.5f, fill(hair))
            }
            1 -> {
                c.drawCircle(cx - r * 1.0f, headCy + r * 0.1f, r * 0.35f, fill(hair))
                crown(c, cx, headCy, r)
            }
            2 -> {
                arc(c, cx - r * 1.08f, headCy - r * 1.3f, cx + r * 1.08f, headCy + r * 0.8f, 180f, 180f, fill(hair))
                crown(c, cx, headCy, r)
            }
            3 -> {
                arc(c, cx - r * 1.08f, headCy - r * 1.3f, cx + r * 1.08f, headCy + r * 0.8f, 180f, 180f, fill(hair))
                c.drawCircle(cx - r * 0.3f, headCy - r * 1.35f, r * 0.5f, fill(hair))
                c.drawCircle(cx + r * 0.05f, headCy - r * 0.05f, r * 0.3f, stroke(DARK, r * 0.06f))
                c.drawCircle(cx + r * 0.6f, headCy - r * 0.05f, r * 0.3f, stroke(DARK, r * 0.06f))
            }
            4 -> {
                path.reset()
                path.moveTo(cx - r * 1.1f, headCy - r * 0.4f)
                path.lineTo(cx + r * 1.1f, headCy - r * 0.4f)
                path.quadTo(cx + r * 0.2f, headCy - r * 1.7f, cx - r * 1.2f, headCy - r * 2.3f)
                path.close()
                c.drawPath(path, fill(0xFFE53935.toInt()))
                c.drawCircle(cx - r * 1.2f, headCy - r * 2.3f, r * 0.3f, fill(WHITE))
            }
            else -> {
                ov(c, cx - r * 1.5f, headCy - r * 0.85f, cx + r * 1.5f, headCy - r * 0.35f, fill(0xFF4527A0.toInt()))
                path.reset()
                path.moveTo(cx - r * 0.9f, headCy - r * 0.6f)
                path.lineTo(cx + r * 0.9f, headCy - r * 0.6f)
                path.lineTo(cx + r * 0.2f, headCy - r * 3.2f)
                path.close()
                c.drawPath(path, fill(0xFF5E35B1.toInt()))
                c.drawCircle(cx + r * 0.1f, headCy - r * 1.6f, r * 0.18f, fill(GOLD))
            }
        }

        // różdżka
        if (raised) {
            val tx = hx + h * 0.12f
            val ty = hy - h * 0.16f
            c.drawLine(hx, hy, tx, ty, stroke(0xFF8D6E63.toInt(), h * 0.02f))
            if (cast > 0f) c.drawCircle(tx, ty, h * 0.09f * cast, fill(0x66FFF59D.toInt()))
            c.drawCircle(tx, ty, h * 0.04f, fill(GOLD))
        }
    }

    private fun crown(c: Canvas, cx: Float, headCy: Float, r: Float) {
        val base = headCy - r * 0.85f
        val hh = r * 0.75f
        path.reset()
        path.moveTo(cx - r * 0.8f, base)
        path.lineTo(cx - r * 0.8f, base - hh)
        path.lineTo(cx - r * 0.4f, base - hh * 0.4f)
        path.lineTo(cx, base - hh * 1.1f)
        path.lineTo(cx + r * 0.4f, base - hh * 0.4f)
        path.lineTo(cx + r * 0.8f, base - hh)
        path.lineTo(cx + r * 0.8f, base)
        path.close()
        c.drawPath(path, fill(GOLD))
        c.drawCircle(cx, base - r * 0.2f, r * 0.12f, fill(0xFFE53935.toInt()))
    }

    fun drawFrog(c: Canvas, cx: Float, footY: Float, s: Float, hop: Float) {
        val y = footY - hop * s * 0.9f
        val green = 0xFF66BB6A.toInt()
        val dark = 0xFF43A047.toInt()
        ov(c, cx - s * 1.15f, y - s * 0.7f, cx - s * 0.3f, y, fill(dark))
        ov(c, cx - s * 1.0f, y - s * 1.5f, cx + s * 0.95f, y - s * 0.1f, fill(green))
        ov(c, cx - s * 0.5f, y - s * 0.9f, cx + s * 0.85f, y - s * 0.1f, fill(0xFFC5E1A5.toInt()))
        ov(c, cx + s * 0.3f, y - s * 0.45f, cx + s * 1.1f, y, fill(dark))
        // oczy
        c.drawCircle(cx + s * 0.1f, y - s * 1.5f, s * 0.36f, fill(green))
        c.drawCircle(cx + s * 0.7f, y - s * 1.5f, s * 0.36f, fill(green))
        c.drawCircle(cx + s * 0.1f, y - s * 1.52f, s * 0.26f, fill(WHITE))
        c.drawCircle(cx + s * 0.7f, y - s * 1.52f, s * 0.26f, fill(WHITE))
        c.drawCircle(cx + s * 0.16f, y - s * 1.52f, s * 0.12f, fill(DARK))
        c.drawCircle(cx + s * 0.76f, y - s * 1.52f, s * 0.12f, fill(DARK))
        // buzia i policzek
        arc(c, cx + s * 0.2f, y - s * 1.05f, cx + s * 0.95f, y - s * 0.5f, 10f, 150f, stroke(0xFF2E7D32.toInt(), s * 0.07f))
        c.drawCircle(cx + s * 0.75f, y - s * 0.85f, s * 0.1f, fill(0x66FF5C8A.toInt()))
    }

    fun drawLady(c: Canvas, cx: Float, footY: Float, s: Float, phase: Float) {
        val y = footY - s * 0.2f + sin(phase) * s * 0.1f
        val fl = 0.6f + 0.4f * abs(sin(phase * 1.7f))
        // skrzydełka
        ov(c, cx - s * 0.8f, y - s * (1.7f + 0.9f * fl), cx + s * 0.2f, y - s * 1.6f, fill(0x99FFFFFF.toInt()))
        // nóżki
        for (i in 0..2) {
            val lx = cx - s * 0.5f + i * s * 0.5f
            c.drawLine(lx, y - s * 0.2f, lx + sin(phase + i) * s * 0.12f, footY, stroke(DARK, s * 0.08f))
        }
        // ciało
        c.drawCircle(cx, y - s * 1.0f, s, fill(0xFFE53935.toInt()))
        c.drawLine(cx - s * 0.1f, y - s * 2.0f, cx - s * 0.1f, y - s * 1.0f, stroke(DARK, s * 0.08f))
        c.drawCircle(cx - s * 0.45f, y - s * 1.35f, s * 0.2f, fill(DARK))
        c.drawCircle(cx + s * 0.25f, y - s * 1.5f, s * 0.18f, fill(DARK))
        c.drawCircle(cx - s * 0.1f, y - s * 0.75f, s * 0.16f, fill(DARK))
        // głowa z czułkami
        c.drawCircle(cx + s * 0.95f, y - s * 1.5f, s * 0.42f, fill(DARK))
        c.drawCircle(cx + s * 1.1f, y - s * 1.58f, s * 0.12f, fill(WHITE))
        c.drawLine(cx + s * 0.95f, y - s * 1.85f, cx + s * 0.8f, y - s * 2.3f, stroke(DARK, s * 0.07f))
        c.drawLine(cx + s * 1.1f, y - s * 1.85f, cx + s * 1.3f, y - s * 2.3f, stroke(DARK, s * 0.07f))
        // kosz piknikowy
        arc(c, cx + s * 0.7f, y - s * 1.2f, cx + s * 1.55f, y - s * 0.4f, 180f, 180f, stroke(0xFF6D4C41.toInt(), s * 0.08f))
        rr(c, cx + s * 0.55f, y - s * 0.7f, cx + s * 1.7f, y + s * 0.0f, s * 0.15f, fill(0xFFA1887F.toInt()))
        c.drawRect(cx + s * 0.5f, y - s * 0.85f, cx + s * 1.75f, y - s * 0.62f, fill(0xFFE53935.toInt()))
        for (i in 0..2) {
            c.drawRect(cx + s * (0.58f + i * 0.4f), y - s * 0.85f, cx + s * (0.78f + i * 0.4f), y - s * 0.74f, fill(WHITE))
        }
    }
}
