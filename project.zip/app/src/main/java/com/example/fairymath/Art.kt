package com.example.fairymath

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.sin

/** Wszystkie postacie i potwory są rysowane kodem. To własne, ogólne postacie fantasy. */
object Art {
    private val HERO_NAMES = arrayOf("Elf łucznik", "Czarodziejka", "Krasnolud")
    private val HERO_DESC = arrayOf("Strzela z łuku", "Rzuca czary", "Rzuca toporem")
    private val MON_NAMES = arrayOf("Goblin", "Szkielet", "Nietoperz", "Ork", "Galareta", "Duch", "Troll")
    private val WEAPONS = arrayOf(
        arrayOf("Strzały", "Płonące strzały", "Lodowe strzały", "Strzały burzy", "Strzały arkany"),
        arrayOf("Magiczny pocisk", "Kula ognia", "Lodowy pocisk", "Piorun", "Moc arkany"),
        arrayOf("Topór", "Płonący topór", "Lodowy topór", "Topór burzy", "Topór runiczny")
    )
    private val TIER_COLORS = intArrayOf(
        0xFFB3E5FC.toInt(), 0xFFFF7A18.toInt(), 0xFF4FC3F7.toInt(), 0xFFFFEB3B.toInt(), 0xFFB388FF.toInt()
    )

    fun heroName(k: Int) = HERO_NAMES[k]
    fun heroDesc(k: Int) = HERO_DESC[k]
    fun monsterName(k: Int) = MON_NAMES[k]
    fun weaponName(hero: Int, tier: Int) = WEAPONS[hero][tier.coerceIn(0, 4)]
    fun tierColor(tier: Int) = TIER_COLORS[tier.coerceIn(0, 4)]

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val DARK = 0xFF1E1E1E.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val GOLD = 0xFFFFC107.toInt()
    private val STEEL = 0xFFB0BEC5.toInt()

    private fun fill(color: Int): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = color
        return p
    }

    private fun stroke(color: Int, w: Float): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        return p
    }

    private fun ov(c: Canvas, l: Float, t: Float, r: Float, b: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawOval(rect, paint)
    }

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
    }

    private fun arc(c: Canvas, l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, paint: Paint) {
        rect.set(l, t, r, b)
        c.drawArc(rect, start, sweep, false, paint)
    }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, paint: Paint) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.close()
        c.drawPath(path, paint)
    }

    // Miejsce, z którego wylatuje pocisk
    fun muzzleX(cx: Float, h: Float): Float = cx + 0.34f * h
    fun muzzleY(footY: Float, h: Float): Float = footY - 0.60f * h

    // ================= BOHATEROWIE (patrzą w prawo) =================

    fun drawHero(c: Canvas, kind: Int, cx: Float, footY: Float, h: Float, phase: Float, attack: Float, tier: Int) {
        c.save()
        if (kind == 2) c.scale(1.2f, 0.88f, cx, footY)
        when (kind) {
            0 -> elf(c, cx, footY, h, phase, attack, tier)
            1 -> mage(c, cx, footY, h, phase, attack, tier)
            else -> dwarf(c, cx, footY, h, phase, attack, tier)
        }
        c.restore()
    }

    private fun legs(c: Canvas, cx: Float, hipY: Float, footY: Float, h: Float, sw: Float, pants: Int, boot: Int, w: Float) {
        val fl = cx - h * 0.06f + sw * h * 0.08f
        val fr = cx + h * 0.06f - sw * h * 0.08f
        c.drawLine(cx - h * 0.06f, hipY, fl, footY - w * 0.5f, stroke(pants, w))
        c.drawLine(cx + h * 0.06f, hipY, fr, footY - w * 0.5f, stroke(pants, w))
        ov(c, fl - w * 0.5f, footY - w * 0.9f, fl + w * 1.3f, footY, fill(boot))
        ov(c, fr - w * 0.5f, footY - w * 0.9f, fr + w * 1.3f, footY, fill(boot))
    }

    private fun elf(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, attack: Float, tier: Int) {
        val r = h * 0.12f
        val headCy = footY - h * 0.76f
        val neckY = headCy + r * 0.95f
        val hipY = footY - h * 0.33f
        val sw = sin(phase)
        val green = 0xFF2E5339.toInt()
        val dk = 0xFF1B3626.toInt()
        val skin = 0xFFF1D4B8.toInt()
        val glow = tierColor(tier)

        // peleryna
        path.reset()
        path.moveTo(cx - h * 0.10f, neckY)
        path.lineTo(cx + h * 0.02f, neckY + h * 0.02f)
        path.lineTo(cx - h * 0.16f, hipY + h * 0.14f)
        path.lineTo(cx - h * 0.36f + sw * h * 0.04f, hipY + h * 0.06f)
        path.close()
        c.drawPath(path, fill(dk))
        // kołczan
        c.save()
        c.rotate(-20f, cx - h * 0.1f, neckY + h * 0.1f)
        rr(c, cx - h * 0.14f, neckY, cx - h * 0.07f, neckY + h * 0.24f, h * 0.02f, fill(0xFF5D4037.toInt()))
        for (i in 0..2) {
            c.drawLine(cx - h * 0.125f + i * h * 0.02f, neckY, cx - h * 0.125f + i * h * 0.02f, neckY - h * 0.07f, stroke(0xFFE0E0E0.toInt(), h * 0.012f))
        }
        c.restore()

        legs(c, cx, hipY, footY, h, sw, 0xFF3B2F2F.toInt(), 0xFF2A1E18.toInt(), h * 0.055f)

        // tunika
        path.reset()
        path.moveTo(cx - h * 0.115f, neckY)
        path.lineTo(cx + h * 0.115f, neckY)
        path.lineTo(cx + h * 0.14f, hipY + h * 0.08f)
        path.lineTo(cx - h * 0.14f, hipY + h * 0.08f)
        path.close()
        c.drawPath(path, fill(green))
        c.drawRect(cx - h * 0.12f, hipY - h * 0.01f, cx + h * 0.12f, hipY + h * 0.025f, fill(0xFF5D4037.toInt()))

        // łuk
        val bx = cx + h * 0.30f
        val by = neckY + h * 0.10f
        val pull = attack.coerceIn(0f, 1f)
        val strX = bx - h * 0.15f * pull
        val bowCol = if (tier > 0) glow else 0xFF8D6E63.toInt()
        arc(c, bx - h * 0.11f, by - h * 0.27f, bx + h * 0.11f, by + h * 0.27f, -80f, 160f, stroke(0xFF8D6E63.toInt(), h * 0.028f))
        if (tier > 0) arc(c, bx - h * 0.11f, by - h * 0.27f, bx + h * 0.11f, by + h * 0.27f, -80f, 160f, stroke((bowCol and 0x00FFFFFF) or 0x66000000, h * 0.05f))
        val topX = bx + h * 0.02f
        val topY = by - h * 0.265f
        val botY = by + h * 0.265f
        c.drawLine(topX, topY, strX, by, stroke(0xFFE0E0E0.toInt(), h * 0.008f))
        c.drawLine(strX, by, topX, botY, stroke(0xFFE0E0E0.toInt(), h * 0.008f))
        // naciągnięta strzała
        if (pull > 0.05f) {
            c.drawLine(strX, by, bx + h * 0.18f, by, stroke(0xFFD7CCC8.toInt(), h * 0.014f))
            tri(c, bx + h * 0.18f, by - h * 0.02f, bx + h * 0.18f, by + h * 0.02f, bx + h * 0.24f, by, fill(if (tier > 0) glow else STEEL))
        }
        // ręce
        c.drawLine(cx + h * 0.09f, neckY + h * 0.04f, bx, by, stroke(green, h * 0.05f))
        c.drawCircle(bx, by, h * 0.03f, fill(skin))
        c.drawLine(cx - h * 0.08f, neckY + h * 0.05f, strX, by, stroke(green, h * 0.05f))
        c.drawCircle(strX, by, h * 0.028f, fill(skin))

        // głowa
        tri(c, cx - r * 0.85f, headCy - r * 0.15f, cx - r * 1.95f, headCy - r * 0.6f, cx - r * 0.8f, headCy + r * 0.35f, fill(skin))
        c.drawCircle(cx, headCy, r, fill(skin))
        c.drawLine(cx - r * 0.05f, headCy - r * 0.3f, cx + r * 0.3f, headCy - r * 0.2f, stroke(0xFF6D4C41.toInt(), r * 0.07f))
        c.drawLine(cx + r * 0.45f, headCy - r * 0.2f, cx + r * 0.8f, headCy - r * 0.3f, stroke(0xFF6D4C41.toInt(), r * 0.07f))
        c.drawCircle(cx + r * 0.15f, headCy - r * 0.05f, r * 0.1f, fill(0xFF2E7D32.toInt()))
        c.drawCircle(cx + r * 0.62f, headCy - r * 0.05f, r * 0.1f, fill(0xFF2E7D32.toInt()))
        c.drawLine(cx + r * 0.2f, headCy + r * 0.5f, cx + r * 0.6f, headCy + r * 0.5f, stroke(0xFF8D4E4E.toInt(), r * 0.06f))
        // kaptur
        arc(c, cx - r * 1.15f, headCy - r * 1.45f, cx + r * 1.1f, headCy + r * 0.65f, 170f, 200f, fill(dk))
        tri(c, cx - r * 1.15f, headCy - r * 0.3f, cx - r * 1.7f, headCy + r * 1.3f, cx - r * 0.4f, neckY + h * 0.02f, fill(dk))
    }

    private fun mage(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, attack: Float, tier: Int) {
        val r = h * 0.12f
        val headCy = footY - h * 0.76f
        val neckY = headCy + r * 0.95f
        val sw = sin(phase)
        val robe = 0xFF4A2A7A.toInt()
        val robeDk = 0xFF35195C.toInt()
        val skin = 0xFFF3D6C4.toInt()
        val glow = if (tier > 0) tierColor(tier) else 0xFF80D8FF.toInt()
        val hem = footY - h * 0.05f

        // długie włosy
        rr(c, cx - r * 1.3f, headCy - r * 0.9f, cx + r * 0.1f, headCy + r * 2.5f, r * 0.7f, fill(0xFF7B1E1E.toInt()))
        // buty spod szaty
        val fl = cx - h * 0.07f + sw * h * 0.06f
        val fr = cx + h * 0.07f - sw * h * 0.06f
        ov(c, fl - h * 0.03f, footY - h * 0.04f, fl + h * 0.07f, footY, fill(0xFF1B1030.toInt()))
        ov(c, fr - h * 0.03f, footY - h * 0.04f, fr + h * 0.07f, footY, fill(0xFF1B1030.toInt()))
        // szata
        path.reset()
        path.moveTo(cx - h * 0.12f, neckY)
        path.lineTo(cx + h * 0.12f, neckY)
        path.lineTo(cx + h * 0.22f + sw * h * 0.01f, hem)
        path.lineTo(cx - h * 0.22f - sw * h * 0.01f, hem)
        path.close()
        c.drawPath(path, fill(robe))
        tri(c, cx - h * 0.02f, neckY + h * 0.1f, cx + h * 0.05f, hem, cx - h * 0.09f, hem, fill(robeDk))
        c.drawRect(cx - h * 0.2f, hem - h * 0.02f, cx + h * 0.2f, hem, fill(GOLD))
        val waist = neckY + (hem - neckY) * 0.4f
        c.drawRect(cx - h * 0.15f, waist, cx + h * 0.15f, waist + h * 0.03f, fill(GOLD))

        // laska
        val sx = cx + h * 0.26f
        val orbY = headCy - h * 0.50f
        c.drawLine(sx, footY - h * 0.02f, sx, orbY + h * 0.03f, stroke(0xFF6D4C41.toInt(), h * 0.026f))
        val orbR = h * 0.05f * (1f + 0.8f * attack)
        c.drawCircle(sx, orbY, orbR * 2.2f, fill((glow and 0x00FFFFFF) or 0x33000000))
        c.drawCircle(sx, orbY, orbR * 1.4f, fill((glow and 0x00FFFFFF) or 0x66000000))
        c.drawCircle(sx, orbY, orbR, fill(glow))
        c.drawCircle(sx - orbR * 0.2f, orbY - orbR * 0.2f, orbR * 0.4f, fill(WHITE))
        // ręce
        val handY = neckY + h * 0.20f
        c.drawLine(cx + h * 0.10f, neckY + h * 0.04f, sx, handY, stroke(robe, h * 0.055f))
        c.drawCircle(sx, handY, h * 0.03f, fill(skin))
        if (attack > 0f) {
            val ox = cx + h * 0.10f
            val oy = neckY - h * 0.03f
            c.drawLine(cx - h * 0.09f, neckY + h * 0.05f, ox, oy, stroke(robe, h * 0.055f))
            c.drawCircle(ox, oy, h * 0.03f, fill(skin))
            c.drawCircle(ox, oy, h * 0.05f * attack, fill((glow and 0x00FFFFFF) or 0xAA000000.toInt()))
        } else {
            c.drawLine(cx - h * 0.09f, neckY + h * 0.05f, cx - h * 0.13f - sw * h * 0.02f, neckY + h * 0.2f, stroke(robe, h * 0.055f))
            c.drawCircle(cx - h * 0.13f - sw * h * 0.02f, neckY + h * 0.2f, h * 0.028f, fill(skin))
        }

        // głowa
        c.drawCircle(cx, headCy, r, fill(skin))
        c.drawLine(cx - r * 0.05f, headCy - r * 0.3f, cx + r * 0.3f, headCy - r * 0.22f, stroke(0xFF5D1818.toInt(), r * 0.07f))
        c.drawLine(cx + r * 0.45f, headCy - r * 0.22f, cx + r * 0.8f, headCy - r * 0.3f, stroke(0xFF5D1818.toInt(), r * 0.07f))
        c.drawCircle(cx + r * 0.15f, headCy - r * 0.05f, r * 0.1f, fill(0xFF4527A0.toInt()))
        c.drawCircle(cx + r * 0.62f, headCy - r * 0.05f, r * 0.1f, fill(0xFF4527A0.toInt()))
        arc(c, cx + r * 0.1f, headCy + r * 0.2f, cx + r * 0.7f, headCy + r * 0.6f, 20f, 140f, stroke(0xFF9E3D4A.toInt(), r * 0.06f))
        // grzywka i kapelusz
        arc(c, cx - r * 1.08f, headCy - r * 1.3f, cx + r * 1.08f, headCy + r * 0.8f, 180f, 180f, fill(0xFF7B1E1E.toInt()))
        ov(c, cx - r * 1.6f, headCy - r * 1.05f, cx + r * 1.5f, headCy - r * 0.45f, fill(0xFF2A1B4D.toInt()))
        path.reset()
        path.moveTo(cx - r * 0.95f, headCy - r * 0.75f)
        path.lineTo(cx + r * 0.95f, headCy - r * 0.75f)
        path.quadTo(cx + r * 0.2f, headCy - r * 2.2f, cx - r * 0.7f, headCy - r * 3.1f)
        path.close()
        c.drawPath(path, fill(0xFF2A1B4D.toInt()))
        c.drawRect(cx - r * 0.95f, headCy - r * 1.0f, cx + r * 0.95f, headCy - r * 0.78f, fill(GOLD))
    }

    private fun dwarf(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, attack: Float, tier: Int) {
        val r = h * 0.125f
        val headCy = footY - h * 0.74f
        val neckY = headCy + r * 0.95f
        val hipY = footY - h * 0.33f
        val sw = sin(phase)
        val mail = 0xFF78909C.toInt()
        val skin = 0xFFE0A98A.toInt()
        val beard = 0xFFD2691E.toInt()
        val glow = tierColor(tier)

        // krótka peleryna
        path.reset()
        path.moveTo(cx - h * 0.13f, neckY)
        path.lineTo(cx + h * 0.0f, neckY)
        path.lineTo(cx - h * 0.1f, hipY + h * 0.1f)
        path.lineTo(cx - h * 0.3f + sw * h * 0.03f, hipY + h * 0.05f)
        path.close()
        c.drawPath(path, fill(0xFF8E2B2B.toInt()))

        legs(c, cx, hipY, footY, h, sw, 0xFF5D4037.toInt(), 0xFF2B1D16.toInt(), h * 0.075f)

        // kolczuga
        path.reset()
        path.moveTo(cx - h * 0.15f, neckY)
        path.lineTo(cx + h * 0.15f, neckY)
        path.lineTo(cx + h * 0.17f, hipY + h * 0.04f)
        path.lineTo(cx - h * 0.17f, hipY + h * 0.04f)
        path.close()
        c.drawPath(path, fill(mail))
        for (i in 1..4) {
            val yy = neckY + (hipY - neckY) * i / 5f
            c.drawLine(cx - h * 0.13f, yy, cx + h * 0.13f, yy, stroke(0xFF546E7A.toInt(), h * 0.008f))
        }
        c.drawRect(cx - h * 0.17f, hipY - h * 0.01f, cx + h * 0.17f, hipY + h * 0.03f, fill(0xFF4E342E.toInt()))
        c.drawRect(cx - h * 0.025f, hipY - h * 0.012f, cx + h * 0.025f, hipY + h * 0.032f, fill(GOLD))

        // topór (w ręce, dopóki nie zostanie rzucony)
        val held = attack <= 0f || attack > 0.34f
        val raised = attack > 0.34f
        val hx = cx + h * 0.20f
        val hy = if (raised) neckY - h * 0.12f else neckY + h * 0.18f
        c.drawLine(cx + h * 0.12f, neckY + h * 0.05f, hx, hy, stroke(mail, h * 0.065f))
        c.drawCircle(hx, hy, h * 0.035f, fill(skin))
        if (held) {
            val tx = hx + h * 0.03f
            val ty = hy - h * 0.26f
            c.drawLine(hx, hy + h * 0.04f, tx, ty, stroke(0xFF6D4C41.toInt(), h * 0.028f))
            path.reset()
            path.moveTo(tx, ty - h * 0.02f)
            path.lineTo(tx + h * 0.14f, ty - h * 0.07f)
            path.lineTo(tx + h * 0.15f, ty + h * 0.11f)
            path.lineTo(tx, ty + h * 0.08f)
            path.close()
            c.drawPath(path, fill(STEEL))
            if (tier > 0) c.drawPath(path, stroke(glow, h * 0.016f))
        }
        c.drawLine(cx - h * 0.12f, neckY + h * 0.06f, cx - h * 0.16f - sw * h * 0.02f, neckY + h * 0.2f, stroke(mail, h * 0.065f))
        c.drawCircle(cx - h * 0.16f - sw * h * 0.02f, neckY + h * 0.2f, h * 0.033f, fill(skin))

        // broda (przed zbroją, pod twarzą)
        path.reset()
        path.moveTo(cx - r * 1.0f, headCy + r * 0.05f)
        path.lineTo(cx + r * 1.0f, headCy + r * 0.05f)
        path.lineTo(cx + r * 0.7f, headCy + r * 2.5f)
        path.lineTo(cx, headCy + r * 3.1f)
        path.lineTo(cx - r * 0.7f, headCy + r * 2.5f)
        path.close()
        c.drawPath(path, fill(beard))
        for (i in -1..1) {
            c.drawLine(cx + i * r * 0.4f, headCy + r * 1.0f, cx + i * r * 0.3f, headCy + r * 2.7f, stroke(0xFFA14F12.toInt(), r * 0.07f))
        }

        // głowa i hełm
        c.drawCircle(cx, headCy, r, fill(skin))
        ov(c, cx - r * 0.1f, headCy + r * 0.25f, cx + r * 0.5f, headCy + r * 0.6f, fill(beard))
        ov(c, cx + r * 0.4f, headCy + r * 0.25f, cx + r * 1.0f, headCy + r * 0.6f, fill(beard))
        c.drawLine(cx - r * 0.05f, headCy - r * 0.32f, cx + r * 0.35f, headCy - r * 0.2f, stroke(0xFF8D4E1E.toInt(), r * 0.1f))
        c.drawLine(cx + r * 0.45f, headCy - r * 0.2f, cx + r * 0.85f, headCy - r * 0.32f, stroke(0xFF8D4E1E.toInt(), r * 0.1f))
        c.drawCircle(cx + r * 0.15f, headCy - r * 0.02f, r * 0.1f, fill(DARK))
        c.drawCircle(cx + r * 0.65f, headCy - r * 0.02f, r * 0.1f, fill(DARK))
        arc(c, cx - r * 1.12f, headCy - r * 1.35f, cx + r * 1.12f, headCy + r * 0.55f, 180f, 180f, fill(0xFF90A4AE.toInt()))
        c.drawRect(cx - r * 1.1f, headCy - r * 0.45f, cx + r * 1.1f, headCy - r * 0.3f, fill(0xFF607D8B.toInt()))
        c.drawRect(cx + r * 0.3f, headCy - r * 0.3f, cx + r * 0.42f, headCy + r * 0.35f, fill(0xFF607D8B.toInt()))
        tri(c, cx - r * 0.9f, headCy - r * 0.95f, cx - r * 1.5f, headCy - r * 1.6f, cx - r * 0.5f, headCy - r * 1.2f, fill(0xFFF5F5F5.toInt()))
        tri(c, cx + r * 0.9f, headCy - r * 0.95f, cx + r * 1.5f, headCy - r * 1.6f, cx + r * 0.5f, headCy - r * 1.2f, fill(0xFFF5F5F5.toInt()))
    }

    // ================= POTWORY (rysowane w prawo, potem odbite) =================

    fun drawMonster(c: Canvas, kind: Int, cx: Float, footY: Float, h: Float, phase: Float, boss: Boolean) {
        c.save()
        c.scale(-1f, 1f, cx, 0f)
        if (boss) c.drawCircle(cx, footY - h * 0.5f, h * 0.75f, fill(0x30FF1744))
        val eye = if (boss) 0xFFFF1744.toInt() else 0xFFFFD600.toInt()
        when (kind) {
            0 -> goblin(c, cx, footY, h, phase, eye)
            1 -> skeleton(c, cx, footY, h, phase, if (boss) 0xFFFF1744.toInt() else 0xFF40C4FF.toInt())
            2 -> bat(c, cx, footY, h, phase)
            3 -> orc(c, cx, footY, h, phase, eye)
            4 -> slime(c, cx, footY, h, phase, eye)
            5 -> ghost(c, cx, footY, h, phase, if (boss) 0xFFFF1744.toInt() else 0xFFB2FF59.toInt())
            else -> troll(c, cx, footY, h, phase, eye)
        }
        c.restore()
    }

    private fun goblin(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val sw = sin(phase)
        val green = 0xFF6B8E23.toInt()
        val r = h * 0.17f
        val headCy = footY - h * 0.70f
        val hipY = footY - h * 0.28f
        val neckY = headCy + r * 0.8f
        c.drawLine(cx - h * 0.05f, hipY, cx - h * 0.05f + sw * h * 0.08f, footY, stroke(0xFF4A5E1A.toInt(), h * 0.05f))
        c.drawLine(cx + h * 0.05f, hipY, cx + h * 0.05f - sw * h * 0.08f, footY, stroke(0xFF4A5E1A.toInt(), h * 0.05f))
        path.reset()
        path.moveTo(cx - h * 0.1f, neckY)
        path.lineTo(cx + h * 0.13f, neckY + h * 0.02f)
        path.lineTo(cx + h * 0.11f, hipY + h * 0.05f)
        path.lineTo(cx - h * 0.11f, hipY + h * 0.05f)
        path.close()
        c.drawPath(path, fill(0xFF5D4037.toInt()))
        c.drawLine(cx + h * 0.08f, neckY + h * 0.05f, cx + h * 0.24f, neckY + h * 0.17f, stroke(green, h * 0.04f))
        c.drawLine(cx + h * 0.24f, neckY + h * 0.17f, cx + h * 0.36f, neckY + h * 0.05f, stroke(STEEL, h * 0.025f))
        c.drawLine(cx - h * 0.08f, neckY + h * 0.05f, cx - h * 0.12f, neckY + h * 0.2f, stroke(green, h * 0.04f))
        val hx = cx + h * 0.05f
        tri(c, hx - r * 0.8f, headCy - r * 0.1f, hx - r * 2.0f, headCy - r * 0.8f, hx - r * 0.7f, headCy + r * 0.4f, fill(green))
        tri(c, hx + r * 0.8f, headCy - r * 0.1f, hx + r * 2.0f, headCy - r * 0.8f, hx + r * 0.7f, headCy + r * 0.4f, fill(green))
        c.drawCircle(hx, headCy, r, fill(green))
        c.drawCircle(hx + r * 0.1f, headCy - r * 0.15f, r * 0.2f, fill(eye))
        c.drawCircle(hx + r * 0.6f, headCy - r * 0.15f, r * 0.2f, fill(eye))
        c.drawCircle(hx + r * 0.15f, headCy - r * 0.15f, r * 0.08f, fill(DARK))
        c.drawCircle(hx + r * 0.65f, headCy - r * 0.15f, r * 0.08f, fill(DARK))
        tri(c, hx + r * 0.3f, headCy, hx + r * 0.7f, headCy + r * 0.2f, hx + r * 0.35f, headCy + r * 0.45f, fill(0xFF557A1F.toInt()))
        for (i in 0..2) {
            tri(c, hx - r * 0.1f + i * r * 0.3f, headCy + r * 0.55f, hx + r * 0.1f + i * r * 0.3f, headCy + r * 0.55f, hx + i * r * 0.3f, headCy + r * 0.8f, fill(WHITE))
        }
    }

    private fun skeleton(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val sw = sin(phase)
        val bone = 0xFFE8E4D4.toInt()
        val r = h * 0.12f
        val headCy = footY - h * 0.82f
        val neckY = headCy + r * 1.1f
        val hipY = footY - h * 0.36f
        c.drawLine(cx - h * 0.05f, hipY, cx - h * 0.05f + sw * h * 0.09f, footY, stroke(bone, h * 0.03f))
        c.drawLine(cx + h * 0.05f, hipY, cx + h * 0.05f - sw * h * 0.09f, footY, stroke(bone, h * 0.03f))
        c.drawLine(cx, neckY, cx, hipY, stroke(bone, h * 0.03f))
        for (i in 0..2) {
            val yy = neckY + h * 0.05f + i * h * 0.07f
            arc(c, cx - h * 0.12f, yy - h * 0.04f, cx + h * 0.12f, yy + h * 0.06f, 0f, 180f, stroke(bone, h * 0.022f))
        }
        c.drawRect(cx - h * 0.07f, hipY - h * 0.01f, cx + h * 0.07f, hipY + h * 0.04f, fill(bone))
        c.drawLine(cx + h * 0.1f, neckY + h * 0.05f, cx + h * 0.22f, neckY + h * 0.17f, stroke(bone, h * 0.025f))
        c.drawLine(cx + h * 0.22f, neckY + h * 0.17f, cx + h * 0.36f, neckY - h * 0.1f, stroke(0xFF90A4AE.toInt(), h * 0.03f))
        c.drawLine(cx + h * 0.19f, neckY + h * 0.12f, cx + h * 0.28f, neckY + h * 0.19f, stroke(0xFF6D4C41.toInt(), h * 0.025f))
        c.drawLine(cx - h * 0.1f, neckY + h * 0.05f, cx - h * 0.13f, neckY + h * 0.2f, stroke(bone, h * 0.025f))
        c.drawCircle(cx, headCy, r, fill(bone))
        rr(c, cx - r * 0.6f, headCy + r * 0.6f, cx + r * 0.6f, headCy + r * 1.2f, r * 0.2f, fill(bone))
        c.drawCircle(cx - r * 0.35f, headCy - r * 0.1f, r * 0.3f, fill(DARK))
        c.drawCircle(cx + r * 0.4f, headCy - r * 0.1f, r * 0.3f, fill(DARK))
        c.drawCircle(cx - r * 0.35f, headCy - r * 0.1f, r * 0.12f, fill(eye))
        c.drawCircle(cx + r * 0.4f, headCy - r * 0.1f, r * 0.12f, fill(eye))
        for (i in 0..3) c.drawLine(cx - r * 0.4f + i * r * 0.27f, headCy + r * 0.7f, cx - r * 0.4f + i * r * 0.27f, headCy + r * 1.15f, stroke(DARK, r * 0.05f))
    }

    private fun bat(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float) {
        val cy = footY - h * 0.5f
        val flap = sin(phase * 1.8f)
        val wing = 0xFF3A2A4A.toInt()
        for (side in intArrayOf(-1, 1)) {
            path.reset()
            path.moveTo(cx + side * h * 0.05f, cy)
            path.lineTo(cx + side * h * 0.5f, cy - h * 0.33f * flap - h * 0.05f)
            path.lineTo(cx + side * h * 0.44f, cy + h * 0.0f)
            path.lineTo(cx + side * h * 0.33f, cy + h * 0.08f)
            path.lineTo(cx + side * h * 0.24f, cy + h * 0.0f)
            path.lineTo(cx + side * h * 0.14f, cy + h * 0.14f)
            path.close()
            c.drawPath(path, fill(wing))
        }
        ov(c, cx - h * 0.11f, cy - h * 0.14f, cx + h * 0.11f, cy + h * 0.16f, fill(0xFF2A1E36.toInt()))
        c.drawCircle(cx, cy - h * 0.16f, h * 0.09f, fill(0xFF2A1E36.toInt()))
        tri(c, cx - h * 0.08f, cy - h * 0.2f, cx - h * 0.05f, cy - h * 0.34f, cx - h * 0.01f, cy - h * 0.23f, fill(0xFF2A1E36.toInt()))
        tri(c, cx + h * 0.08f, cy - h * 0.2f, cx + h * 0.05f, cy - h * 0.34f, cx + h * 0.01f, cy - h * 0.23f, fill(0xFF2A1E36.toInt()))
        c.drawCircle(cx - h * 0.035f, cy - h * 0.17f, h * 0.022f, fill(0xFFFF1744.toInt()))
        c.drawCircle(cx + h * 0.035f, cy - h * 0.17f, h * 0.022f, fill(0xFFFF1744.toInt()))
        tri(c, cx - h * 0.03f, cy - h * 0.1f, cx - h * 0.015f, cy - h * 0.1f, cx - h * 0.022f, cy - h * 0.06f, fill(WHITE))
        tri(c, cx + h * 0.03f, cy - h * 0.1f, cx + h * 0.015f, cy - h * 0.1f, cx + h * 0.022f, cy - h * 0.06f, fill(WHITE))
    }

    private fun orc(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val sw = sin(phase)
        val skin = 0xFF557A3A.toInt()
        val armor = 0xFF37474F.toInt()
        val r = h * 0.14f
        val headCy = footY - h * 0.78f
        val neckY = headCy + r * 0.9f
        val hipY = footY - h * 0.3f
        c.drawLine(cx - h * 0.07f, hipY, cx - h * 0.07f + sw * h * 0.08f, footY, stroke(0xFF3E4A2A.toInt(), h * 0.08f))
        c.drawLine(cx + h * 0.07f, hipY, cx + h * 0.07f - sw * h * 0.08f, footY, stroke(0xFF3E4A2A.toInt(), h * 0.08f))
        path.reset()
        path.moveTo(cx - h * 0.2f, neckY)
        path.lineTo(cx + h * 0.2f, neckY)
        path.lineTo(cx + h * 0.15f, hipY + h * 0.03f)
        path.lineTo(cx - h * 0.15f, hipY + h * 0.03f)
        path.close()
        c.drawPath(path, fill(skin))
        path.reset()
        path.moveTo(cx - h * 0.15f, neckY + h * 0.02f)
        path.lineTo(cx + h * 0.15f, neckY + h * 0.02f)
        path.lineTo(cx + h * 0.12f, hipY - h * 0.02f)
        path.lineTo(cx - h * 0.12f, hipY - h * 0.02f)
        path.close()
        c.drawPath(path, fill(armor))
        c.drawCircle(cx - h * 0.2f, neckY + h * 0.02f, h * 0.07f, fill(0xFF455A64.toInt()))
        c.drawCircle(cx + h * 0.2f, neckY + h * 0.02f, h * 0.07f, fill(0xFF455A64.toInt()))
        tri(c, cx + h * 0.17f, neckY - h * 0.03f, cx + h * 0.23f, neckY - h * 0.03f, cx + h * 0.2f, neckY - h * 0.12f, fill(STEEL))
        // topór
        c.drawLine(cx + h * 0.2f, neckY + h * 0.08f, cx + h * 0.3f, neckY + h * 0.2f, stroke(skin, h * 0.07f))
        c.drawLine(cx + h * 0.3f, neckY + h * 0.3f, cx + h * 0.36f, neckY - h * 0.15f, stroke(0xFF6D4C41.toInt(), h * 0.035f))
        tri(c, cx + h * 0.36f, neckY - h * 0.2f, cx + h * 0.5f, neckY - h * 0.08f, cx + h * 0.34f, neckY, fill(0xFF78909C.toInt()))
        c.drawLine(cx - h * 0.2f, neckY + h * 0.06f, cx - h * 0.24f, neckY + h * 0.24f, stroke(skin, h * 0.07f))
        c.drawCircle(cx, headCy, r, fill(skin))
        c.drawRect(cx - r * 0.2f, headCy - r * 0.95f, cx + r * 0.3f, headCy - r * 0.6f, fill(0xFF2E3B22.toInt()))
        c.drawLine(cx - r * 0.1f, headCy - r * 0.35f, cx + r * 0.35f, headCy - r * 0.2f, stroke(DARK, r * 0.1f))
        c.drawLine(cx + r * 0.5f, headCy - r * 0.2f, cx + r * 0.9f, headCy - r * 0.35f, stroke(DARK, r * 0.1f))
        c.drawCircle(cx + r * 0.2f, headCy - r * 0.05f, r * 0.14f, fill(eye))
        c.drawCircle(cx + r * 0.65f, headCy - r * 0.05f, r * 0.14f, fill(eye))
        rr(c, cx - r * 0.1f, headCy + r * 0.35f, cx + r * 0.9f, headCy + r * 0.8f, r * 0.2f, fill(0xFF3E5A2A.toInt()))
        tri(c, cx + r * 0.05f, headCy + r * 0.4f, cx + r * 0.25f, headCy + r * 0.4f, cx + r * 0.15f, headCy - r * 0.1f, fill(WHITE))
        tri(c, cx + r * 0.6f, headCy + r * 0.4f, cx + r * 0.8f, headCy + r * 0.4f, cx + r * 0.7f, headCy - r * 0.1f, fill(WHITE))
    }

    private fun slime(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val w = h * 0.6f * (1f + 0.07f * sin(phase * 1.5f))
        val hh = h * 0.6f * (1f - 0.07f * sin(phase * 1.5f))
        ov(c, cx - w / 2f, footY - hh, cx + w / 2f, footY + h * 0.02f, fill(0xCC3E9B45.toInt()))
        ov(c, cx - w * 0.38f, footY - hh * 0.8f, cx + w * 0.38f, footY - h * 0.02f, fill(0x663E9B45.toInt()))
        ov(c, cx - w * 0.3f, footY - hh * 0.82f, cx - w * 0.05f, footY - hh * 0.6f, fill(0x88FFFFFF.toInt()))
        c.drawCircle(cx - w * 0.15f, footY - hh * 0.25f, h * 0.03f, fill(0x88C8E6C9.toInt()))
        c.drawCircle(cx + w * 0.2f, footY - hh * 0.35f, h * 0.045f, fill(0x88C8E6C9.toInt()))
        c.drawCircle(cx + w * 0.05f, footY - hh * 0.15f, h * 0.025f, fill(0x88C8E6C9.toInt()))
        c.drawCircle(cx + w * 0.02f, footY - hh * 0.55f, h * 0.05f, fill(eye))
        c.drawCircle(cx + w * 0.25f, footY - hh * 0.55f, h * 0.05f, fill(eye))
        c.drawCircle(cx + w * 0.04f, footY - hh * 0.55f, h * 0.02f, fill(DARK))
        c.drawCircle(cx + w * 0.27f, footY - hh * 0.55f, h * 0.02f, fill(DARK))
    }

    private fun ghost(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val wave = sin(phase * 2f) * h * 0.04f
        path.reset()
        path.moveTo(cx - h * 0.22f, footY - h * 0.5f)
        path.quadTo(cx - h * 0.22f, footY - h * 0.98f, cx, footY - h * 0.98f)
        path.quadTo(cx + h * 0.22f, footY - h * 0.98f, cx + h * 0.22f, footY - h * 0.5f)
        path.lineTo(cx + h * 0.22f, footY - h * 0.12f + wave)
        path.lineTo(cx + h * 0.11f, footY - h * 0.26f - wave)
        path.lineTo(cx, footY - h * 0.1f + wave)
        path.lineTo(cx - h * 0.11f, footY - h * 0.26f - wave)
        path.lineTo(cx - h * 0.22f, footY - h * 0.12f - wave)
        path.close()
        c.drawPath(path, fill(0xAA9FB8D4.toInt()))
        c.drawLine(cx + h * 0.2f, footY - h * 0.5f, cx + h * 0.4f, footY - h * 0.4f + wave, stroke(0x889FB8D4.toInt(), h * 0.05f))
        c.drawLine(cx - h * 0.2f, footY - h * 0.5f, cx - h * 0.3f, footY - h * 0.35f - wave, stroke(0x889FB8D4.toInt(), h * 0.05f))
        ov(c, cx - h * 0.12f, footY - h * 0.78f, cx - h * 0.03f, footY - h * 0.62f, fill(0xFF1A1A2E.toInt()))
        ov(c, cx + h * 0.04f, footY - h * 0.78f, cx + h * 0.13f, footY - h * 0.62f, fill(0xFF1A1A2E.toInt()))
        c.drawCircle(cx - h * 0.075f, footY - h * 0.7f, h * 0.02f, fill(eye))
        c.drawCircle(cx + h * 0.085f, footY - h * 0.7f, h * 0.02f, fill(eye))
        ov(c, cx - h * 0.05f, footY - h * 0.56f, cx + h * 0.06f, footY - h * 0.46f, fill(0xFF1A1A2E.toInt()))
    }

    private fun troll(c: Canvas, cx: Float, footY: Float, h: Float, phase: Float, eye: Int) {
        val sw = sin(phase * 0.8f)
        val skin = 0xFF7A7867.toInt()
        val r = h * 0.11f
        val headCy = footY - h * 0.76f
        val neckY = headCy + r * 0.9f
        val hipY = footY - h * 0.3f
        c.drawLine(cx - h * 0.08f, hipY, cx - h * 0.08f + sw * h * 0.06f, footY, stroke(0xFF5D5B4C.toInt(), h * 0.11f))
        c.drawLine(cx + h * 0.08f, hipY, cx + h * 0.08f - sw * h * 0.06f, footY, stroke(0xFF5D5B4C.toInt(), h * 0.11f))
        rr(c, cx - h * 0.24f, neckY, cx + h * 0.24f, hipY + h * 0.05f, h * 0.1f, fill(skin))
        ov(c, cx - h * 0.1f, neckY + h * 0.1f, cx + h * 0.1f, neckY + h * 0.26f, fill(0xFF8A8874.toInt()))
        c.drawCircle(cx - h * 0.12f, neckY + h * 0.05f, h * 0.035f, fill(0xFF558B2F.toInt()))
        c.drawCircle(cx + h * 0.15f, neckY + h * 0.2f, h * 0.03f, fill(0xFF558B2F.toInt()))
        c.drawLine(cx + h * 0.22f, neckY + h * 0.06f, cx + h * 0.34f, neckY + h * 0.24f, stroke(skin, h * 0.1f))
        c.drawLine(cx + h * 0.3f, neckY + h * 0.3f, cx + h * 0.42f, neckY - h * 0.2f, stroke(0xFF5D4037.toInt(), h * 0.05f))
        ov(c, cx + h * 0.34f, neckY - h * 0.34f, cx + h * 0.52f, neckY - h * 0.1f, fill(0xFF6D4C41.toInt()))
        c.drawLine(cx - h * 0.22f, neckY + h * 0.06f, cx - h * 0.28f, neckY + h * 0.28f, stroke(skin, h * 0.1f))
        c.drawCircle(cx + h * 0.02f, headCy, r, fill(skin))
        c.drawCircle(cx + h * 0.06f, headCy - r * 0.15f, r * 0.14f, fill(eye))
        c.drawCircle(cx + h * 0.1f + r * 0.4f, headCy - r * 0.15f, r * 0.14f, fill(eye))
        rr(c, cx - r * 0.2f, headCy + r * 0.3f, cx + r * 1.0f, headCy + r * 0.8f, r * 0.2f, fill(0xFF5D5B4C.toInt()))
        tri(c, cx + r * 0.0f, headCy + r * 0.35f, cx + r * 0.25f, headCy + r * 0.35f, cx + r * 0.12f, headCy - r * 0.15f, fill(0xFFF5F5DC.toInt()))
        tri(c, cx + r * 0.7f, headCy + r * 0.35f, cx + r * 0.95f, headCy + r * 0.35f, cx + r * 0.82f, headCy - r * 0.15f, fill(0xFFF5F5DC.toInt()))
    }

    // ================= BONUS (duszek z eliksirem) =================

    fun drawWisp(c: Canvas, cx: Float, y: Float, s: Float, phase: Float) {
        for (i in 3 downTo 1) {
            c.drawCircle(cx + i * s * 0.5f, y + sin(phase + i) * s * 0.1f, s * (0.5f - i * 0.1f), fill(0x334FC3F7))
        }
        c.drawCircle(cx, y, s * 1.5f, fill(0x224FC3F7))
        c.drawCircle(cx, y, s * 1.0f, fill(0x554FC3F7))
        c.drawCircle(cx, y, s * 0.6f, fill(0xFFB3E5FC.toInt()))
        c.drawCircle(cx, y, s * 0.3f, fill(WHITE))
        // flakonik
        val fy = y + s * 0.9f
        rr(c, cx - s * 0.35f, fy, cx + s * 0.35f, fy + s * 0.7f, s * 0.2f, fill(0xFFD32F2F.toInt()))
        c.drawRect(cx - s * 0.12f, fy - s * 0.25f, cx + s * 0.12f, fy + s * 0.02f, fill(0xFFB0BEC5.toInt()))
        c.drawRect(cx - s * 0.16f, fy - s * 0.35f, cx + s * 0.16f, fy - s * 0.22f, fill(0xFF8D6E63.toInt()))
        ov(c, cx - s * 0.2f, fy + s * 0.12f, cx - s * 0.08f, fy + s * 0.4f, fill(0x88FFFFFF.toInt()))
    }

    // ================= POCISKI =================

    fun drawProjectile(c: Canvas, kind: Int, x: Float, y: Float, h: Float, t: Float, tier: Int, angle: Float) {
        val glow = tierColor(tier)
        c.drawCircle(x, y, h * 0.16f, fill((glow and 0x00FFFFFF) or 0x33000000))
        when (kind) {
            0 -> {
                c.save()
                c.rotate(angle, x, y)
                c.drawLine(x - h * 0.22f, y, x + h * 0.1f, y, stroke(0xFFD7CCC8.toInt(), h * 0.018f))
                tri(c, x + h * 0.08f, y - h * 0.03f, x + h * 0.08f, y + h * 0.03f, x + h * 0.17f, y, fill(if (tier > 0) glow else STEEL))
                tri(c, x - h * 0.22f, y, x - h * 0.16f, y - h * 0.04f, x - h * 0.15f, y, fill(if (tier > 0) glow else WHITE))
                tri(c, x - h * 0.22f, y, x - h * 0.16f, y + h * 0.04f, x - h * 0.15f, y, fill(if (tier > 0) glow else WHITE))
                c.restore()
            }
            1 -> {
                c.drawCircle(x, y, h * 0.09f, fill((glow and 0x00FFFFFF) or 0x99000000.toInt()))
                c.drawCircle(x, y, h * 0.055f, fill(glow))
                c.drawCircle(x, y, h * 0.028f, fill(WHITE))
                val k = h * (0.1f + 0.04f * abs(sin(t * 30f)))
                c.drawLine(x - k, y, x + k, y, stroke(WHITE, h * 0.012f))
                c.drawLine(x, y - k, x, y + k, stroke(WHITE, h * 0.012f))
            }
            else -> {
                c.save()
                c.rotate((t * 900f) % 360f, x, y)
                c.drawLine(x - h * 0.1f, y, x + h * 0.1f, y, stroke(0xFF6D4C41.toInt(), h * 0.03f))
                path.reset()
                path.moveTo(x + h * 0.07f, y - h * 0.14f)
                path.lineTo(x + h * 0.13f, y)
                path.lineTo(x + h * 0.07f, y + h * 0.14f)
                path.lineTo(x - h * 0.01f, y + h * 0.04f)
                path.lineTo(x - h * 0.01f, y - h * 0.04f)
                path.close()
                c.drawPath(path, fill(STEEL))
                if (tier > 0) c.drawPath(path, stroke(glow, h * 0.018f))
                c.restore()
            }
        }
    }
}
