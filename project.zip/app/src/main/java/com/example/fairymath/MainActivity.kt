package com.example.fairymath

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Animowana postać na ekranach menu. */
class PreviewView(context: Context, private val kind: Int) : View(context) {
    override fun onDraw(canvas: Canvas) {
        val t = System.nanoTime() / 1_000_000_000f
        Art.drawPerson(canvas, kind, width / 2f, height * 0.95f, height * 0.78f, t * 6f, 0f)
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {

    private var game: GameView? = null
    private var pauseDialog: AlertDialog? = null
    private var screen = "menu"
    private val ink = 0xFF4A148C.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMenu()
    }

    override fun onPause() {
        super.onPause()
        val g = game
        if (screen == "game" && g != null && !g.paused) {
            g.paused = true
            g.tapToResume = true
        }
    }

    override fun onBackPressed() {
        when (screen) {
            "menu" -> super.onBackPressed()
            "game" -> showPauseDialog()
            else -> showMenu()
        }
    }

    // ---------- pomocnicy interfejsu ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun bg() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xFFFFC1E3.toInt(), 0xFFD1C4E9.toInt(), 0xFFB3E5FC.toInt())
    )

    private fun roundBg(color: Int, radiusDp: Int, strokeColor: Int = Color.WHITE) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(3), strokeColor)
        }

    private fun <T : View> T.sized(w: Int, h: Int, top: Int = 0): T {
        layoutParams = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
        return this
    }

    private fun fancyButton(label: String, color: Int, size: Float = 20f, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = size
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            background = RippleDrawable(ColorStateList.valueOf(0x66FFFFFF), roundBg(color, 28), null)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun titleView(label: String, size: Float = 34f) = TextView(this).apply {
        text = label
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(ink)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        setShadowLayer(6f, 0f, 3f, 0xFFFFFFFF.toInt())
    }

    private fun label(txt: String, size: Float = 20f) = TextView(this).apply {
        text = txt
        textSize = size
        setTextColor(ink)
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }

    private fun page(views: List<View>) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }
        views.forEach { col.addView(it) }
        val scroll = ScrollView(this).apply {
            background = bg()
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        setContentView(scroll)
    }

    // ---------- ekrany ----------

    private fun showMenu() {
        screen = "menu"
        game = null
        val heroes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (k in 0..3) addView(PreviewView(this@MainActivity, k).sized(dp(70), dp(110)))
        }
        val hasSave = Store.loadGame(this) != null
        val load = fancyButton("Wczytaj grę", 0xFF29B6F6.toInt()) {
            val sv = Store.loadGame(this)
            if (sv != null) startGame(sv.character, sv)
        }
        load.isEnabled = hasSave
        load.alpha = if (hasSave) 1f else 0.5f

        page(
            listOf(
                titleView("Czarodziejskie\nLiczby", 38f).sized(MATCH, WRAP),
                heroes.sized(MATCH, WRAP, 8),
                fancyButton("Nowa gra", 0xFFEC407A.toInt()) { showCharacterSelect() }.sized(MATCH, dp(56), 16),
                load.sized(MATCH, dp(56), 12),
                fancyButton("Wyniki", 0xFFAB47BC.toInt()) { showScores() }.sized(MATCH, dp(56), 12),
                fancyButton("Ustawienia", 0xFF7E57C2.toInt()) { showSettings() }.sized(MATCH, dp(56), 12),
                fancyButton("Wyjdź", 0xFF78909C.toInt()) { finish() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showCharacterSelect() {
        screen = "select"
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (row in 0..1) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in 0..1) {
                val k = row * 2 + col
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(6), dp(6), dp(6), dp(10))
                    background = roundBg(0xCCFFFFFF.toInt(), 20, 0xFFBA68C8.toInt())
                    setOnClickListener { startGame(k, null) }
                    addView(PreviewView(this@MainActivity, k).sized(MATCH, dp(150)))
                    addView(label(Art.name(k), 20f).sized(WRAP, WRAP))
                }
                r.addView(card, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                })
            }
            grid.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        page(
            listOf(
                titleView("Wybierz bohatera", 30f).sized(MATCH, WRAP),
                grid.sized(MATCH, WRAP, 12),
                fancyButton("Wróć", 0xFF78909C.toInt()) { showMenu() }.sized(MATCH, dp(52), 12)
            )
        )
    }

    private fun startGame(character: Int, save: SaveState?) {
        screen = "game"
        val cfg = Store.settings(this)
        val gv = GameView(this, cfg, character, save)
        gv.listener = object : GameView.Listener {
            override fun onGameOver(score: Int) {
                if (game === gv) gameOver(score)
            }

            override fun onPauseRequested() {
                showPauseDialog()
            }
        }
        game = gv
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFEDE7F6.toInt())
        }
        root.addView(gv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(keypad(gv), LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    private fun keypad(gv: GameView): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            setBackgroundColor(0xFFD1C4E9.toInt())
        }
        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9"),
            arrayOf("Cofnij", "0", "Zatwierdź")
        )
        for (row in rows) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in row) {
                val color = when (key) {
                    "Cofnij" -> 0xFFEF6C00.toInt()
                    "Zatwierdź" -> 0xFF2E7D32.toInt()
                    else -> 0xFF7E57C2.toInt()
                }
                val size = if (key.length > 2) 15f else 24f
                val b = fancyButton(key, color, size) {
                    when (key) {
                        "Cofnij" -> gv.backspace()
                        "Zatwierdź" -> gv.submit()
                        else -> gv.pressDigit(key.toInt())
                    }
                }
                r.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            col.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return col
    }

    private fun showPauseDialog() {
        val g = game ?: return
        if (pauseDialog?.isShowing == true) return
        g.paused = true
        g.tapToResume = false
        pauseDialog = AlertDialog.Builder(this)
            .setTitle("Pauza")
            .setItems(arrayOf("Wznów grę", "Zapisz i wyjdź do menu", "Wyjdź bez zapisu")) { _, which ->
                when (which) {
                    0 -> {
                        g.paused = false
                    }
                    1 -> {
                        Store.saveGame(this, g.snapshot())
                        Toast.makeText(this, "Gra zapisana", Toast.LENGTH_SHORT).show()
                        showMenu()
                    }
                    else -> {
                        showMenu()
                    }
                }
            }
            .setOnCancelListener { g.paused = false }
            .show()
    }

    private fun gameOver(score: Int) {
        screen = "over"
        game = null
        Store.clearGame(this)
        val best = Store.best(this)
        if (score > 0) Store.addScore(this, score)
        val record = score > best && score > 0
        val msg = if (record) "Nowy rekord! Brawo!" else "Najlepszy wynik: $best"
        page(
            listOf(
                titleView("Koniec gry!", 38f).sized(MATCH, WRAP),
                label("Twój wynik", 22f).sized(WRAP, WRAP, 24),
                titleView("$score", 64f).sized(MATCH, WRAP),
                label(msg, 20f).sized(WRAP, WRAP, 8),
                fancyButton("Zagraj jeszcze raz", 0xFFEC407A.toInt()) { showCharacterSelect() }
                    .sized(MATCH, dp(56), 28),
                fancyButton("Menu", 0xFF7E57C2.toInt()) { showMenu() }.sized(MATCH, dp(56), 12)
            )
        )
    }

    private fun showScores() {
        screen = "scores"
        val list = Store.scores(this)
        val views = ArrayList<View>()
        views.add(titleView("Wyniki", 34f).sized(MATCH, WRAP))
        if (list.isEmpty()) {
            views.add(label("Jeszcze brak wyników.\nZagraj pierwszą grę!", 20f).sized(WRAP, WRAP, 24))
        } else {
            list.forEachIndexed { i, e ->
                views.add(label("${i + 1}.   ${e.score} pkt    ${e.date}", 20f).sized(WRAP, WRAP, 10))
            }
        }
        views.add(fancyButton("Wróć", 0xFF78909C.toInt()) { showMenu() }.sized(MATCH, dp(52), 28))
        page(views)
    }

    private fun onSeek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            f(progress)
        }

        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    }

    private fun showSettings() {
        screen = "settings"
        var st = Store.settings(this)
        fun save() = Store.saveSettings(this, st)

        val cbAdd = CheckBox(this).apply {
            text = "Dodawanie (+)"
            textSize = 20f
            setTextColor(ink)
            isChecked = st.add
        }
        val cbSub = CheckBox(this).apply {
            text = "Odejmowanie (−)"
            textSize = 20f
            setTextColor(ink)
            isChecked = st.sub
        }
        cbAdd.setOnCheckedChangeListener { _, checked ->
            if (!checked && !cbSub.isChecked) {
                cbAdd.isChecked = true
            } else {
                st = st.copy(add = checked)
                save()
            }
        }
        cbSub.setOnCheckedChangeListener { _, checked ->
            if (!checked && !cbAdd.isChecked) {
                cbSub.isChecked = true
            } else {
                st = st.copy(sub = checked)
                save()
            }
        }

        val tvFrom = label("Od: ${st.min}", 18f)
        val tvTo = label("Do: ${st.max}", 18f)
        val sbFrom = SeekBar(this).apply { max = 99; progress = st.min }
        val sbTo = SeekBar(this).apply { max = 99; progress = st.max - 1 }
        sbFrom.setOnSeekBarChangeListener(onSeek { p ->
            val lo = p
            var hi = st.max
            if (lo >= hi) {
                hi = lo + 1
                sbTo.progress = hi - 1
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })
        sbTo.setOnSeekBarChangeListener(onSeek { p ->
            val hi = p + 1
            var lo = st.min
            if (hi <= lo) {
                lo = hi - 1
                sbFrom.progress = lo
            }
            st = st.copy(min = lo, max = hi)
            tvFrom.text = "Od: $lo"
            tvTo.text = "Do: $hi"
            save()
        })

        val rg = RadioGroup(this)
        val names = arrayOf("Łatwy – dużo czasu (22 s)", "Średni (15 s)", "Trudny – mało czasu (10 s)")
        names.forEachIndexed { i, txt ->
            rg.addView(RadioButton(this).apply {
                id = 1000 + i
                text = txt
                textSize = 18f
                setTextColor(ink)
            })
        }
        rg.check(1000 + st.difficulty)
        rg.setOnCheckedChangeListener { _, id ->
            st = st.copy(difficulty = id - 1000)
            save()
        }

        page(
            listOf(
                titleView("Ustawienia", 34f).sized(MATCH, WRAP),
                label("Działania").sized(WRAP, WRAP, 20),
                cbAdd.sized(WRAP, WRAP, 4),
                cbSub.sized(WRAP, WRAP, 4),
                label("Zakres liczb").sized(WRAP, WRAP, 20),
                tvFrom.sized(WRAP, WRAP, 6),
                sbFrom.sized(MATCH, WRAP),
                tvTo.sized(WRAP, WRAP, 6),
                sbTo.sized(MATCH, WRAP),
                label("Czas na odpowiedź").sized(WRAP, WRAP, 20),
                rg.sized(MATCH, WRAP, 4),
                label("Z każdym poziomem czas się trochę skraca,\na liczby rosną.", 14f).sized(WRAP, WRAP, 8),
                fancyButton("Wróć", 0xFF78909C.toInt()) { showMenu() }.sized(MATCH, dp(52), 20)
            )
        )
    }
}
