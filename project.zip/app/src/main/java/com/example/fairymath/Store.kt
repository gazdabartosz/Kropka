package com.example.fairymath

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class GameSettings(
    val add: Boolean = true,
    val sub: Boolean = true,
    val min: Int = 1,
    val max: Int = 10,
    val difficulty: Int = 0
)

data class SaveState(
    val character: Int,
    val score: Int,
    val lives: Int,
    val level: Int,
    val progress: Int
)

data class ScoreEntry(val score: Int, val date: String)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("fairymath", Context.MODE_PRIVATE)

    fun settings(c: Context): GameSettings {
        val sp = prefs(c)
        return GameSettings(
            sp.getBoolean("add", true),
            sp.getBoolean("sub", true),
            sp.getInt("min", 1),
            sp.getInt("max", 10),
            sp.getInt("diff", 0)
        )
    }

    fun saveSettings(c: Context, s: GameSettings) {
        prefs(c).edit()
            .putBoolean("add", s.add)
            .putBoolean("sub", s.sub)
            .putInt("min", s.min)
            .putInt("max", s.max)
            .putInt("diff", s.difficulty)
            .apply()
    }

    fun scores(c: Context): List<ScoreEntry> {
        val raw = prefs(c).getString("scores", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(";").mapNotNull { item ->
            val parts = item.split(",")
            val sc = parts.getOrNull(0)?.toIntOrNull()
            if (sc == null) null else ScoreEntry(sc, parts.getOrNull(1) ?: "")
        }
    }

    fun best(c: Context): Int = scores(c).maxOfOrNull { it.score } ?: 0

    fun addScore(c: Context, score: Int) {
        val date = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
        val list = (scores(c) + ScoreEntry(score, date))
            .sortedByDescending { it.score }
            .take(10)
        prefs(c).edit()
            .putString("scores", list.joinToString(";") { "${it.score},${it.date}" })
            .apply()
    }

    fun saveGame(c: Context, s: SaveState) {
        prefs(c).edit()
            .putString("save", "${s.character},${s.score},${s.lives},${s.level},${s.progress}")
            .apply()
    }

    fun loadGame(c: Context): SaveState? {
        val raw = prefs(c).getString("save", null) ?: return null
        val p = raw.split(",").mapNotNull { it.toIntOrNull() }
        if (p.size != 5) return null
        return SaveState(p[0], p[1], p[2], p[3], p[4])
    }

    fun clearGame(c: Context) {
        prefs(c).edit().remove("save").apply()
    }
}
